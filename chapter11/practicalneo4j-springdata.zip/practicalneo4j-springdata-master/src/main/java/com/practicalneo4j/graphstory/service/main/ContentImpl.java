package com.practicalneo4j.graphstory.service.main;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.practicalneo4j.graphstory.domain.Content;
import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.domain.pojo.MappedContent;
import com.practicalneo4j.graphstory.service.GraphStoryService;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Service("contentInterface")
@Scope("prototype")
public class ContentImpl extends GraphStoryService implements ContentInterface {

	static Logger log = Logger.getLogger(ContentImpl.class);

	@Override
	public GraphStory getContent(GraphStory graphStory, String username, Integer page, Integer pagesize) {

		Page<MappedContent> mappedContent = mappedContentRepository.getContent(username, new PageRequest(page, pagesize, new Sort(Direction.DESC, "p.timestamp")));

		// return the mapped content
		graphStory.setContent(Lists.newLinkedList(mappedContent.getContent()));

		// is there more content?
		graphStory.setNext(mappedContent.hasNext());
		return graphStory;

	}

	@Override
	public List<MappedContent> getContentByTag(String username, String tag, Boolean getuserscontent) {

		if (getuserscontent) {
			return mappedContentRepository.getUserContentWithTag(username, tag);
		} else {
			return mappedContentRepository.getFollowingContentWithTag(username, tag);
		}

	}

	@Override
	public Content getContentItem(String contentId) {

		Content content = contentRepository.findBySchemaPropertyValue("contentId", contentId);

		return content;
	}

	@Override
	public Content add(Content content, User user) {

		content.setContentId(uuidGenWithTimeStamp());
		content.setTimestamp(new Date().getTime() / 1000);
		content.setTagstr(removeTrailingComma(content.getTagstr()));

		Content currentPost = contentRepository.currentpost(user.getNodeId());

		// has the user posted content before? if so, then get the "currentPost", remove that REL, set THIS post as CURRENTPOST by creating REL with user,
		// then make currentPost the "next" post and save it all
		if (currentPost != null) {
			neo4jTemplate.deleteRelationshipBetween(user, currentPost, GraphStoryConstants.CURRENTPOST);
			content.setUser(user);
			content.setNext(currentPost);
			content = contentRepository.save(content);

		}
		// or is the first content post for this user?
		else {
			content.setUser(user);
			content = contentRepository.save(content);
		}

		return content;
	}

	@Override
	public Content edit(Content content, User user) {

		Content c = contentRepository.findByContentId(content.getContentId());

		// just update the essentials. it WILL NOT be re-ordered.
		c.setTitle(content.getTitle());
		c.setUrl(content.getUrl());

		if (content.getTags() != null) {
			c.setTags(content.getTags());
			c.setTagstr(removeTrailingComma(content.getTagstr()));
		}

		content = contentRepository.save(c);
		return content;
	}

	@Override
	public void delete(String contentId, User user) {
		Content content = getContentItem(contentId);

		Content currentPost = contentRepository.currentpost(user.getNodeId());

		// this was the last post
		if (content.getContentId().equals(currentPost.getContentId())) {
			// get the next post

			// remove the rel between currentpost and profile
			neo4jTemplate.deleteRelationshipBetween(user, content, GraphStoryConstants.CURRENTPOST);

			// remote the rel between currentpost and next post
			if (content.getNext() != null) {
				Content nextPost = contentRepository.findOne(content.getNext().getNodeId());

				neo4jTemplate.deleteRelationshipBetween(content, nextPost, GraphStoryConstants.NEXTPOST);
				// make nextpost the currentpost
				neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(user.getNodeId()), neo4jTemplate.getNode(nextPost.getNodeId()), GraphStoryConstants.CURRENTPOST, null);
				// set the profile
				nextPost.setUser(user);
				// save it
				contentRepository.save(nextPost);
			}

		}
		// some next content
		else
		{
			// is next to currentpost
			if (currentPost.getNext().getNodeId().equals(content.getNodeId())) {

				// remove the rel between currentpost and the next to last content
				neo4jTemplate.deleteRelationshipBetween(currentPost, content, GraphStoryConstants.NEXTPOST);

				if (content.getNext().getNodeId() != null) {
					// get the next content
					Content newNextToLasttPost = contentRepository.findOne(content.getNext().getNodeId());
					// remote the rel between the now former next to last content and new next to last content
					neo4jTemplate.deleteRelationshipBetween(content, newNextToLasttPost, GraphStoryConstants.NEXTPOST);
					// create rel bewteen the last content and now new next to last content
					neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(currentPost.getNodeId()), neo4jTemplate.getNode(newNextToLasttPost.getNodeId()), GraphStoryConstants.NEXTPOST, null);
					// set the next
					currentPost.setNext(newNextToLasttPost);
					// save it
					contentRepository.save(currentPost);
				}

			} else {

				Content previousPost = contentRepository.prevpost(content.getNodeId());
				// remove the rel between prevpost and content
				neo4jTemplate.deleteRelationshipBetween(previousPost, content, GraphStoryConstants.NEXTPOST);

				if (content.getNext().getNodeId() != null) {
					Content newNextPost = contentRepository.findOne(content.getNext().getNodeId());
					neo4jTemplate.deleteRelationshipBetween(content, newNextPost, GraphStoryConstants.NEXTPOST);

					neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(previousPost.getNodeId()), neo4jTemplate.getNode(newNextPost.getNodeId()), GraphStoryConstants.NEXTPOST, null);

					// set the next
					previousPost.setNext(newNextPost);
					// save it
					contentRepository.save(previousPost);
				}

			}
		}
		// delete the content
		neo4jTemplate.delete(content);
	}

	private String removeTrailingComma(String s) {
		s = s.trim();
		if (s.endsWith(",")) {
			s = s.substring(0, s.length() - 1);
		}

		return s;
	}
}