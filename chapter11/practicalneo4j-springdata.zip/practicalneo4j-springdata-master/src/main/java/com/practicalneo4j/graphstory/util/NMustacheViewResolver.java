package com.practicalneo4j.graphstory.util;

import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
import org.springframework.web.servlet.view.AbstractUrlBasedView;
import org.springframework.web.servlet.view.mustache.MustacheTemplate;
import org.springframework.web.servlet.view.mustache.MustacheTemplateFactory;
import org.springframework.web.servlet.view.mustache.MustacheView;
import org.springframework.web.servlet.view.mustache.MustacheViewResolver;
import org.springframework.web.servlet.view.mustache.java.MustacheJTemplateFactory;

public class NMustacheViewResolver extends MustacheViewResolver {

	public class MustacheViewResolver extends AbstractTemplateViewResolver
			implements ViewResolver
	{
		private MustacheTemplateFactory templateFactory;

		public MustacheViewResolver()
		{
			setViewClass(MustacheView.class);
		}

		@Override
		protected Class<?> requiredViewClass()
		{
			return MustacheView.class;
		}

		@Override
		protected AbstractUrlBasedView buildView(String viewName)
				throws Exception
		{
			MustacheView view = new MustacheView(); // (MustacheView) super.buildView(viewName);
			MustacheJTemplateFactory mustacheJTemplateFactory = new MustacheJTemplateFactory();
			MustacheTemplate template = mustacheJTemplateFactory.getTemplate(view.getUrl());
			view.setTemplate(template);

			return view;
		}

	}
}
