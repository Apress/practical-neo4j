package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedUserLocationRepository.MappedUserLocation;

@Controller
public class IntentController extends GraphStoryController {

	static Logger log = Logger.getLogger(IntentController.class);

	// purchases by friends
	@RequestMapping(value = "/intent", method = RequestMethod.GET)
	public String friendsPurchase(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser) {

		model.addAttribute("title", "Products Purchased by Friends");
		model.addAttribute("mappedProductUserPurchaseList", graphStoryInterface.getPurchaseInterface().friendsPurchase(currentuser.getUserId()));
		model.addAttribute("user", currentuser);

		return "/mustache/html/graphs/intent/index.html";
	}

	// x is friends with a,b,c who made purchase of product y
	// AKA friends bought this product
	@RequestMapping(value = "/intent/friendsPurchaseByProduct", method = RequestMethod.GET)
	public String friendsPurchaseByProduct(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser, @RequestParam(required = false) String producttitle) {

		model.addAttribute("title", "Specific Products Purchased by Friends");
		model.addAttribute("showForm", true);

		if (StringUtils.isBlank(producttitle)) {
			producttitle = "Star Wars Mimobot Thumb Drives";
		}

		model.addAttribute("mappedProductUserPurchaseList", graphStoryInterface.getPurchaseInterface().friendsPurchaseByProduct(currentuser.getUserId(), producttitle));
		model.addAttribute("user", currentuser);
		model.addAttribute("producttitle", producttitle);

		return "/mustache/html/graphs/intent/index.html";
	}

	// x is friends with a,b,c who made purchase of various products and x uses tags which one or more products has in common
	// AKA friends bought products. match these products to tags of the current user
	@RequestMapping(value = "/intent/friendsPurchaseTagSimilarity", method = RequestMethod.GET)
	public String friendsPurchaseTagSimilarity(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser) {
		model.addAttribute("title", "Products Purchased by Friends and Matches User's Tags");
		model.addAttribute("mappedProductUserPurchaseList", graphStoryInterface.getPurchaseInterface().friendsPurchaseTagSimilarity(currentuser.getUserId()));

		model.addAttribute("user", currentuser);

		return "/mustache/html/graphs/intent/index.html";
	}

	// x is friends with a,b,c who made purchase of product y. user x uses tags which product y has in common. x also lives within 10 miles of b
	// AKA friends that are nearby bought this product. the product also matches tags you use
	@RequestMapping(value = "/intent/friendsPurchaseTagSimilarityAndProximityToLocation", method = RequestMethod.GET)
	public String friendsPurchaseTagSimilarityAndProximityToLocation(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser) {
		model.addAttribute("title", "Products Purchased by Friends Nearby and Matches User's Tags");
		MappedUserLocation mappedUserLocation = graphStoryInterface.getUserInterface().getUserLocation(currentuser.getUsername());

		model.addAttribute("user", currentuser);
		model.addAttribute("mappedUserLocation", mappedUserLocation);

		model.addAttribute("mappedProductUserPurchaseList", graphStoryInterface.getPurchaseInterface().friendsPurchaseTagSimilarityAndProximityToLocation(
				mappedUserLocation.getLat(),
				mappedUserLocation.getLon(),
				new Double("10.00"),
				currentuser.getUserId()));

		return "/mustache/html/graphs/intent/index.html";
	}
}