package com.practicalneo4j.graphstory.domain;

import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.support.index.IndexType;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@NodeEntity
@TypeAlias("Product")
public class Product {

	@GraphId
	private Long nodeId;

	@Indexed
	private String productId; // this could also be a SKU or UPC

	private String title;

	private String description;

	private String tagstr;

	@Indexed(indexType = IndexType.FULLTEXT, indexName = "productcontent")
	private String content;

	private String price;

	@RelatedTo(type = GraphStoryConstants.HAS, direction = Direction.OUTGOING, elementClass = Tag.class)
	private Set<Tag> tags;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTagstr() {
		return tagstr;
	}

	public void setTagstr(String tagstr) {
		this.tagstr = tagstr;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Set<Tag> getTags() {
		return tags;
	}

	public void setTags(Set<Tag> tags) {
		this.tags = tags;
	}

}
