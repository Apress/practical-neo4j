package com.practicalneo4j.graphstory.repository;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.practicalneo4j.graphstory.repository.MappedProductSearchRespository.MappedProductSearch;

public interface MappedProductSearchRespository extends GraphRepository<MappedProductSearch> {

	@Query(value = "MATCH (p:Product) " +
			" WHERE lower(p.title) =~ {q} " +
			" RETURN count(*) as count, TOSTRING(ID(p)) as productNodeId, " +
			" p.title as name  " +
			" ORDER BY p.title LIMIT 5")
	Iterable<MappedProductSearch> search(@Param("q") String q);

	@QueryResult
	@JsonPropertyOrder(alphabetic = true)
	@NodeEntity
	public interface MappedProductSearch {

		@ResultColumn("productNodeId")
		String getId();

		@ResultColumn("name")
		String getLabel();

		@ResultColumn("count")
		String getName();
	}
}
