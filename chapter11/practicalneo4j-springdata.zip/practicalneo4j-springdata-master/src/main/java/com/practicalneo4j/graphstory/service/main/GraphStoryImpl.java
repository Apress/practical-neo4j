package com.practicalneo4j.graphstory.service.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service("graphStoryInterface")
@Scope("prototype")
public class GraphStoryImpl implements GraphStoryInterface {

	private ContentInterface contentInterface;

	private HelperInterface helperInterface;

	private LocationInterface locationInterface;

	private ProductInterface productInterface;

	private PurchaseInterface purchaseInterface;

	private TagInterface tagInterface;

	private UserInterface userInterface;

	@Autowired
	public GraphStoryImpl(ContentInterface contentInterface, HelperInterface helperInterface, LocationInterface locationInterface, ProductInterface productInterface, PurchaseInterface purchaseInterface, TagInterface tagInterface, UserInterface userInterface) {
		this.contentInterface = contentInterface;
		this.helperInterface = helperInterface;
		this.locationInterface = locationInterface;
		this.productInterface = productInterface;
		this.purchaseInterface = purchaseInterface;
		this.tagInterface = tagInterface;
		this.userInterface = userInterface;
	}

	@Override
	public ContentInterface getContentInterface() {
		return contentInterface;
	}

	@Override
	public void setContentInterface(ContentInterface contentInterface) {
		this.contentInterface = contentInterface;
	}

	@Override
	public HelperInterface getHelperInterface() {
		return helperInterface;
	}

	@Override
	public LocationInterface getLocationInterface() {
		return locationInterface;
	}

	@Override
	public void setLocationInterface(LocationInterface locationInterface) {
		this.locationInterface = locationInterface;
	}

	@Override
	public ProductInterface getProductInterface() {
		return productInterface;
	}

	@Override
	public void setProductInterface(ProductInterface productInterface) {
		this.productInterface = productInterface;
	}

	@Override
	public PurchaseInterface getPurchaseInterface() {
		return purchaseInterface;
	}

	@Override
	public void setPurchaseInterface(PurchaseInterface purchaseInterface) {
		this.purchaseInterface = purchaseInterface;
	}

	@Override
	public TagInterface getTagInterface() {
		return tagInterface;
	}

	@Override
	public void setTagInterface(TagInterface tagInterface) {
		this.tagInterface = tagInterface;
	}

	@Override
	public void setHelperInterface(HelperInterface helperInterface) {
		this.helperInterface = helperInterface;
	}

	@Override
	public UserInterface getUserInterface() {
		return userInterface;
	}

	@Override
	public void setUserInterface(UserInterface userInterface) {
		this.userInterface = userInterface;
	}

}
