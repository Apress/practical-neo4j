package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedUserLocationRepository.MappedUserLocation;

public interface UserInterface {

	public GraphStory save(GraphStory graphStory) throws Exception;

	public GraphStory login(GraphStory graphStory) throws Exception;

	public User getByUserName(String username) throws Exception;

	public User update(User user) throws Exception;

	public List<User> following(String username) throws Exception;

	public List<User> searchByUsername(String currentusername, String username) throws Exception;

	public void follow(String currentusername, String username) throws Exception;

	public void unfollow(String currentusername, String username) throws Exception;

	public MappedUserLocation getUserLocation(String currentusername);

}
