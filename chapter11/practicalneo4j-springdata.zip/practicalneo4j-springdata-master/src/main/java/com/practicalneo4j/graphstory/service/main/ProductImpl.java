package com.practicalneo4j.graphstory.service.main;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.neo4j.graphdb.Relationship;
import org.neo4j.helpers.collection.Iterables;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.practicalneo4j.graphstory.domain.Product;
import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedProductRepository.MappedProduct;
import com.practicalneo4j.graphstory.repository.MappedProductSearchRespository.MappedProductSearch;
import com.practicalneo4j.graphstory.repository.MappedProductUserTagRepository.MappedProductUserTag;
import com.practicalneo4j.graphstory.repository.MappedProductUserViewsRepository.MappedProductUserViews;
import com.practicalneo4j.graphstory.service.GraphStoryService;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Service("productInterface")
@Scope("prototype")
public class ProductImpl extends GraphStoryService implements ProductInterface {

	static Logger log = Logger.getLogger(ProductImpl.class);

	@Override
	public GraphStory getProducts(GraphStory graphStory, Integer pagenum) {

		Page<MappedProduct> products = mappedProductRepository.getProducts(new PageRequest(pagenum, 10, new Sort(Direction.ASC, "p.title")));
		graphStory.setProducts(products.getContent());
		graphStory.setNext(products.hasNext());
		return graphStory;

	}

	@Override
	public void createUserView(User user, Long productNodeId) {

		Product product = productRepository.findOne(productNodeId);

		try {
			Relationship r = neo4jTemplate.getRelationshipBetween(user, product, GraphStoryConstants.VIEWED);

			Long d = new Date().getTime() / 1000;

			Date timestamp = new Date(d * 1000);
			SimpleDateFormat dformatter = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat tformatter = new SimpleDateFormat("h:mm a");
			String timestampAsStr = dformatter.format(timestamp) + " at " + tformatter.format(timestamp);

			if (r == null) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("timestamp", d);
				map.put("dateAsStr", timestampAsStr);
				neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(user.getNodeId()), neo4jTemplate.getNode(productNodeId), GraphStoryConstants.VIEWED, map);
			} else {

				r.setProperty("timestamp", d);
				r.setProperty("dateAsStr", timestampAsStr);
				neo4jTemplate.save(r);
			}

		}
		catch (Exception e) {
			log.error(e);
		}

	}

	@Override
	public List<MappedProductUserViews> getProductTrail(String username) {
		return mappedProductUserViewsRepository.getProductTrail(username);
	}

	@Override
	// consumption filter for marketing (matching tags) / tag is optional
	public List<MappedProductUserTag> usersWithMatchingTags(String tag) {
		if (StringUtils.isNotBlank(tag)) {
			return mappedProductUserTagRepository.getProductsHasSpecificTagAndUserUsesSpecificTag(tag);
		} else {
			return mappedProductUserTagRepository.getProductsHasATagAndUserUsesAMatchingTag();
		}
	}

	@Override
	public MappedProductSearch[] search(String q) {
		q = q.trim().toLowerCase() + ".*";
		return Iterables.toArray(MappedProductSearch.class, mappedProductSearchRespository.search(q));
	}

}
