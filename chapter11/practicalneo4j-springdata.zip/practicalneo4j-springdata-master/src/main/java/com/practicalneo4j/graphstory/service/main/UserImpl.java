package com.practicalneo4j.graphstory.service.main;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedUserLocationRepository.MappedUserLocation;
import com.practicalneo4j.graphstory.service.GraphStoryService;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Service("userInterface")
@Scope("prototype")
public class UserImpl extends GraphStoryService implements UserInterface {

	static Logger log = Logger.getLogger(UserImpl.class);

	private User tempUser;

	@Override
	public GraphStory save(GraphStory graphStory) throws Exception {

		graphStory.getUser().setUsername(graphStory.getUser().getUsername().toLowerCase().trim());

		if (!userExists(graphStory.getUser())) {
			graphStory.setUser(userRepository.save(graphStory.getUser()));
		} else {
			addErrorMsg(graphStory, "The username you entered already exists.");
		}

		return graphStory;

	}

	@Override
	public GraphStory login(GraphStory graphStory) throws Exception {
		tempUser = userRepository.findByUsername(graphStory.getUser().getUsername());
		if (tempUser != null) {
			graphStory.setUser(tempUser);
		} else {
			addErrorMsg(graphStory, "The username you entered does not exist.");
		}

		return graphStory;
	}

	@Override
	public User getByUserName(String username) throws Exception {

		User u = userRepository.findByUsername(username);

		return u;
	}

	private boolean userExists(User user) throws Exception {
		boolean userFound = false;

		if (getByUserName(user.getUsername()) != null) {
			userFound = true;
		}

		return userFound;
	}

	@Override
	public User update(User user) throws Exception {
		user = userRepository.save(user);
		return user;
	}

	@Override
	public List<User> following(String username) throws Exception {
		LinkedList<User> following = userRepository.following(username);

		return following;
	}

	@Override
	public List<User> searchByUsername(String currentusername, String username) throws Exception {

		username = username.toLowerCase() + ".*";

		LinkedList<User> users = new LinkedList<User>(userRepository.searchByUsername(currentusername, username));
		return users;
	}

	@Override
	public void follow(String currentusername, String username) throws Exception {

		User cu = getByUserName(currentusername);
		User toFollow = getByUserName(username);

		neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(cu.getNodeId()), neo4jTemplate.getNode(toFollow.getNodeId()), GraphStoryConstants.FOLLOWS, null);
	}

	@Override
	public void unfollow(String currentusername, String username) throws Exception {
		User cu = getByUserName(currentusername);
		User toUnfollow = getByUserName(username);
		neo4jTemplate.deleteRelationshipBetween(cu, toUnfollow, GraphStoryConstants.FOLLOWS);
	}

	@Override
	public MappedUserLocation getUserLocation(String currentusername) {
		MappedUserLocation mappedUserLocation = null;
		List<MappedUserLocation> mappedUserLocations = mappedUserLocationRepository.getUserLocation(currentusername);

		if (mappedUserLocations.size() > 0) {
			mappedUserLocation = mappedUserLocations.get(0);
		}
		return mappedUserLocation;
	}
}
