package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class HomeController extends GraphStoryController {

	static Logger log = Logger.getLogger(HomeController.class);

	@RequestMapping(method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		model.addAttribute("title", "Home");

		return "/mustache/html/home/index.html";
	}

	@RequestMapping(value = "/msg", method = RequestMethod.GET)
	public String msg(@RequestParam(value = "msg", required = false) String msg, Locale locale, Model model) {
		model.addAttribute("title", "Tell Yours");
		if (msg != null) {
			model.addAttribute("msg", msg);
		}
		return "/mustache/html/home/message.html";
	}
}