package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.practicalneo4j.graphstory.repository.MappedProductUserPurchaseRepository.MappedProductUserPurchase;
import com.practicalneo4j.graphstory.service.GraphStoryService;

@Service("purchaseInterface")
@Scope("prototype")
public class PurchaseImpl extends GraphStoryService implements PurchaseInterface {

	static Logger log = Logger.getLogger(PurchaseImpl.class);

	@Override
	public List<MappedProductUserPurchase> friendsPurchase(String userId) {
		return mappedProductUserPurchaseRepository.friendsPurchase(userId);
	}

	@Override
	public List<MappedProductUserPurchase> friendsPurchaseByProduct(String userId, String title) {
		return mappedProductUserPurchaseRepository.friendsPurchaseByProduct(userId, title);
	}

	@Override
	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarity(String userId) {
		return mappedProductUserPurchaseRepository.friendsPurchaseTagSimilarity(userId);
	}

	@Override
	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarityAndProximityToLocation(Double lat, Double lon, Double distance, String userId) {
		return mappedProductUserPurchaseRepository.friendsPurchaseTagSimilarityAndProximityToLocation(userId, distanceQueryAsString(lat, lon, distance));
	}
}