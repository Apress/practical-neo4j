package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedProductSearchRespository.MappedProductSearch;
import com.practicalneo4j.graphstory.repository.MappedProductUserTagRepository.MappedProductUserTag;
import com.practicalneo4j.graphstory.repository.MappedProductUserViewsRepository.MappedProductUserViews;

public interface ProductInterface {

	// retrieve products
	public GraphStory getProducts(GraphStory graphStory, Integer pagenum);

	// capture views
	public void createUserView(User user, Long productNodeId);

	// product trail
	public List<MappedProductUserViews> getProductTrail(String username);

	// consumption filter for marketing (matching tags) / tag is optional
	public List<MappedProductUserTag> usersWithMatchingTags(String tag);

	// search products via string
	public MappedProductSearch[] search(String q);

}
