package com.practicalneo4j.graphstory.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.annotation.Transient;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@NodeEntity
@TypeAlias("Content")
public class Content {

	@GraphId
	private Long nodeId;

	@Indexed
	private String contentId;

	private String title;

	private String url;

	private String tagstr;

	private Long timestamp;

	@Transient
	private String userNameForPost;

	@Transient
	private String timestampAsStr;

	@RelatedTo(type = GraphStoryConstants.HAS, direction = Direction.OUTGOING, elementClass = Tag.class)
	@JsonInclude(Include.NON_NULL)
	private Set<Tag> tags;

	@RelatedTo(type = GraphStoryConstants.CURRENTPOST, direction = Direction.INCOMING, elementClass = User.class)
	@JsonIgnore
	private User user;

	@RelatedTo(type = GraphStoryConstants.NEXTPOST, direction = Direction.OUTGOING, elementClass = Content.class)
	@JsonIgnore
	private Content next;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTagstr() {
		return tagstr;
	}

	public void setTagstr(String tagstr) {
		this.tagstr = tagstr;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public Set<Tag> getTags() {
		return tags;
	}

	public void setTags(Set<Tag> tags) {
		this.tags = tags;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Content getNext() {
		return next;
	}

	public void setNext(Content next) {
		this.next = next;
	}

	public String getUserNameForPost() {
		return userNameForPost;
	}

	public void setUserNameForPost(String userNameForPost) {
		this.userNameForPost = userNameForPost;
	}

	public String getTimestampAsStr() {
		if (timestamp != null)
		{
			Date d = new Date(Long.valueOf(timestamp * 1000));
			SimpleDateFormat dformatter = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat tformatter = new SimpleDateFormat("h:mm a");
			timestampAsStr = dformatter.format(d) + " at " + tformatter.format(d);
		}
		return timestampAsStr;
	}
}
