package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.service.main.GraphStory;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Controller
public class UserController extends GraphStoryController {

	static Logger log = Logger.getLogger(UserController.class);

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String home(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser) {

		model.addAttribute("title", "User");

		model.addAttribute("user", currentuser);

		return "/mustache/html/graphs/social/user.html";
	}

	@RequestMapping(value = "/user/edit", method = RequestMethod.PUT)
	public @ResponseBody
	User edit(Model model, @ModelAttribute("currentuser") User currentuser, @RequestBody User jsonString) {

		try {

			if (jsonString != null) {
				currentuser.setFirstname(jsonString.getFirstname());
				currentuser.setLastname(jsonString.getLastname());
				currentuser = graphStoryInterface.getUserInterface().update(currentuser);
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return currentuser;
	}

	@RequestMapping(value = "/friends", method = RequestMethod.GET)
	public String friends(Locale locale, Model model, @CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String graphstoryUserAuthKey) {

		model.addAttribute("title", "Friends");

		try {
			model.addAttribute("following", graphStoryInterface.getUserInterface().following(graphstoryUserAuthKey));
		}
		catch (Exception e) {
			log.error(e);
		}

		return "/mustache/html/graphs/social/friends.html";
	}

	@RequestMapping(value = "/searchbyusername/{name}", method = RequestMethod.GET)
	public @ResponseBody
	GraphStory searchbyusername(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String graphstoryUserAuthKey, @PathVariable String name, Model model) {

		try {

			graphStory.setUsers(graphStoryInterface.getUserInterface().searchByUsername(graphstoryUserAuthKey, name));

		}
		catch (Exception e) {
			log.error(e);
		}
		return graphStory;
	}

	@RequestMapping(value = "/follow/{user}", method = RequestMethod.GET)
	public @ResponseBody
	GraphStory follow(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String graphstoryUserAuthKey, @PathVariable String user, Model model) {

		try {
			graphStoryInterface.getUserInterface().follow(graphstoryUserAuthKey, user);
			graphStory.setFollowing(graphStoryInterface.getUserInterface().following(graphstoryUserAuthKey));
		}
		catch (Exception e) {
			log.error(e);
		}
		return graphStory;
	}

	@RequestMapping(value = "/unfollow/{user}", method = RequestMethod.GET)
	public @ResponseBody
	GraphStory unfollow(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String graphstoryUserAuthKey, @PathVariable String user, Model model) {

		try {
			graphStoryInterface.getUserInterface().unfollow(graphstoryUserAuthKey, user);
			graphStory.setFollowing(graphStoryInterface.getUserInterface().following(graphstoryUserAuthKey));
		}
		catch (Exception e) {
			log.error(e);
		}

		return graphStory;
	}

}