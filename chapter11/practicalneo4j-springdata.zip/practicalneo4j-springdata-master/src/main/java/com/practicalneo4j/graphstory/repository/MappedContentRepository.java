package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.domain.pojo.MappedContent;

public interface MappedContentRepository extends GraphRepository<MappedContent> {
	@Query(" MATCH (u:User {username: {u} }) " +
			" WITH u " +
			" MATCH (u)-[:FOLLOWS*0..1]->f " +
			" WITH DISTINCT f,u " +
			" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..3]-p " +
			" RETURN p.contentId as contentId, p.title as title, p.tagstr as tagstr, p.timestamp as timestamp, p.url as url, f.username as username, f=u as owner ")
	Page<MappedContent> getContent(@Param("u") String username, Pageable pageable);

	@Query(" MATCH (u:User {username: {u} }) " +
			" WITH u " +
			" MATCH (u)-[:FOLLOWS*0..1]->f " +
			" WITH DISTINCT f,u " +
			" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p " +
			" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, p.timestamp as timestamp, p.url as url, f.username as username, f=u as owner" +
			" ORDER BY p.timestamp DESC" +
			" SKIP {skip} LIMIT 4")
	List<MappedContent> getContent(@Param("u") String username, @Param("skip") Integer skip);

	@Query("MATCH (u:User {username: {u} })" +
			" WITH u" +
			" MATCH (u)-[:FOLLOWS]->f" +
			" WITH DISTINCT f" +
			" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p" +
			" WITH DISTINCT f,p" +
			" MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" +
			" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
			" p.timestamp as timestamp, p.url as url, f.username as username, false as owner" +
			" ORDER BY p.timestamp DESC")
	List<MappedContent> getFollowingContentWithTag(@Param("u") String username, @Param("wp") String wordPhrase);

	@Query("MATCH (u:User {username: {u} })" +
			" MATCH u-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p " +
			" WITH DISTINCT u,p" +
			" MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" +
			" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
			" p.timestamp as timestamp, p.url as url, u.username as username, true as owner" +
			" ORDER BY p.timestamp DESC")
	List<MappedContent> getUserContentWithTag(@Param("u") String username, @Param("wp") String wordPhrase);

}