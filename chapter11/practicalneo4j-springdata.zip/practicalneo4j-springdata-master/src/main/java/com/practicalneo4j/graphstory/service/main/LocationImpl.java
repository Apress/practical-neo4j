package com.practicalneo4j.graphstory.service.main;

import java.text.DecimalFormat;
import java.util.List;

import org.apache.log4j.Logger;
import org.neo4j.graphdb.Relationship;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.practicalneo4j.graphstory.domain.Location;
import com.practicalneo4j.graphstory.domain.Product;
import com.practicalneo4j.graphstory.domain.pojo.MappedLocation;
import com.practicalneo4j.graphstory.service.GraphStoryService;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

@Service("locationInterface")
@Scope("prototype")
public class LocationImpl extends GraphStoryService implements LocationInterface {

	static Logger log = Logger.getLogger(LocationImpl.class);

	@Override
	public List<MappedLocation> returnLocationsWithinDistance(Double lat, Double lon, Double distance) {
		List<MappedLocation> locations = mappedLocationRepository.locationsWithinDistance(distanceQueryAsString(lat, lon, distance), "business");

		// add the distance in miles to locations
		addDistanceTo(locations, lat, lon);

		return locations;
	}

	@Override
	public GraphStory returnLocationsWithinDistanceAndHasProduct(GraphStory graphStory, Double lat, Double lon, Double distance, Long productNodeId) {

		List<MappedLocation> locations = mappedLocationRepository.locationsWithinDistanceWithProduct(distanceQueryAsString(lat, lon, distance), productNodeId);

		// add the distance in miles to locations
		addDistanceTo(locations, lat, lon);

		graphStory.setMappedLocations(locations);
		graphStory.setProduct(productRepository.findOne(productNodeId));

		return graphStory;
	}

	private void addDistanceTo(List<MappedLocation> locations, Double lat, Double lon) {

		for (MappedLocation location : locations) {
			location.setDistanceToLocation(distance(location.getLat(), location.getLon(), lat, lon, 'M'));
		}

	}

	private String distance(double lat1, double lon1, double lat2, double lon2, char unit) {

		StringBuilder distance = new StringBuilder();

		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);

		char K = 'K';
		char N = 'N';
		char M = 'M';

		if (unit == M) {
			dist = dist * 60 * 1.1515;
			DecimalFormat df = new DecimalFormat("#.00");
			distance.append(df.format(dist) + " Miles Away");
		}
		else if (unit == K) {
			dist = dist * 1.609344;
			distance.append(dist + "Kilometers Away");
		} else if (unit == N) {
			dist = dist * 0.8684;
			distance.append(dist + "Nautical Miles Away");
		}
		return distance.toString();
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::  This function converts decimal degrees to radians             :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::  This function converts radians to decimal degrees             :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}

	@Override
	public void addProductToLocation(Long locationNodeId, Long productNodeId) {

		Location location = locationRepository.findOne(locationNodeId);
		Product product = productRepository.findOne(productNodeId);
		Relationship r = neo4jTemplate.getRelationshipBetween(location, product, GraphStoryConstants.HAS);
		if (r == null) {
			neo4jTemplate.createRelationshipBetween(neo4jTemplate.getNode(location.getNodeId()), neo4jTemplate.getNode(productNodeId), GraphStoryConstants.HAS, null);
		}
	}

	@Override
	public void removeProductFromLocation(Long locationNodeId, Long productNodeId) {
		Location location = locationRepository.findOne(locationNodeId);
		Product product = productRepository.findOne(productNodeId);
		neo4jTemplate.deleteRelationshipBetween(location, product, GraphStoryConstants.HAS);
	}

	@Override
	public Location save(Location location) {

		location = locationRepository.save(location);

		ClientConfig clientConfig = new DefaultClientConfig();
		Client client = Client.create(clientConfig);
		//
		String nodeUrl = environment.getProperty("rootNeo4jServiceUrl") + GraphStoryConstants.nodepath + String.valueOf(location.getNodeId());
		String input = "{\"value\":\"dummy\",\"key\":\"dummy\", \"uri\":\"" + nodeUrl + "\"}";
		WebResource webResource = client.resource(environment.getProperty("rootNeo4jServiceUrl") + GraphStoryConstants.spatialIndexPath);
		ClientResponse response = webResource.accept("application/json").type("application/json").post(ClientResponse.class, input);

		return null;
	}

}
