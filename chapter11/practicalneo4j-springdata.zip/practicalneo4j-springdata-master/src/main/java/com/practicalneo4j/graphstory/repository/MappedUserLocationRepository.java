package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.repository.MappedUserLocationRepository.MappedUserLocation;

public interface MappedUserLocationRepository extends GraphRepository<MappedUserLocation> {

	@Query(" MATCH (u:User { username : {u} } )-[:HAS]-(l:Location) " +
			" RETURN u.username as username, l.address as address, l.city as city, l.state as state, l.zip as zip, l.lat as lat, l.lon as lon")
	List<MappedUserLocation> getUserLocation(@Param("u") String username);

	@QueryResult
	@NodeEntity
	public interface MappedUserLocation {

		@ResultColumn("username")
		String getUsername();

		@ResultColumn("address")
		String getAddress();

		@ResultColumn("city")
		String getCity();

		@ResultColumn("state")
		String getState();

		@ResultColumn("zip")
		String getZip();

		@ResultColumn("lat")
		Double getLat();

		@ResultColumn("lon")
		Double getLon();
	}

}
