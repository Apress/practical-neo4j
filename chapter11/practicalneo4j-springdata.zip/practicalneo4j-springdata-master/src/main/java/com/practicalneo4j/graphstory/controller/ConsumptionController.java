package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.service.main.GraphStory;

@Controller
public class ConsumptionController extends GraphStoryController {

	static Logger log = Logger.getLogger(ConsumptionController.class);

	// retrieve products & show content trail
	@RequestMapping(value = "/consumption", method = RequestMethod.GET)
	public String home(Locale locale, Model model, @ModelAttribute("currentuser") User currentuser) {
		model.addAttribute("title", "Consumption");
		try {
			graphStory = graphStoryInterface.getProductInterface().getProducts(graphStory, 0);

			graphStory.setProductTrail(graphStoryInterface.getProductInterface().getProductTrail(currentuser.getUsername()));

			model.addAttribute("products", graphStory.getProducts());
			model.addAttribute("next", graphStory.getNext());
			model.addAttribute("nextPageUrl", "/consumption/1");
			model.addAttribute("productTrail", graphStory.getProductTrail());
			model.addAttribute("currentuser", currentuser);

		}
		catch (Exception e) {
			log.error(e);
		}

		return "/mustache/html/graphs/consumption/index.html";
	}

	@RequestMapping(value = "/consumption/{pagenum}", method = RequestMethod.GET)
	public String nextProductPage(@PathVariable int pagenum, Locale locale, Model model) {
		try {
			graphStory = graphStoryInterface.getProductInterface().getProducts(graphStory, pagenum);

			model.addAttribute("products", graphStory.getProducts());
			model.addAttribute("next", graphStory.getNext());

			if (graphStory.getNext()) {
				pagenum = pagenum + 1;
				model.addAttribute("nextPageUrl", "/consumption/" + String.valueOf(pagenum));
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return "/mustache/html/graphs/consumption/product-list.html";
	}

	// capture product views

	@RequestMapping(value = "/consumption/add/{productNodeId}", method = RequestMethod.GET)
	public @ResponseBody
	GraphStory createUserProductViewRel(Model model, @ModelAttribute("currentuser") User currentuser, @PathVariable Long productNodeId) {
		try {
			// add a user view
			graphStory.setProducts(null);
			graphStoryInterface.getProductInterface().createUserView(currentuser, productNodeId);
			// pass back the list of products viewed
			graphStory.setProductTrail(graphStoryInterface.getProductInterface().getProductTrail(currentuser.getUsername()));
		}
		catch (Exception e) {
			log.error(e);
		}

		return graphStory;
	}

	// consumption filter for marketing (matching tags)
	@RequestMapping(value = "/consumption/console", method = RequestMethod.GET)
	public String usersWithMatchingTags(Locale locale, Model model, @RequestParam(required = false) String tag) {
		model.addAttribute("title", "Consumption Console");

		model.addAttribute("usersWithMatchingTags", graphStoryInterface.getProductInterface().usersWithMatchingTags(tag));

		return "/mustache/html/graphs/consumption/console.html";
	}
}
