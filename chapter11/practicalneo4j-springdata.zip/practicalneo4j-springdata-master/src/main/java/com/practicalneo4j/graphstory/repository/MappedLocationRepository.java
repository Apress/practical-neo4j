package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.domain.pojo.MappedLocation;

public interface MappedLocationRepository extends GraphRepository<MappedLocation> {

	@Query("START n = node:geom({lq}) WHERE n.type = {locationType} " +
			" RETURN n.locationId as locationId, n.address as address, n.city as city, n.state as state, n.zip as zip, n.name as name, n.lat as lat, n.lon as lon")
	List<MappedLocation> locationsWithinDistance(@Param("lq") String lq, @Param("locationType") String locationType);

	@Query("START n = node:geom({lq}), p=node({productNodeId})" +
			" MATCH n-[:HAS]->p " +
			" RETURN n.locationId as locationId, n.address as address, n.city as city, n.state as state, n.zip as zip, n.name as name, n.lat as lat, n.lon as lon ")
	List<MappedLocation> locationsWithinDistanceWithProduct(@Param("lq") String lq, @Param("productNodeId") Long productNodeId);

}
