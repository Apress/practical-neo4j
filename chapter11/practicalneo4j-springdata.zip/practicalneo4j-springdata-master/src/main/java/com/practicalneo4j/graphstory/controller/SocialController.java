package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practicalneo4j.graphstory.domain.Content;
import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.service.main.GraphStory;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Controller
public class SocialController extends GraphStoryController {

	static Logger log = Logger.getLogger(SocialController.class);

	private static final int pagesize = 3;

	// retrieve content based on user
	@RequestMapping(value = { "/social" }, method = RequestMethod.GET)
	public String home(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String username, Locale locale, Model model) {
		model.addAttribute("title", "Social");

		try {
			graphStory = graphStoryInterface.getContentInterface().getContent(graphStory, username, 0, pagesize);
			model.addAttribute("content", graphStory.getContent());
			model.addAttribute("morecontent", graphStory.getNext());

		}
		catch (Exception e) {
			log.error(e);
		}

		return "/mustache/html/graphs/social/posts.html";
	}

	@RequestMapping(value = "/postsfeed/{pagenum}", method = RequestMethod.GET)
	public @ResponseBody
	GraphStory postsfeed(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String username, @PathVariable int pagenum) {
		try {
			graphStory = graphStoryInterface.getContentInterface().getContent(graphStory, username, pagenum, pagesize);
		}
		catch (Exception e) {
			log.error(e);
		}
		return graphStory;
	}

	// get item
	@RequestMapping(value = { "/viewpost/{contentId}" }, method = RequestMethod.GET)
	public String viewpost(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String username, Locale locale, Model model, @PathVariable String contentId) {
		model.addAttribute("title", "Social");
		try {
			model.addAttribute("content", graphStoryInterface.getContentInterface().getContentItem(contentId));
		}
		catch (Exception e) {
			log.error(e);
		}

		return "/mustache/html/graphs/social/post.html";
	}

	// add & tag my content
	@RequestMapping(value = "/posts/add", method = RequestMethod.POST)
	public @ResponseBody
	Content add(Model model, @ModelAttribute("currentuser") User currentuser, @RequestBody Content jsonObj) {
		try {
			if (jsonObj != null) {
				if (StringUtils.isNotBlank(jsonObj.getTagstr())) {
					jsonObj.setTags(graphStoryInterface.getTagInterface().saveTags(jsonObj.getTagstr()));
				}
				jsonObj = graphStoryInterface.getContentInterface().add(jsonObj, currentuser);
				jsonObj.setUserNameForPost(currentuser.getUsername());
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return jsonObj;
	}

	// edit & tag my content
	@RequestMapping(value = "/posts/edit", method = RequestMethod.PUT)
	public @ResponseBody
	Content edit(Model model, @ModelAttribute("currentuser") User currentuser, @RequestBody Content jsonObj) {

		try {
			if (jsonObj != null) {
				if (StringUtils.isNotBlank(jsonObj.getTagstr())) {
					jsonObj.setTags(graphStoryInterface.getTagInterface().saveTags(jsonObj.getTagstr()));
				} else {
					jsonObj.setTags(null);
				}
				jsonObj = graphStoryInterface.getContentInterface().edit(jsonObj, currentuser);
				jsonObj.setUserNameForPost(currentuser.getUsername());
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return jsonObj;
	}

	// delete my content
	@RequestMapping(value = { "/posts/delete/{contentId}" }, method = RequestMethod.GET)
	public @ResponseBody
	void delete(@ModelAttribute("currentuser") User currentuser, Locale locale, Model model, @PathVariable String contentId) {
		try {
			graphStoryInterface.getContentInterface().delete(contentId, currentuser);
		}
		catch (Exception e) {
			log.error(e);
		}

	}

}
