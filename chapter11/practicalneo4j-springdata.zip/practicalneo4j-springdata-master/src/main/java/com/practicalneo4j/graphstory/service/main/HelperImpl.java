package com.practicalneo4j.graphstory.service.main;

import javax.servlet.http.Cookie;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.practicalneo4j.graphstory.service.GraphStoryService;

@Service("helperInterface")
@Scope("prototype")
public class HelperImpl extends GraphStoryService implements HelperInterface {

	static Logger log = Logger.getLogger(HelperImpl.class);

	public final static String ROOTPATH = "/";

	public final static int dayexpiry = 24 * 60 * 60;

	public final static int twoWeekExpiry = 14 * dayexpiry;

	@Override
	public Cookie addCookie(String name, String value) {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(ROOTPATH);
		cookie.setMaxAge(twoWeekExpiry);
		return cookie;
	}

	@Override
	public Cookie removeCookie(String name) {
		Cookie cookie = new Cookie(name, "");
		cookie.setPath(ROOTPATH);
		cookie.setMaxAge(0);
		return cookie;
	}

}
