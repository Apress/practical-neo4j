package com.practicalneo4j.graphstory.service.main;

import javax.servlet.http.Cookie;

public interface HelperInterface {

	public Cookie addCookie(String name, String value);

	public Cookie removeCookie(String name);

}
