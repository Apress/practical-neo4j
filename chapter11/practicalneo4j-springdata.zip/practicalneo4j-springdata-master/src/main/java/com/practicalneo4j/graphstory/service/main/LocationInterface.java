package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import com.practicalneo4j.graphstory.domain.Location;
import com.practicalneo4j.graphstory.domain.pojo.MappedLocation;

public interface LocationInterface {

	// filter locations within distance
	public List<MappedLocation> returnLocationsWithinDistance(Double lat, Double lon, Double distance);

	// filter locations within distance that have product
	public GraphStory returnLocationsWithinDistanceAndHasProduct(GraphStory graphStory, Double lat, Double lon, Double distance, Long productNodeId);

	// connect products to location
	public void addProductToLocation(Long locationNodeId, Long productNodeId);

	// connect products to location
	public void removeProductFromLocation(Long locationNodeId, Long productNodeId);

	// create/edit location
	public Location save(Location location);

}
