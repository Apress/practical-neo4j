package com.practicalneo4j.graphstory.domain;

import org.springframework.data.annotation.Transient;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
@TypeAlias("Tag")
public class Tag {

	public Tag() {

	}

	public Tag(String wordPhrase) {
		this.setWordPhrase(wordPhrase);
	}

	@GraphId
	private Long nodeId;

	@Indexed(unique = true)
	private String wordPhrase;

	@Transient
	private Integer tagCount;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getWordPhrase() {
		return wordPhrase;
	}

	public void setWordPhrase(String wordPhrase) {
		this.wordPhrase = wordPhrase;
	}

	public Integer getTagCount() {
		return tagCount;
	}

	public void setTagCount(Integer tagCount) {
		this.tagCount = tagCount;
	}
}
