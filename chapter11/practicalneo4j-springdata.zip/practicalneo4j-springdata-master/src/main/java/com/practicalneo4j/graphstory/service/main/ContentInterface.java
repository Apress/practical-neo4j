package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import com.practicalneo4j.graphstory.domain.Content;
import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.domain.pojo.MappedContent;

public interface ContentInterface {

	// retrieve content based on user
	public GraphStory getContent(GraphStory graphStory, String username, Integer page, Integer pagesize);

	public List<MappedContent> getContentByTag(String username, String tag, Boolean getuserscontent);

	// get item
	public Content getContentItem(String contentId);

	// add content
	public Content add(Content content, User user);

	// edit my content
	public Content edit(Content content, User user);

	// delete my content
	public void delete(String contentId, User user);

}
