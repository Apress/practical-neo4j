package com.practicalneo4j.graphstory.util;

import org.springframework.web.servlet.view.mustache.MustacheTemplate;
import org.springframework.web.servlet.view.mustache.MustacheTemplateException;
import org.springframework.web.servlet.view.mustache.java.MustacheJTemplate;
import org.springframework.web.servlet.view.mustache.java.MustacheJTemplateFactory;

import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheException;
import com.google.common.util.concurrent.UncheckedExecutionException;

public class NMustacheJTemplateFactory extends MustacheJTemplateFactory {

	@Override
	public MustacheTemplate getTemplate(String templateURL) throws MustacheTemplateException {

		return new MustacheJTemplate(compile(templateURL));

	}

	@Override
	public Mustache compile(String name)
	{
		try {
			Mustache mustache = mc.compile(name);
			mustache.init();
			return mustache;
		}
		catch (UncheckedExecutionException e) {
			throw handle(e);
		}
	}

	private MustacheException handle(Exception e) {
		Throwable cause = e.getCause();
		if (cause instanceof MustacheException) {
			return ((MustacheException) cause);
		}
		return new MustacheException(cause);
	}
}
