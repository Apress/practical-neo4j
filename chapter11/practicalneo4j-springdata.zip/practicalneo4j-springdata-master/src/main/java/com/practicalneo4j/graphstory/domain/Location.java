package com.practicalneo4j.graphstory.domain;

import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.annotation.Transient;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@NodeEntity
@TypeAlias("Location")
public class Location {

	@GraphId
	private Long nodeId;

	@Indexed
	private String locationId;

	private String name;

	private String address;

	private String city;

	private String state;

	private String zip;

	private Double lat;

	private Double lon;

	@RelatedTo(type = GraphStoryConstants.HAS, direction = Direction.OUTGOING, elementClass = Product.class)
	private Set<Product> products;

	@Transient
	private String distanceToLocation;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public Double getLat() {
		return lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}

	public Double getLon() {
		return lon;
	}

	public void setLon(Double lon) {
		this.lon = lon;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	public String getDistanceToLocation() {
		return distanceToLocation;
	}

	public void setDistanceToLocation(String distanceToLocation) {
		this.distanceToLocation = distanceToLocation;
	}

}
