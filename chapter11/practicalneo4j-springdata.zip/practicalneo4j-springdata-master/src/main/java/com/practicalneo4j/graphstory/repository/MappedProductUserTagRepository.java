package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.repository.MappedProductUserTagRepository.MappedProductUserTag;

public interface MappedProductUserTagRepository extends GraphRepository<MappedProductUserTag> {

	@Query("MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User)	" +
			" RETURN p.title as title, collect(u.username) as u, collect(distinct t.wordPhrase) as t ")
	List<MappedProductUserTag> getProductsHasATagAndUserUsesAMatchingTag();
	
	@Query("MATCH (t:Tag { wordPhrase: {wp} }) " +
			"WITH t " +
			"MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) " +
			"RETURN p.title as title,collect(u) as u, collect(distinct t) as t ")
	List<MappedProductUserTag> getProductsHasSpecificTagAndUserUsesSpecificTag(@Param("wp") String wp);

	@QueryResult
	@NodeEntity
	public interface MappedProductUserTag {

		@ResultColumn("title")
		String getTitle();

		@ResultColumn("u")
		List<String> getUsers();

		@ResultColumn("t")
		List<String> getTags();
	}
}
