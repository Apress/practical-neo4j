package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.repository.MappedContentTagRepository.MappedContentTag;

@Controller
public class InterestController extends GraphStoryController {

	static Logger log = Logger.getLogger(InterestController.class);

	// interest main page - includes user's tags & tags of the people the user is following
	@RequestMapping(value = { "/interest", "/interest/home" }, method = RequestMethod.GET)
	public String view(@ModelAttribute("currentuser") User currentuser, Locale locale, Model model, @RequestParam(required = false) String tag, @RequestParam(required = false) Boolean userscontent) {
		model.addAttribute("title", "Interest");
		graphStory.setUser(currentuser);
		graphStory = graphStoryInterface.getTagInterface().tagsInMyNetwork(graphStory);

		if (StringUtils.isNotBlank(tag)) {
			model.addAttribute("content", graphStoryInterface.getContentInterface().getContentByTag(currentuser.getUsername(), tag, userscontent));
		}

		model.addAttribute("tagsInNetwork", graphStory.getTagsInNetwork());
		model.addAttribute("usersTags", graphStory.getUserTags());

		return "/mustache/html/graphs/interest/index.html";
	}

	// retrieve tags via auto suggest
	@RequestMapping(value = "/tag/{q}", method = RequestMethod.GET)
	public @ResponseBody
	MappedContentTag[] tagSearch(@PathVariable String q, Model model) {
		MappedContentTag[] mappedTags = null;
		try {
			mappedTags = graphStoryInterface.getTagInterface().search(q);

		}
		catch (Exception e) {
			log.error(e);
		}
		return mappedTags;
	}

}
