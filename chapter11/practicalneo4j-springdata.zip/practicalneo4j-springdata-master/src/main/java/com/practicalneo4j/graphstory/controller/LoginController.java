package com.practicalneo4j.graphstory.controller;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.practicalneo4j.graphstory.service.main.GraphStory;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Controller
public class LoginController extends GraphStoryController {

	static Logger log = Logger.getLogger(LoginController.class);

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@ModelAttribute("graphStory") GraphStory graphStory, HttpServletResponse response) {

		ModelAndView modelAndView;

		try {
			graphStory = graphStoryInterface.getUserInterface().login(graphStory);

			if (CollectionUtils.isEmpty(graphStory.getErrorMsgs())) {
				response.addCookie(graphStoryInterface.getHelperInterface().addCookie(GraphStoryConstants.graphstoryUserAuthKey, graphStory.getUser().getUsername()));
				modelAndView = new ModelAndView("redirect:/social");
			} else {
				modelAndView = new ModelAndView("/mustache/html/home/message.html");
				modelAndView.addObject("title", "Tell Yours");
				modelAndView.addObject(graphStory.getErrorMsgs());
			}
			return modelAndView;

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}

}
