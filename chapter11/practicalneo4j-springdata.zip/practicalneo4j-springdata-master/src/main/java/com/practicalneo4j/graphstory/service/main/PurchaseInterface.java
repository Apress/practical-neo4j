package com.practicalneo4j.graphstory.service.main;

import java.util.List;

import com.practicalneo4j.graphstory.repository.MappedProductUserPurchaseRepository.MappedProductUserPurchase;

public interface PurchaseInterface {

	public List<MappedProductUserPurchase> friendsPurchase(String userId);

	public List<MappedProductUserPurchase> friendsPurchaseByProduct(String userId, String title);

	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarity(String userId);

	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarityAndProximityToLocation(Double lat, Double lon, Double distance, String userId);
}
