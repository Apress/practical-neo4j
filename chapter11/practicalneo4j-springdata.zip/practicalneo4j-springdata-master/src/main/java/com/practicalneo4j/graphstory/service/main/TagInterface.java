package com.practicalneo4j.graphstory.service.main;

import java.util.Set;

import com.practicalneo4j.graphstory.domain.Tag;
import com.practicalneo4j.graphstory.repository.MappedContentTagRepository.MappedContentTag;

public interface TagInterface {

	// save tags from content
	public Set<Tag> saveTags(String tagText);

	// save a tag
	public Tag save(String tag);

	public MappedContentTag[] search(String q);

	// count tags in aggregate
	public GraphStory tagsInMyNetwork(GraphStory graphStory);

}
