package com.practicalneo4j.graphstory.service.main;

import java.io.Serializable;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.practicalneo4j.graphstory.domain.Product;
import com.practicalneo4j.graphstory.domain.User;
import com.practicalneo4j.graphstory.domain.pojo.MappedContent;
import com.practicalneo4j.graphstory.domain.pojo.MappedLocation;
import com.practicalneo4j.graphstory.repository.MappedContentTagRepository.MappedContentTag;
import com.practicalneo4j.graphstory.repository.MappedProductRepository.MappedProduct;
import com.practicalneo4j.graphstory.repository.MappedProductUserViewsRepository.MappedProductUserViews;

@Service("graphStory")
@Scope("prototype")
public class GraphStory implements Serializable {

	@JsonIgnore
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_NULL)
	private User user;

	@JsonInclude(Include.NON_NULL)
	public String title;

	@JsonInclude(Include.NON_NULL)
	private List<String> errorMsgs;

	@JsonInclude(Include.NON_NULL)
	private List<User> users;

	@JsonInclude(Include.NON_NULL)
	private List<User> following;

	@JsonInclude(Include.NON_NULL)
	private List<MappedContent> content;

	@JsonInclude(Include.NON_NULL)
	private Boolean next;

	@JsonInclude(Include.NON_NULL)
	private String nextPageUrl;

	@JsonInclude(Include.NON_NULL)
	private List<MappedContentTag> tagsInNetwork;

	@JsonInclude(Include.NON_NULL)
	private List<MappedContentTag> userTags;

	@JsonInclude(Include.NON_NULL)
	private List<MappedProduct> products;

	@JsonInclude(Include.NON_NULL)
	private List<MappedProductUserViews> productTrail;

	@JsonInclude(Include.NON_NULL)
	private List<MappedLocation> mappedLocations;

	@JsonInclude(Include.NON_NULL)
	private Product product;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<String> getErrorMsgs() {
		return errorMsgs;
	}

	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<User> getFollowing() {
		return following;
	}

	public void setFollowing(List<User> following) {
		this.following = following;
	}

	public List<MappedContent> getContent() {
		return content;
	}

	public void setContent(List<MappedContent> content) {
		this.content = content;
	}

	public Boolean getNext() {
		return next;
	}

	public void setNext(Boolean next) {
		this.next = next;
	}

	public String getNextPageUrl() {
		return nextPageUrl;
	}

	public void setNextPageUrl(String nextPageUrl) {
		this.nextPageUrl = nextPageUrl;
	}

	public List<MappedContentTag> getTagsInNetwork() {
		return tagsInNetwork;
	}

	public void setTagsInNetwork(List<MappedContentTag> tagsInNetwork) {
		this.tagsInNetwork = tagsInNetwork;
	}

	public List<MappedContentTag> getUserTags() {
		return userTags;
	}

	public void setUserTags(List<MappedContentTag> userTags) {
		this.userTags = userTags;
	}

	public List<MappedProduct> getProducts() {
		return products;
	}

	public void setProducts(List<MappedProduct> products) {
		this.products = products;
	}

	public List<MappedProductUserViews> getProductTrail() {
		return productTrail;
	}

	public void setProductTrail(List<MappedProductUserViews> productTrail) {
		this.productTrail = productTrail;
	}

	public List<MappedLocation> getMappedLocations() {
		return mappedLocations;
	}

	public void setMappedLocations(List<MappedLocation> mappedLocations) {
		this.mappedLocations = mappedLocations;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
