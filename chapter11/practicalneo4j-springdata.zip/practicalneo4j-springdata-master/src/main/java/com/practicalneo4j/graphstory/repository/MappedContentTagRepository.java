package com.practicalneo4j.graphstory.repository;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.practicalneo4j.graphstory.repository.MappedContentTagRepository.MappedContentTag;

public interface MappedContentTagRepository extends GraphRepository<MappedContentTag> {

	@Query(value = "MATCH (c:Content)-[:HAS]->(t:Tag) WHERE t.wordPhrase =~ {q} RETURN t.wordPhrase as name, count(*) as count ORDER BY t.wordPhrase LIMIT 5")
	Iterable<MappedContentTag> search(@Param("q") String q);

	@Query("START u=node({nodeId})" +
			" MATCH u-[:FOLLOWS]->f " +
			" WITH distinct f " +
			" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
			" WITH distinct c " +
			" MATCH c-[ct:HAS]->(t) " +
			" WITH distinct ct,t " +
			" RETURN t.wordPhrase as name, count(ct) as count " +
			" ORDER BY count desc " +
			" SKIP 0 LIMIT 30")
	Iterable<MappedContentTag> tagsInNetwork(@Param("nodeId") Long nodeId);

	@Query("START u=node({nodeId})" +
			" MATCH u-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
			" WITH distinct c " +
			" MATCH c-[ct:HAS]->(t) " +
			" WITH distinct ct,t " +
			" RETURN t.wordPhrase as name, count(ct) as count " +
			" ORDER BY count desc " +
			" SKIP 0 LIMIT 30")
	Iterable<MappedContentTag> userTags(@Param("nodeId") Long nodeId);

	@QueryResult
	@JsonPropertyOrder(alphabetic = true)
	@NodeEntity
	public interface MappedContentTag {

		@ResultColumn("count")
		String getId();

		@ResultColumn("name")
		String getLabel();

		@ResultColumn("name")
		String getName();
	}
}
