package com.practicalneo4j.graphstory.repository;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.domain.Content;

public interface ContentRepository extends GraphRepository<Content> {

	Content findByContentId(String contentId);

	@Query("START user=node({nodeId}) MATCH user-[:CURRENTPOST]->content RETURN content")
	Content currentpost(@Param("nodeId") Long nodeId);

	@Query("START user=node({nodeId}) MATCH content-[:NEXTPOST]->user RETURN content")
	Content prevpost(@Param("nodeId") Long nodeId);
}
