package com.practicalneo4j.graphstory.controller;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.practicalneo4j.graphstory.service.main.GraphStory;

@Controller
public class SignupController extends GraphStoryController {

	static Logger log = Logger.getLogger(SignupController.class);

	@RequestMapping(value = "/signup/add", method = RequestMethod.POST)
	public ModelAndView addUser(@ModelAttribute("graphStory") GraphStory graphStory) {

		ModelAndView modelAndView;

		try {
			graphStory = graphStoryInterface.getUserInterface().save(graphStory);

			if (CollectionUtils.isEmpty(graphStory.getErrorMsgs())) {
				modelAndView = new ModelAndView("redirect:/msg");

				modelAndView.addObject("msg", "Thank you, " + graphStory.getUser().getUsername());
			} else {
				modelAndView = new ModelAndView("/mustache/html/home/index.html");
				modelAndView.addObject("title", "Home");
				modelAndView.addObject(graphStory.getErrorMsgs());
			}
			return modelAndView;

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}
}
