package com.practicalneo4j.graphstory.domain;

import java.util.Date;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@NodeEntity
@TypeAlias("Purchase")
public class Purchase {

	@GraphId
	private Long nodeId;

	@Indexed
	private String purchaseId;

	@RelatedTo(type = GraphStoryConstants.CONTAINS, direction = Direction.OUTGOING, elementClass = Product.class)
	private Set<Product> products;

	private Date timestamp;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(String purchaseId) {
		this.purchaseId = purchaseId;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

}
