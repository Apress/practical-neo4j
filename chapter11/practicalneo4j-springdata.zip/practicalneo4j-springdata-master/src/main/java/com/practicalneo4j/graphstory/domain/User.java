package com.practicalneo4j.graphstory.domain;

import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@NodeEntity
@TypeAlias("User")
public class User {

	@GraphId
	private Long nodeId;

	@Indexed
	private String userId;

	@Indexed
	// uses CREATE INDEX ON :User(username);
	private String username;

	private String firstname;

	private String lastname;

	@RelatedTo(type = GraphStoryConstants.MADE, direction = Direction.OUTGOING, elementClass = Purchase.class)
	private Purchase purchase;

	@RelatedTo(type = GraphStoryConstants.USES, direction = Direction.OUTGOING, elementClass = Tag.class)
	private Set<Tag> tags;

	@RelatedTo(type = GraphStoryConstants.HAS, direction = Direction.OUTGOING, elementClass = Location.class)
	private Set<Location> locations;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Purchase getPurchase() {
		return purchase;
	}

	public void setPurchase(Purchase purchase) {
		this.purchase = purchase;
	}

	public Set<Tag> getTags() {
		return tags;
	}

	public void setTags(Set<Tag> tags) {
		this.tags = tags;
	}

	public Set<Location> getLocations() {
		return locations;
	}

	public void setLocations(Set<Location> locations) {
		this.locations = locations;
	}

}