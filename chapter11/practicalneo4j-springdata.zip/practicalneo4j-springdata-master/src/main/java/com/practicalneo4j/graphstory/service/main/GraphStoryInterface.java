package com.practicalneo4j.graphstory.service.main;

public interface GraphStoryInterface {

	public ContentInterface getContentInterface();

	public void setContentInterface(ContentInterface contentInterface);

	public HelperInterface getHelperInterface();

	public void setHelperInterface(HelperInterface helperInterface);

	public LocationInterface getLocationInterface();

	public void setLocationInterface(LocationInterface locationInterface);

	public ProductInterface getProductInterface();

	public void setProductInterface(ProductInterface productInterface);

	public PurchaseInterface getPurchaseInterface();

	public void setPurchaseInterface(PurchaseInterface purchaseInterface);

	public TagInterface getTagInterface();

	public void setTagInterface(TagInterface tagInterface);

	public UserInterface getUserInterface();

	public void setUserInterface(UserInterface userInterface);

}
