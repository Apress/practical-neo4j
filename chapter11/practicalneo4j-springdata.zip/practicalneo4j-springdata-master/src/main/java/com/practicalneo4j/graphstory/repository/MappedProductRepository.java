package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.repository.MappedProductRepository.MappedProduct;

public interface MappedProductRepository extends GraphRepository<MappedProduct> {

	@Query("MATCH (p:Product) RETURN ID(p) as nodeId, p.title as title, p.description as description, p.tagstr  as tagstr")
	Page<MappedProduct> getProducts(Pageable pageable);

	@Query("MATCH (t:Tag { wordPhrase: {wp} }) " +
			" WITH t " +
			" MATCH (p:Product)-[:HAS]->(t)  " +
			" RETURN ID(p) as nodeId, p.title as title, p.description as description, p.tagstr  as tagstr")
	List<MappedProduct> getProductsHasTag(@Param("wp") String wp);

	@Query("MATCH (t:Tag { wordPhrase: {wp} }),(u:User { username: {username} })  " +
			" WITH t,u " +
			" MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u)   " +
			" RETURN ID(p) as nodeId, p.title, p.description, p.tagstr ")
	List<MappedProduct> getProductsHasTagAndUserUsesTag(@Param("wp") String wp, @Param("username") String username);

	@QueryResult
	@NodeEntity
	public interface MappedProduct {

		@ResultColumn("nodeId")
		String getNodeId();

		@ResultColumn("title")
		String getTitle();

		@ResultColumn("description")
		String getDescription();

		@ResultColumn("tagstr")
		String getTagstr();

	}

}
