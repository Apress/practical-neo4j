package com.practicalneo4j.graphstory.repository;

import org.springframework.data.neo4j.repository.GraphRepository;

import com.practicalneo4j.graphstory.domain.Purchase;

public interface PurchaseRepository extends GraphRepository<Purchase> {

}
