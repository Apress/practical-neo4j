package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.repository.MappedProductUserPurchaseRepository.MappedProductUserPurchase;

public interface MappedProductUserPurchaseRepository extends GraphRepository<MappedProductUserPurchase> {

	// purchases by friends
	@Query("MATCH (u:User { userId : {userId} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " +
			" RETURN p.productId as productId, " +
			" p.title as title, " +
			" collect(f.firstname + ' ' + f.lastname) as fullname, " +
			" null as wordPhrase, " +
			" count(f) as cfriends " +
			" ORDER BY cfriends desc, p.title ")
	List<MappedProductUserPurchase> friendsPurchase(@Param("userId") String userId);

	// userId is friends with a,b,c who made purchase of product title
	// AKA friends bought this product
	@Query("MATCH (p:Product) " +
			" WHERE lower(p.title) =lower({title}) " +
			" WITH p " +
			" MATCH (u:User { userId : {userId} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->(p) " +
			" RETURN p.productId as productId,  " +
			" p.title as title, " +
			" collect(f.firstname + ' ' + f.lastname) as fullname, " +
			" null as wordPhrase, count(f) as cfriends " +
			"ORDER BY cfriends desc, p.title ")
	List<MappedProductUserPurchase> friendsPurchaseByProduct(@Param("userId") String userId, @Param("title") String title);

	// x is friends with a,b,c who made purchase of various products and x uses tags which one or more products has in common
	// AKA friends bought products. match these products to tags of the current user
	@Query("MATCH (u:User { userId : {userId} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " +
			" WITH u,p,f " +
			" MATCH u-[:USES]->(t)<-[:HAS]-p " +
			" RETURN p.productId as productId,  " +
			" p.title as title, " +
			" collect(f.firstname + ' ' + f.lastname) as fullname, " +
			" t.wordPhrase as wordPhrase, " +
			" count(f) as cfriends " +
			" ORDER BY cfriends desc, p.title ")
	List<MappedProductUserPurchase> friendsPurchaseTagSimilarity(@Param("userId") String userId);

	// x is friends with a,b,c who made purchase of product y. user x uses tags which product y has in common. x also lives within 10 miles of b
	// AKA friends that are nearby bought this product. the product also matches tags you use
	@Query("START n = node:geom({lq}) " +
			" WITH n " +
			" MATCH (u:User { userId : {userId} } )-[:USES]->(t)<-[:HAS]-p " +
			" WITH n,u,p,t " +
			" MATCH u-[:FOLLOWS]->(f)-[:HAS]->(n) " +
			" WITH p,f,t " +
			" MATCH f-[:MADE]->()-[:CONTAINS]->(p) " +
			" RETURN p.productId as productId, " +
			" p.title as title, " +
			" collect(f.firstname + ' ' + f.lastname) as fullname, " +
			" t.wordPhrase as wordPhrase, " +
			" count(f) as cfriends " +
			" ORDER BY cfriends desc, p.title ")
	List<MappedProductUserPurchase> friendsPurchaseTagSimilarityAndProximityToLocation(@Param("userId") String userId, @Param("lq") String lq);

	@QueryResult
	@NodeEntity
	public interface MappedProductUserPurchase {

		@ResultColumn("productId")
		String getProductId();

		@ResultColumn("title")
		String getTitle();

		@ResultColumn("fullname")
		List<String> getFullname();

		@ResultColumn("wordPhrase")
		String getWordPhrase();

		@ResultColumn("cfriends")
		Integer getCfriends();
	}
}
