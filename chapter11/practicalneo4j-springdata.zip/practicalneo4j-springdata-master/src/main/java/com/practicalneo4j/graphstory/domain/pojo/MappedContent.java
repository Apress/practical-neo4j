package com.practicalneo4j.graphstory.domain.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;

@QueryResult
@NodeEntity
public class MappedContent {

	@GraphId
	private Long nodeId;

	@ResultColumn("contentId")
	private String contentId;

	@ResultColumn("title")
	private String title;

	@ResultColumn("url")
	private String url;

	@ResultColumn("tagstr")
	private String tagstr;

	@ResultColumn("timestamp")
	private Long timestamp;

	@ResultColumn("username")
	private String userNameForPost;

	private String timestampAsStr;

	@ResultColumn("owner")
	private Boolean owner;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTagstr() {
		return tagstr;
	}

	public void setTagstr(String tagstr) {
		this.tagstr = tagstr;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public String getTimestampAsStr() {
		if (timestamp != null)
		{
			Date d = new Date(Long.valueOf(timestamp * 1000));
			SimpleDateFormat dformatter = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat tformatter = new SimpleDateFormat("h:mm a");
			timestampAsStr = dformatter.format(d) + " at " + tformatter.format(d);
		}
		return timestampAsStr;
	}

	public String getUserNameForPost() {
		return userNameForPost;
	}

	public void setUserNameForPost(String userNameForPost) {
		this.userNameForPost = userNameForPost;
	}

	public Boolean getOwner() {
		return owner;
	}

	public void setOwner(Boolean owner) {
		this.owner = owner;
	}

}
