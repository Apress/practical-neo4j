package com.practicalneo4j.graphstory.controller;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practicalneo4j.graphstory.domain.Location;
import com.practicalneo4j.graphstory.repository.MappedProductSearchRespository.MappedProductSearch;
import com.practicalneo4j.graphstory.repository.MappedUserLocationRepository.MappedUserLocation;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Controller
public class LocationController extends GraphStoryController {

	static Logger log = Logger.getLogger(LocationController.class);

	// location main page
	// filter locations within distance
	// provide distance
	// filter locations within distance that have product
	// provide distance & productid
	@RequestMapping(value = "/location", method = RequestMethod.GET)
	public String location(@CookieValue(GraphStoryConstants.graphstoryUserAuthKey) String username, Locale locale, Model model, @RequestParam(required = false) Double distance, @RequestParam(required = false) String productNodeId) {
		model.addAttribute("title", "Location");

		MappedUserLocation mappedUserLocation = graphStoryInterface.getUserInterface().getUserLocation(username);
		model.addAttribute("mappedUserLocation", mappedUserLocation);

		if (distance != null) {
			if (StringUtils.isNotBlank(productNodeId)) {

				graphStory = graphStoryInterface.getLocationInterface().returnLocationsWithinDistanceAndHasProduct(graphStory, mappedUserLocation.getLat(), mappedUserLocation.getLon(), distance, Long.valueOf(productNodeId));

				model.addAttribute("locations", graphStory.getMappedLocations());
				model.addAttribute("product", graphStory.getProduct());

			} else {
				model.addAttribute("locations", graphStoryInterface.getLocationInterface().returnLocationsWithinDistance(mappedUserLocation.getLat(), mappedUserLocation.getLon(), distance));
			}

		}

		return "/mustache/html/graphs/location/index.html";
	}

	// retrieve products via auto suggest
	@RequestMapping(value = "/productsearch/{q}", method = RequestMethod.GET)
	public @ResponseBody
	MappedProductSearch[] productsearch(@PathVariable String q, Model model) {
		MappedProductSearch[] mappedProductSearch = null;
		try {
			mappedProductSearch = graphStoryInterface.getProductInterface().search(q);

		}
		catch (Exception e) {
			log.error(e);
		}
		return mappedProductSearch;
	}

	/*
	 ***********************************
	 while not implemented in the view, the following methods and subsequently called methods could be used to build out a console
	 ***********************************
	 */

	// connect products to location -
	@RequestMapping(value = "/addProductToLocation/{productNodeId}/{locationNodeId}", method = RequestMethod.GET)
	public @ResponseBody
	void addProductToLocation(@PathVariable String locationNodeId, @PathVariable String productNodeId, Model model) {

		try {
			graphStoryInterface.getLocationInterface().addProductToLocation(Long.valueOf(locationNodeId), Long.valueOf(productNodeId));
		}
		catch (Exception e) {
			log.error(e);
		}

	}

	// remove products from location
	@RequestMapping(value = "/removeProductFromLocation/{productNodeId}/{locationNodeId}", method = RequestMethod.GET)
	public @ResponseBody
	void removeProductFromLocation(@PathVariable String locationNodeId, @PathVariable String productNodeId, Model model) {

		try {
			graphStoryInterface.getLocationInterface().removeProductFromLocation(Long.valueOf(locationNodeId), Long.valueOf(productNodeId));
		}
		catch (Exception e) {
			log.error(e);
		}

	}

	// save location - MUST MANUALLY PROVIDE LAT AND LON or use service to determine, e.g. google maps
	@RequestMapping(value = "/location/save", method = RequestMethod.POST)
	public @ResponseBody
	Location save(Model model, @RequestBody Location locationJsonObj) {
		try {
			if (locationJsonObj != null) {
				locationJsonObj = graphStoryInterface.getLocationInterface().save(locationJsonObj);
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return locationJsonObj;
	}

}
