package com.practicalneo4j.graphstory.repository;

import java.util.LinkedList;
import java.util.List;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.domain.User;

public interface UserRepository extends GraphRepository<User> {

	User findByUsername(String username);

	// match users and user by username via param 'c'
	@Query(" MATCH (n:User), (user { username:{c}}) " +

			// where n.username WILDCARD on param 'u'
			// but is not the current user
			" WHERE (n.username =~ {u} AND n <> user) " +

			// and don't return users already being followed
			" AND (NOT (user)-[:FOLLOWS]->(n)) " +
			" RETURN n")
	List<User> searchByUsername(@Param("c") String currentusername, @Param("u") String username);

	@Query("MATCH (user { username:{u}})-[:FOLLOWS]->(users) RETURN users " +
			" ORDER BY users.username")
	LinkedList<User> following(@Param("u") String username);
}
