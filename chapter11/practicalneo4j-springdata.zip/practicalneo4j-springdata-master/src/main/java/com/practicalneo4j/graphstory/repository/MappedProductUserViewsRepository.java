package com.practicalneo4j.graphstory.repository;

import java.util.List;

import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.QueryResult;
import org.springframework.data.neo4j.annotation.ResultColumn;
import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.repository.query.Param;

import com.practicalneo4j.graphstory.repository.MappedProductUserViewsRepository.MappedProductUserViews;

public interface MappedProductUserViewsRepository extends GraphRepository<MappedProductUserViews> {

	@Query("MATCH (u:User { username: {username} })-[r:VIEWED]->(p) " +
			" RETURN p.title as title, r.dateAsStr as dateAsStr " +
			" ORDER BY r.timestamp DESC ")
	List<MappedProductUserViews> getProductTrail(@Param("username") String username);

	@QueryResult
	@NodeEntity
	public interface MappedProductUserViews {

		@ResultColumn("title")
		String getTitle();

		@ResultColumn("dateAsStr")
		String getDateAsStr();
	}
}
