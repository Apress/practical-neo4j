Practical Neo4j for Spring Data
===================

I used Eclipse 3.7 with JDK 7 for this project.  

After the project has been downloaed and unpacked, then you should:

1. Setup a Neo4j instance by going to www.graphstory.com/practicalneo4j
2. Copy the database connection information
3. Import the project into your IDE
4. Update the database connection information in the {projectroot}/src/main/java/com/practicalneo4j/graphstory/service/package.properties file with your connection information
5. Update the  REST Connection to Neo4j server configuration {projectroot}/WebContent/WEB-INF/applicationContext.xml to use the username and password.
6. Update your tomcat server.xml by adding a host similar to the one below.

	```xml
	<Host name="practicalneo4j-java" appBase="/path/to/your/practicalneo4j-springdata/WebContent" unpackWARs="true" autoDeploy="true" >
		<Context path="" docBase="" reloadable="true" swallowOutput="true"  />
	</Host>
	```
7. Configure your web server. The virtual host configuration for apache web server is below:

	```xml
	<VirtualHost *:80>
		ServerName practicalneo4j-spring
		ProxyPreserveHost On
		ProxyPass / http://practicalneo4j-spring:8090/
		ProxyPassReverse / http://practicalneo4j-spring:8090/
	</VirtualHost>
	```
