﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PracticalNeo4j_DotNet.Models
{
    public class Purchase
    {
        public long nodeId { get; set; }
        public string purhcaseId { get; set; }
    }
}