﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PracticalNeo4j_DotNet.ViewModels
{
    public class MappedProductSearch
    {
        public string id { get; set; }
        public string label { get; set; }
        public string name { get; set; }
    }
}