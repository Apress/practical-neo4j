Practical Neo4j for .Net
===================

1. Setup a Neo4j instance by going to www.graphstory.com/practicalneo4j
2. Copy the database connection information
3. Download the zip or clone the repo
4. Open the project in Visual Studio
5. Update the "graphStory" connection string in the Web.config file & run the app
