Practical Neo4j for Ruby
==================

I used Eclipse 3.7 with JDK 7 for this project.  This project also requires Ruby 1.9.2 or greater.

I also used RVM to manage my ruby instances https://rvm.io/

After the project has been downloaed and unpacked, then you should:

1. Setup a Neo4j instance by going to www.graphstory.com/practicalneo4j
2. Copy the database connection information
3. Import the project into your IDE
4. Make sure to add a writable "logs" directory to under the {projectroot}/app folder
5. Update the database connection information in the {projectroot}/app/graphstory.rb file with your connection information
6. you may need to add gems, e.g. sinatra or neography.  Your mileage may vary.
7. Configure your web server. I used passenger_module with Apache http.

	```xml
	LoadModule passenger_module /path/to/your/.rvm/gems/ruby-1.9.2-head@global/gems/passenger-4.0.45/buildout/apache2/mod_passenger.so
	<IfModule mod_passenger.c>
	    PassengerRoot /path/to/your/.rvm/gems/ruby-1.9.2-head@global/gems/passenger-4.0.45
		PassengerDefaultRuby /path/to/your/.rvm/gems/ruby-1.9.2-head/wrappers/ruby
	</IfModule>

	```
8. Make sure the files are readable by the web server user
9. The virtual host configuration for apache web server is below. 

```xml
<VirtualHost *:80>
	ServerName practicalneo4j-ruby
  	DocumentRoot /path/to/your/practicalneo4j-ruby/app/public
  
  	<Directory /path/to/your/practicalneo4j-ruby/app/public>
			Options None
			AllowOverride None
			Order allow,deny
			allow from all
	</Directory>
	ErrorLog /path/to/your/practicalneo4j-ruby/app/logs/practicalneo4j-ruby-error.log
	LogLevel warn
</VirtualHost>
```