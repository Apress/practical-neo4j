require 'rubygems'
require 'ostruct'
require 'sinatra/base'
require 'sinatra/mustache'
require "sinatra/cookies"
require "sinatra/json"
require 'neography'
require 'logger' 

require './service/content'
require './service/location'
require './service/product'
require './service/purchase'
require './service/tags'
require './service/user'
require './service/userlocation'

class App < Sinatra::Base
  
  helpers Sinatra::Cookies
  helpers Sinatra::Content
  helpers Sinatra::Location
  helpers Sinatra::Product
  helpers Sinatra::Purchase
  helpers Sinatra::Tags
  helpers Sinatra::User
  helpers Sinatra::Userlocation
  
  set :views, 'views'
  
  Excon.defaults[:ssl_verify_peer] = false
  
  graphstoryUserAuthKey = "graphstoryUserAuthKey"
  
  log = Logger.new('logs/practicalneo4j-ruby-debug.log')
  neo = Neography::Rest.new("https://username:password@host:7473/db/data")
  
                             
  # home page
  get '/' do
    @title = "Home"
    mustache :"home/index"
  end

  # login
  post '/login' do
      # search db for user
      user = get_user_by_user_name(neo,params[:username])
      
      # found it!  set cookie and redirect
      if !user.nil?  && !user.empty?
        @user = user
        response.set_cookie(graphstoryUserAuthKey, :value => @user["username"], :path => "/", :expires => Time.now + 86400000) 
        redirect to('/social')
      
      # not found. show message
      else
        @title = "Home"
        @error ="The username you entered was not found."
        mustache :"home/index"   
      end
  end
  
  # sign up
  post '/signup/add' do
    # search db for user
      user = get_user_by_user_name(neo,params[:username])
      
      # found a match. need to use another username
      if !!user.nil  && !user.empty?
        @title = "Home"
        @error ="The username " +params[:username]+ " already exists. Please use a different username"
        mustache :"home/index"
      #save the user 
      else
        save_user(neo,params[:username])
        redirect to("/msg?u="+params[:username])
      end
  end
  
  # home page
  get '/msg' do
    @title = "Thank you!"
    @msg ="The username \"" +params[:u]+ "\" has been added. Thank you!"
    mustache :"home/message"
  end

############################################################
# user & friends 
############################################################

  
  # show user  
  get '/user' do
    @title = "User"
    @user = get_user_by_user_name(neo,request.cookies[graphstoryUserAuthKey])
    mustache :"graphs/social/user"
  end
  
  # edit user's first/last name
  put '/user/edit' do
    user = JSON.parse(request.body.read)
    update_user(neo,user,request.cookies[graphstoryUserAuthKey])
    json user
  end

  # show connected users via FOLLOW relationship
  get '/friends' do
    @title = "Friends"
    @following = following(neo,request.cookies[graphstoryUserAuthKey])
    mustache :"graphs/social/friends"
  end
  
  # search for users / returns collection of users as json
  get '/searchbyusername/:username' do
    content_type :json
    username=params[:username]
    json :users => search_by_user_name(neo, request.cookies[graphstoryUserAuthKey],username)
  end
  
  # follow a user & return the updated list of users being followed
  get '/follow/:username' do
    content_type :json
    json :following => follow(neo,request.cookies[graphstoryUserAuthKey],params[:username])
  end

  # unfollow a user & return the updated list of users being followed
  get '/unfollow/:username' do
    content_type :json
    json :following => unfollow(neo,request.cookies[graphstoryUserAuthKey],params[:username])
  end  

############################################################
# social graph
############################################################

  # view posts  
  get '/social' do
    @title="Social"
    @contents = get_content(neo,request.cookies[graphstoryUserAuthKey],0)
    
    if @contents.count > 3
      @morecontent = true
      @contents = @contents.take(3)
    else
      @morecontent = false
    end
    
    mustache :"graphs/social/posts"
  end

  # returns status updates as json  
  get '/postsfeed/:pagenum' do
    json :content => get_content(neo,request.cookies[graphstoryUserAuthKey],params[:pagenum].to_i)
  end
  
  # view single post
  get '/viewpost/:contentId' do
    @statusupdate = get_status_update(neo,params[:contentId],request.cookies[graphstoryUserAuthKey])[0]
    @title= @statusupdate["title"]
    mustache :"graphs/social/post"
  end

  # add a status update
  post '/posts/add' do
    contentItem = JSON.parse(request.body.read)
    
    # save and return content
    contentItem=add_content(neo,contentItem,request.cookies[graphstoryUserAuthKey])
  
    json contentItem
        
  end
  
  # edit a status update
  post '/posts/edit' do
    contentItem = JSON.parse(request.body.read)
    # edit content
    contentItem = edit_content(neo,contentItem,request.cookies[graphstoryUserAuthKey])
    
    json contentItem
  end
  
  # delete post
  get '/posts/delete/:contentId' do
    delete_content(neo,request.cookies[graphstoryUserAuthKey],params[:contentId])
  end

############################################################
# interest graph
############################################################

  # show tags within the user's network (theirs and those being followed)
  get '/interest' do
    @title = "Interest"
    
    @tagsInNetwork = tags_in_network(neo,request.cookies[graphstoryUserAuthKey])
    @userTags = user_tags(neo,request.cookies[graphstoryUserAuthKey])
  
    if params[:userscontent] == "true"
      @contents = get_user_content_with_tag(neo,request.cookies[graphstoryUserAuthKey],params[:tag] )
    else
      @contents = get_following_content_with_tag(neo,request.cookies[graphstoryUserAuthKey],params[:tag] )     
    end
  
    mustache :"graphs/interest/index"
  end

  # show status updates based on a tag
  get '/tag/:q' do
      json tag_search(neo,params[:q].to_s)
  end


############################################################
# consumption graph
############################################################


  # add a product via VIEWED relationship and return VIEWED products
  get '/consumption' do
    @title="Consumption"
      
    @products=get_products(neo,0)
    @next = true
    @nextPageUrl="/consumption/1"

    @productTrail = get_product_trail(neo,request.cookies[graphstoryUserAuthKey])
    
    mustache :"graphs/consumption/index"
  end

  # displays products that are connected to users via a tag relationship
  get '/consumption/console' do
    @title="Consumption Console"
  
    if params[:tag] && !params[:tag].empty?
      @usersWithMatchingTags  = get_products_has_specific_tag_and_user_users_specific_tag(neo,params[:tag])
    else
      @usersWithMatchingTags = get_products_has_a_tag_and_user_users_a_matching_tag(neo)
    end
    
    mustache :"graphs/consumption/console"    
  end

  # return partial - helps to perform auto scroll of products
  get '/consumption/:pagenum' do
    # get page
    curpage=params[:pagenum].to_i

    # get products for this page
    @products=getProducts(neo,curpage)
    
    # bump the page total
    @next = true
    curpage=curpage+1
    
    # set the next GET route
    @nextPageUrl="/consumption/"+curpage.to_s

    mustache :"graphs/consumption/product-list"
  end
  
  # add a product via VIEWED relationship and return VIEWED products
  get '/consumption/add/:productNodeId' do
    # productNodeId to integer
    productNodeId=params[:productNodeId].to_i
    
    #create or update the user view and   
    #return the product trail as JSON
    json :productTrail => create_user_view_and_return_views(neo,
                                                            request.cookies[graphstoryUserAuthKey],
                                                            productNodeId)
  end

############################################################
# location graph
############################################################

  # show locations nearby or locations that have a specific product
  get '/location' do
    @title="Location"

    #get their primary location
    @mappedUserLocation=get_user_location(neo,request.cookies[graphstoryUserAuthKey])
    
    # was a distance param provided?
    if(params[:distance])
      #make the location query
      lq = get_lq(@mappedUserLocation[0],params[:distance].to_s)
      # was a product node id provided?
      if(params[:productNodeId].empty?)
        # if no, just get locations of type 'business'
        @locations=locations_within_distance(neo, lq, @mappedUserLocation[0],"business") 
      else
        #otherwise find locations that have this product
        pnid=params[:productNodeId].to_i
        @productnode=neo.get_node(pnid)["data"]
        @locations=locations_within_distance_with_product(neo,lq,pnid, @mappedUserLocation[0])
      end
    end 
    
    mustache :"graphs/location/index"
  end

  # return product array as json
  get '/productsearch/:q' do
    json product_search(neo,params[:q].to_s)
  end

############################################################
# intent graph
############################################################


  #purchases by friends
  get '/intent' do
    @title = "Products Purchased by Friends"
    #get products purchased by Friends
    @mappedProductUserPurchaseList =friends_purchase(neo,request.cookies[graphstoryUserAuthKey])
    mustache :"graphs/intent/index"
  end
  
  # specific product purchases by friends
  get '/intent/friends_purchase_by_product' do
    @title = "Specific Products Purchased by Friends"
    @producttitle = 'Star Wars Mimobot Thumb Drives'
    @mappedProductUserPurchaseList = friends_purchase_by_product(neo,request.cookies[graphstoryUserAuthKey], @producttitle)
    mustache :"graphs/intent/index"
  end
  
  # friends bought specific products. match these products to tags of the current user
  get '/intent/friends_purchase_tag_similarity' do
    @title = "Products Purchased by Friends and Matches User's Tags"
    @mappedProductUserPurchaseList = friends_purchase_tag_similarity(neo,request.cookies[graphstoryUserAuthKey])
    mustache :"graphs/intent/index"
  end
  
  # friends that are nearby bought this product. the product should also matches tags of the current user
  get '/intent/friends_purchase_tag_similarity_and_proximity_to_location' do
    @title = "Products Purchased by Friends Nearby and Matches User's Tags"
    @mappedUserLocation=get_user_location(neo,request.cookies[graphstoryUserAuthKey])
    lq = get_lq(@mappedUserLocation[0],"10.00")
    @mappedProductUserPurchaseList=friends_purchase_tag_similarity_and_proximity_to_location(neo,request.cookies[graphstoryUserAuthKey],lq)
    mustache :"graphs/intent/index"
  end
end