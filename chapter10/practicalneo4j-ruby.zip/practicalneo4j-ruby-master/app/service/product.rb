require 'sinatra/base'

module Sinatra
  module Product
    def get_products(neo, skip)
      skip=skip*10
      cypher =  " MATCH (p:Product) RETURN ID(p) as nodeId, p.title as title, "+
                " p.description as description, p.tagstr  as tagstr " +
                " ORDER BY p.title "+
                " SKIP {skip} LIMIT 10 "
      results=neo.execute_query(cypher, {:skip => skip} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def get_product_trail(neo,username)
      cypher =  " MATCH (u:User { username: {username} })-[r:VIEWED]->(p) "+
                " RETURN p.title as title,  r.dateAsStr as dateAsStr " +
                " ORDER BY r.timestamp desc "
      results=neo.execute_query(cypher, {:username => username} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    # the method to add a user view of a product and return all views
    def create_user_view_and_return_views(neo,username,productNodeId)
    
      # create timestamp and string display
      time = Time.now
      tsAsInt = time.to_i
      timestampAsStr= time.strftime("%m/%d/%Y") + " at " + time.strftime("%l:%M %p")
        
      cypher =  " MATCH (p:Product), (u:User { username:{u} })" +
                " WHERE id(p) = {productNodeId}" +
                " WITH u,p" +
                " MERGE (u)-[r:VIEWED]->(p)" +
                " SET r.dateAsStr={timestampAsStr}, r.timestamp={ts}" +
                " WITH u " +
                " MATCH (u)-[r:VIEWED]->(p)" +
                " RETURN p.title as title,  r.dateAsStr as dateAsStr" +
                " ORDER BY r.timestamp desc"
                
      results=neo.execute_query(cypher, {:u => username,
                                         :productNodeId => productNodeId, 
                                         :timestampAsStr => timestampAsStr, 
                                         :ts => tsAsInt} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    
    end
    
    def product_search(neo,q)
      q= q + ".*"
      cypher =  " MATCH (p:Product) WHERE lower(p.title) =~ {q}"+
                " RETURN count(*) as name, TOSTRING(ID(p)) as id, p.title as label " +
                " ORDER BY p.title " +
                " LIMIT 5 " 
      results=neo.execute_query(cypher, {:q => q} )
      results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
    
    # products that share any tag with a user
    def get_products_has_a_tag_and_user_users_a_matching_tag(neo)
      cypher =  " MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) "+
                " RETURN p.title as title , collect(u.username) as users, " +
                " collect(distinct t.wordPhrase) as tags "
      results=neo.execute_query(cypher)
      results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
    
    # products that share a specific tag with a user
    def get_products_has_specific_tag_and_user_users_specific_tag(neo, wp)
      cypher =  " MATCH (t:Tag { wordPhrase: {wp} }) " +
                " WITH t " +
                " MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) " +
                " RETURN p.title as title,collect(u) as u, collect(distinct t) as t "
      results=neo.execute_query(cypher, {:wp => wp} )
      results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
  end
end