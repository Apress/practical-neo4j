require 'sinatra/base'
require 'date'

module Sinatra
  module Tags
    
    def tag_search(neo,q)
      q= q + ".*"
      cypher =  " MATCH (c:Content)-[:HAS]->(t:Tag) WHERE t.wordPhrase =~ {q} " + 
                " RETURN count(t) as name, TOSTRING(ID(t)) as id, t.wordPhrase as label  "+
                " ORDER BY t.wordPhrase " +
                " LIMIT 5"
      results=neo.execute_query(cypher, {:q => q} )
      results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
  end
end