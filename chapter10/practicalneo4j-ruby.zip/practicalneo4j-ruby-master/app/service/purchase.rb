require 'sinatra/base'

module Sinatra
  module Purchase
    # products purchased by friends
    def friends_purchase(neo,username)
      cypher = " MATCH (u:User { username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p" +
               " RETURN p.productId as productId,  p.title as title, " +
               " collect(f.firstname + ' ' + f.lastname) as fullname, " +
               " null as wordPhrase, count(f) as cfriends " +
               " ORDER BY cfriends desc, p.title "
       results=neo.execute_query(cypher, {:u => username} )
       results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
    # a specific product purchased by friends
    def friends_purchase_by_product(neo,username,title)
        cypher =  " MATCH (p:Product) " +
                  " WHERE lower(p.title) =lower({title}) " +
                  " WITH p " +
                  " MATCH (u:User { username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->(p) " +
                  " RETURN p.productId as productId,  p.title as title, " +
                  " collect(f.firstname + ' ' + f.lastname) as fullname, " +
                  " null as wordPhrase, count(f) as cfriends " +
                  " ORDER BY cfriends desc, p.title "
        results=neo.execute_query(cypher, {:u => username, :title => title } )
        results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
    # products purchased by friends that match the user's tags
    def friends_purchase_tag_similarity(neo,username)
        cypher =  " MATCH (u:User { username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " +
                  " WITH u,p,f " +
                  " MATCH u-[:USES]->(t)<-[:HAS]-p " +
                  " RETURN p.productId as productId,  p.title as title, " +
                  " collect(f.firstname + ' ' + f.lastname) as fullname, " +
                  " t.wordPhrase as wordPhrase, " +
                  " count(f) as cfriends " +
                  " ORDER BY cfriends desc, p.title "
        results=neo.execute_query(cypher, {:u => username} )
        results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
    
    # user's friends' purchases who are nearby and the products match the user's tags
    def friends_purchase_tag_similarity_and_proximity_to_location(neo,username,lq)
        cypher =  " START n = node:geom({lq}) " +
                  " WITH n " +
                  " MATCH (u:User { username: {u} } )-[:USES]->(t)<-[:HAS]-p " +
                  " WITH n,u,p,t " +
                  " MATCH u-[:FOLLOWS]->(f)-[:HAS]->(n) " +
                  " WITH p,f,t " +
                  " MATCH f-[:MADE]->()-[:CONTAINS]->(p) " +
                  " RETURN p.productId as productId,  p.title as title, " +
                  " collect(f.firstname + ' ' + f.lastname) as fullname, " +
                  " t.wordPhrase as wordPhrase, " +
                  " count(f) as cfriends " +
                  " ORDER BY cfriends desc, p.title "
        results=neo.execute_query(cypher, {:u => username, :lq => lq} )
        results["data"].map {|row| Hash[results["columns"].zip(row)] }
    end
  end
end
