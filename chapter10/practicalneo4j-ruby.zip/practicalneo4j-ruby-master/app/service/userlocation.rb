require 'sinatra/base'

module Sinatra
  module Userlocation
    def get_user_location(neo,username)
        ul=""
        cypher = " MATCH (u:User { username : {u} } )-[:HAS]-(l:Location) " +
        " RETURN u.username as username, l.address as address, l.city as city," + 
        " l.state as state,  l.zip as zip, l.lat as lat, l.lon as lon"
        results = neo.execute_query(cypher, {:u => username} )
        results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] } 
        
    end

    def get_lq(ul,distance)
        # setup spatial query for spatial index
        lq = "withinDistance:["
        lq.concat(ul["lat"].to_s)
        lq.concat(",")
        lq.concat(ul["lon"].to_s)
        lq.concat(",")
        lq.concat(distance)
        lq.concat("]")
        lq
     end
  end
end