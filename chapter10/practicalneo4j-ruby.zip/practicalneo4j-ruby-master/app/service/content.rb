require 'sinatra/base'
require 'date'

module Sinatra
  module Content
    def get_content(neo,username,skip)
      cypher =  " MATCH (u:User {username: {u} })-[:FOLLOWS*0..1]->f  "+
                " WITH DISTINCT f,u "+
                " MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..3]-p   "+
                " RETURN  p.contentId as contentId, p.title as title, "+ 
                " p.tagstr as tagstr, p.timestamp as timestamp, "+ 
                " p.url as url, f.username as username, f=u as owner  "+
                " ORDER BY p.timestamp desc SKIP {s} LIMIT 4 "
      results=neo.execute_query(cypher, {:u => username, :s => skip} )
      r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r
    end
    
    def get_status_update(neo,contentId,username)
      cypher =  " MATCH (c:Content {contentId:{contentId}})-[:NEXTPOST*0..]-()-[:CURRENTPOST]-(o:User), "+
                " (u:User {username: {u} }) "+
                " RETURN c.contentId as contentId, c.title as title, c.tagstr as tagstr, "+
                " c.timestamp as timestamp, c.url as url, o.username as username, o=u as owner "
      results=neo.execute_query(cypher, {:contentId => contentId, :u => username} )
      r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r
    end
    
    def tags_in_network(neo,username)
      cypher =  " MATCH (u:User {username: {u} })-[:FOLLOWS]->f " +
                " WITH distinct f " +
                " MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
                " WITH distinct c " +
                " MATCH c-[ct:HAS]->(t) " +
                " WITH distinct ct,t " +
                " RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id " +
                " ORDER BY id desc " +
                " SKIP 0 LIMIT 30"
       results=neo.execute_query(cypher, {:u => username} )
       results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def user_tags(neo,username)
      cypher =  " MATCH (u:User {username: {u} })-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
                " WITH distinct c " +
                " MATCH c-[ct:HAS]->(t) " +
                " WITH distinct ct,t " +
                " RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id " +
                " ORDER BY id desc " +
                " SKIP 0 LIMIT 30"
       results=neo.execute_query(cypher, {:u => username} )
       results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def get_user_content_with_tag(neo,username,wordPhrase)
      cypher =  " MATCH (u:User {username: {u} })-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p " +
                " WITH DISTINCT u,p" +
                " MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" +
                " RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
                " p.timestamp as timestamp, p.url as url, u.username as username, true as owner" +
                " ORDER BY p.timestamp DESC"
       results=neo.execute_query(cypher, {:u => username, :wp => wordPhrase} )
       r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r
    end
    
    def get_following_content_with_tag(neo,username,wordPhrase)
      cypher =  " MATCH (u:User {username: {u} })-[:FOLLOWS]->f" +
                " WITH DISTINCT f" +
                " MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p" +
                " WITH DISTINCT f,p" +
                " MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" +
                " RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
                " p.timestamp as timestamp, p.url as url, f.username as username, false as owner" +
                " ORDER BY p.timestamp DESC"
       results=neo.execute_query(cypher, {:u => username, :wp => wordPhrase} )
       r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r
    end
    
    # add a status update
    def add_content(neo,contentItem,username)
      
      tagstr=trim_content_tags(contentItem["tagstr"])
      tags=tagstr.split(",")
      time = Time.now.to_i
      
      cypher =  " MATCH (user { username: {u}}) " +
                " CREATE UNIQUE (user)-[:CURRENTPOST]->(newLP:Content { title:{title}, url:{url}, " +
                " tagstr:{tagstr}, timestamp:{timestamp}, contentId:{contentId} }) " +
                " WITH user, newLP" +
                " FOREACH (tagName in {tags} |  " +
                " MERGE (t:Tag {wordPhrase:tagName}) " +
                " MERGE (newLP)-[:HAS]->(t) " +
                " )" +
                " WITH user, newLP " +
                " OPTIONAL MATCH  (newLP)<-[:CURRENTPOST]-(user)-[oldRel:CURRENTPOST]->(oldLP)" +
                " DELETE oldRel " +
                " CREATE (newLP)-[:NEXTPOST]->(oldLP) " +
                " RETURN newLP.contentId as contentId, newLP.title as title, newLP.tagstr as tagstr, " +
                " newLP.timestamp as timestamp, newLP.url as url, {u} as username, true as owner "
                
                
      results=neo.execute_query(cypher, { :u => username,
                                          :title => contentItem["title"].strip, 
                                          :url => contentItem["url"].strip, 
                                          :tagstr => tagstr, 
                                          :timestamp => time, 
                                          :contentId => SecureRandom.uuid, 
                                          :tags => tags } )
      r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r
    end
    
    # edit a status update
    def edit_content(neo,contentItem,username)
      
      tagstr=trim_content_tags(contentItem["tagstr"])
      tags=tagstr.split(",")
      
      cypher =  " MATCH (c:Content {contentId:{contentId}})-[:NEXTPOST*0..]-()-[:CURRENTPOST]-(user { username: {u}}) " +
                " SET c.title = {title}, c.url = {url}, c.tagstr = {tagstr}" +
                " FOREACH (tagName in {tags} |  " +
                " MERGE (t:Tag {wordPhrase:tagName}) " +
                " MERGE (c)-[:HAS]->(t) " +
                " )" +
                " RETURN c.contentId as contentId, c.title as title, c.tagstr as tagstr, " +
                " c.timestamp as timestamp, c.url as url, {u} as username, true as owner " 
      results=neo.execute_query(cypher, { :u => username,
                                          :title => contentItem["title"].strip, 
                                          :url => contentItem["url"].strip, 
                                          :tagstr => tagstr, 
                                          :contentId => contentItem["contentId"], 
                                          :tags => tags } )
      r=results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
      r.each do |e|
        #convert the timestamp to readable date and time
        e.merge!("timestampAsStr" => Time.at(e["timestamp"]).strftime("%m/%d/%Y") + 
        " at " +  
        Time.at(e["timestamp"]).strftime("%l:%M %p"))
      end
      r                               
    end 
    
    # delete a status update
    def delete_content(neo,username,contentId)
      
       cypher =  " MATCH (u:User { username: {u} }), (c:Content { contentId: {contentId} }) " +
                " WITH u,c " +
                " MATCH (u)-[:CURRENTPOST]->(c)-[:NEXTPOST]->(nextPost) " +
                " WHERE nextPost is not null " +
                " CREATE UNIQUE (u)-[:CURRENTPOST]->(nextPost) " +
                " WITH count(nextPost) as cnt " +
                " MATCH (before)-[:NEXTPOST]->(c:Content { contentId: {contentId}})-[:NEXTPOST]->(after) " +
                " WHERE before is not null AND after is not null " +
                " CREATE UNIQUE (before)-[:NEXTPOST]->(after) " +
                " WITH count(before) as cnt " +
                " MATCH (c:Content { contentId: {contentId} })-[r]-() " +
                " DELETE c, r" 
      results=neo.execute_query(cypher, {:u => username, :contentId => contentId})
    end
    
    def trim_content_tags(tagstr)
      # strip any white space from the leading/trailing of tags, 
      # remove the last comma if one exists
      tagstr=tagstr.split(",").map(&:strip)
      tagstr = tagstr.join(",")
      tagstr=tagstr.chomp(",")
    end
  end
end
