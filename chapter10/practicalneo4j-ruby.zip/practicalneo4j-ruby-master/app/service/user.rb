require 'sinatra/base'

module Sinatra
  module User
    def get_user_by_user_name(neo, username)
      user=""
      users = neo.find_nodes_labeled("User", username: username)
        if !!users  && users.any?
          user = users.first["data"]
        end
      user 
    end

    
    def getUserNodeByUserName(neo, username)
      user=""
      userarray = neo.find_nodes_labeled("User", {:username => username})
        if !userarray.nil?  && !userarray.empty? 
          user = userarray.at(0)
        end
      user 
    end
    
    def save_user(neo, username)
        node=neo.create_node("username" => username)  
        neo.add_label(node, "User")  
    end
    
    def update_user(neo,user,username)
      cypher =  "MATCH (user:User {username:{u}} )  " +
                "SET user.firstname = {fn}, user.lastname = {ln}"
      neo.execute_query(cypher, {:fn => user["firstname"],:ln => user["lastname"], :u => username} )
    end
    
    def following(neo,username)
      cypher =  " MATCH (user { username:{u}})-[:FOLLOWS]->(users) "+ 
                " RETURN users.firstname as firstname, users.lastname as lastname, users.username as username " +
                " ORDER BY users.username"
       results=neo.execute_query(cypher, {:u => username} )
       results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def search_by_user_name(neo,currentusername,username)
      username=username.downcase+".*"
      
      cypher =  " MATCH (n:User), (user { username:{c}}) " +
                " WHERE (n.username =~ {u} AND n <> user) " +
                " AND (NOT (user)-[:FOLLOWS]->(n)) " +
                " RETURN n.firstname as firstname, n.lastname as lastname, n.username as username"
      results=neo.execute_query(cypher, {:c => currentusername, :u => username} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def follow(neo,currentusername,username)
      cypher =  " MATCH (user1:User {username:{cu}} ), (user2:User {username:{u}} ) " +
                " CREATE UNIQUE user1-[:FOLLOWS]->user2 " +
                " WITH user1" +
                " MATCH (user1)-[f:FOLLOWS]->(users)" +
                " RETURN users.firstname as firstname, users.lastname as lastname, "+
                " users.username as username " +
                " ORDER BY users.username" 
      results=neo.execute_query(cypher, {:cu => currentusername, :u => username} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
    
    def unfollow(neo,currentusername,username)
      cypher =  "MATCH (user1:User {username:{cu}} )-[f:FOLLOWS]->(user2:User {username:{u}} ) " +
                " DELETE f " +
                " WITH user1" +
                " MATCH (user1)-[f:FOLLOWS]->(users)" +
                " RETURN users.firstname as firstname, users.lastname as lastname, "+
                " users.username as username " +
                " ORDER BY users.username"
      results=neo.execute_query(cypher, {:cu => currentusername, :u => username} )
      results["data"].map {|row| Hash[*results["columns"].zip(row).flatten] }
    end
              
  end
end