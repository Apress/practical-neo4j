package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.neo4j.helpers.collection.IteratorUtil;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.practicalneo4j.graphstory.model.User;
import com.practicalneo4j.graphstory.model.mapped.MappedUserLocation;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class UserDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(UserDAO.class);

	private User tempUser;

	public GraphStory login(GraphStory graphStory) throws Exception {

		tempUser = getByUserName(graphStory.getUser());
		if (tempUser != null) {
			graphStory.setUser(tempUser);
		} else {
			addErrorMsg(graphStory, "The username you entered does not exist.");
		}
		return graphStory;
	}

	public GraphStory save(GraphStory graphStory) throws Exception {

		// no user match, so proceed with the saving
		if (userExists(graphStory.getUser()) == false) {

			// give user an id
			graphStory.getUser().setUserId(uuidGenWithTimeStamp());

			cypher.iteratorQuery(" CREATE (user:User {1}) ", map("1", objectAsMap(graphStory.getUser())));

		} else {
			graphStory.getErrorMsgs().add("The username you entered already exists.");
		}

		return graphStory;
	}

	public User update(String currentusername, User user) throws Exception {

		Map<String, Object> userMap = null;

		userMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
				" MATCH (user:User {username:{1}}) " +
						" SET user.firstname={2}, user.lastname={3} " +
						" RETURN user",
				map("1", currentusername, "2", user.getFirstname(), "3", user.getLastname())));
		ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();

		return resultSetMapper.mapLabelNodeToClass(userMap, User.class, new ObjectMapper());
	}

	public User getByUserName(User user) throws Exception {
		return getByUserName(user.getUsername());
	}

	public User getByUserName(String username) throws Exception {
		Map<String, Object> userMap = null;
		if (StringUtils.isEmpty(username)) {
			return null;
		} else {
			userMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
					" MATCH (user:User {username:{1}}) RETURN user LIMIT 1 ",
					map("1", username)));
			ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();

			return resultSetMapper.mapLabelNodeToClass(userMap, User.class, new ObjectMapper());
		}
	}

	private boolean userExists(User user) {
		boolean userFound = false;

		try {
			tempUser = getByUserName(user);

			if (getByUserName(tempUser) != null) {
				userFound = true;
			}
		}
		catch (Exception e) {
			log.error(e);

		}

		return userFound;
	}

	public List<User> following(String username) {

		try
		{
			ResultSet resultSet = cypher.resultSetQuery(
					" MATCH (user { username:{1}})-[:FOLLOWS]->(users) " +
							" RETURN users " +
							" ORDER BY users.username",
					map("1", username));
			ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();
			return resultSetMapper.mapRersultSetToObject(resultSet, User.class);
		}
		catch (Exception e) {
			log.error(e);

			return null;
		}
	}

	// find users the current user is not already following
	public List<User> searchNotFollowing(String currentusername, String username) {
		try
		{
			username = username.toLowerCase() + ".*";

			ResultSet resultSet = cypher.resultSetQuery(
					" MATCH (users:User), (user { username:{1}}) " +
							// where n.username WILDCARD on param 'u'
							// but is not the current user
							" WHERE (users.username =~ {2} AND users <> user) " +
							// and don't return users already being followed
							" AND (NOT (user)-[:FOLLOWS]->(users)) " +
							" RETURN users" +
							" ORDER BY users.username",
					map("1", currentusername, "2", username));
			ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();
			return resultSetMapper.mapRersultSetToObject(resultSet, User.class);
		}
		catch (Exception e) {
			log.error(e);

			return null;
		}
	}

	// follow and return new list of following
	public List<User> follow(String currentusername, String username) {

		try
		{
			ResultSet resultSet = cypher.resultSetQuery(
					" MATCH (user1:User {username:{1}} ),(user2:User {username:{2}} )" +
							" CREATE UNIQUE user1-[:FOLLOWS]->user2" +
							" WITH user1" +
							" MATCH (user1)-[f:FOLLOWS]->(users)" +
							" RETURN users " +
							" ORDER BY users.username",
					map("1", currentusername, "2", username));
			ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();
			return resultSetMapper.mapRersultSetToObject(resultSet, User.class);
		}
		catch (Exception e) {
			log.error(e);

			return null;
		}

	}

	// unfollow (e.g. delete relationship) and return new list of following
	public List<User> unfollow(String currentusername, String username) {

		try
		{
			ResultSet resultSet = cypher.resultSetQuery(
					" MATCH (user1:User {username:{1}} )-[f:FOLLOWS]->(user2:User {username:{2}} )" +
							" DELETE f" +
							" WITH user1" +
							" MATCH (user1)-[f:FOLLOWS]->(users)" +
							" RETURN users " +
							" ORDER BY users.username",
					map("1", currentusername, "2", username));
			ResultSetMapper<User> resultSetMapper = new ResultSetMapper<User>();
			return resultSetMapper.mapRersultSetToObject(resultSet, User.class);
		}
		catch (Exception e) {
			log.error(e);

			return null;
		}

	}

	public MappedUserLocation getUserLocation(String currentusername) throws Exception {
		MappedUserLocation mappedUserLocation = null;

		ResultSet resultSet = cypher.resultSetQuery(
				" MATCH (u:User { username : {1} } )-[:HAS]-(l:Location)" +
						" RETURN u.username as username, l.address as address, " +
						" l.city as city, l.state as state, l.zip as zip, " +
						" l.lat as lat, l.lon as lon",
				map("1", currentusername));

		ResultSetMapper<MappedUserLocation> resultSetMapper = new ResultSetMapper<MappedUserLocation>();
		List<MappedUserLocation> mappedUserLocations = resultSetMapper.mapResultSetToListMappedClass(resultSet, MappedUserLocation.class);

		if (mappedUserLocations.size() > 0) {
			mappedUserLocation = mappedUserLocations.get(0);
		}
		return mappedUserLocation;

	}

}
