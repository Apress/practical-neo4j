package com.practicalneo4j.graphstory.model;

import java.io.Serializable;

import org.neo4j.graphdb.Node;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	private Node node = null;

	private Long nodeId = null;

	private String productId; // this could also be a SKU or UPC

	private String title;

	private String description;

	private String tagstr;

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTagstr() {
		return tagstr;
	}

	public void setTagstr(String tagstr) {
		this.tagstr = tagstr;
	}

}
