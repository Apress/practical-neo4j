package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.neo4j.helpers.collection.IteratorUtil;

import com.practicalneo4j.graphstory.model.Content;
import com.practicalneo4j.graphstory.model.mapped.MappedContent;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class ContentDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(ContentDAO.class);

	public GraphStory getContent(String username, int skip, GraphStory graphStory) {
		try {

			ResultSet rs = cypher.resultSetQuery(
					" MATCH (u:User {username: {1} }) " +
							" WITH u " +
							" MATCH (u)-[:FOLLOWS*0..1]->f " +
							" WITH DISTINCT f,u " +
							" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..3]-p " +
							" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
							" p.timestamp as timestamp, p.url as url, f.username as username, f=u as owner " +
							" ORDER BY p.timestamp DESC " +
							" SKIP {2} LIMIT 4 ",
					map("1", username, "2", skip));
			ResultSetMapper<MappedContent> resultSetMapper = new ResultSetMapper<MappedContent>();

			graphStory.setContent(resultSetMapper.mapResultSetToListMappedClass(rs, MappedContent.class));

			if (graphStory.getContent().size() >= 4) {
				graphStory.setMorecontent(true);
				if (skip == 0) {
					graphStory.setContent(graphStory.getContent().subList(0, 3));
				}

			} else {
				graphStory.setMorecontent(false);
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return graphStory;

	}

	public MappedContent getByContentId(String contentId, String currentusername) {
		Map<String, Object> contentMap = null;
		if (StringUtils.isEmpty(contentId)) {
			return null;
		} else {
			contentMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
					" MATCH (c:Content {contentId:{1}})-[:NEXTPOST*0..]-()-[:CURRENTPOST]-(o:User),(u:User {username: {2} }) " +
							" RETURN c.contentId as contentId, c.title as title, c.tagstr as tagstr, " +
							" c.timestamp as timestamp, c.url as url, o.username as username, o=u as owner ",
					map("1", contentId, "2", currentusername)));
			ResultSetMapper<MappedContent> resultSetMapper = new ResultSetMapper<MappedContent>();
			return resultSetMapper.mapResultSetToMappedClass(contentMap, MappedContent.class);

		}
	}

	public List<MappedContent> getContentByTag(String username, String tag, Boolean isCurrentUser) {

		List<MappedContent> contents = null;
		ResultSetMapper<MappedContent> resultSetMapper = new ResultSetMapper<MappedContent>();
		try {
			if (isCurrentUser) {
				ResultSet rs = cypher.resultSetQuery(
						"MATCH (u:User {username: {1} })" +
								" MATCH u-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p " +
								" WITH DISTINCT u,p" +
								" MATCH p-[:HAS]-(t:Tag {wordPhrase : {2} } )" +
								" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
								" p.timestamp as timestamp, p.url as url, " +
								" u.username as username, true as owner " +
								" ORDER BY p.timestamp DESC",
						map("1", username, "2", tag));

				contents = resultSetMapper.mapResultSetToListMappedClass(rs, MappedContent.class);

			} else {

				ResultSet rs = cypher.resultSetQuery(
						" MATCH (u:User {username: {1} })" +
								" WITH u " +
								" MATCH (u)-[:FOLLOWS]->f" +
								" WITH DISTINCT f" +
								" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p" +
								" WITH DISTINCT f,p" +
								" MATCH p-[:HAS]-(t:Tag {wordPhrase : {2} } )" +
								" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " +
								" p.timestamp as timestamp, p.url as url, " +
								" f.username as username, false as owner " +
								" ORDER BY p.timestamp DESC",
						map("1", username, "2", tag));
				contents = resultSetMapper.mapResultSetToListMappedClass(rs, MappedContent.class);
			}
		}
		catch (Exception e) {
			log.error(e);
		}
		return contents;
	}

	public MappedContent addContent(Content content, String username) {
		Date timestamp = new Date();

		String tagStr = trimContentTags(content.getTagstr());

		Map<String, Object> contentMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
				" MATCH (user { username: {1}}) " +
						" CREATE UNIQUE (user)-[:CURRENTPOST]->(newLP:Content { title:{2}, url:{3}, " +
						" tagstr:{4}, timestamp:{5}, contentId:{6} }) " +
						" WITH user, newLP, collect(distinct newLP.tagstr) as tstr" +
						" FOREACH (tagName in {7} |  " +
						" MERGE (t:Tag {wordPhrase: tagName })" +
						" MERGE (newLP)-[:HAS]->(t) )" +
						" WITH user, newLP " +
						" OPTIONAL MATCH  (newLP)<-[:CURRENTPOST]-(user)-[oldRel:CURRENTPOST]->(oldLP)" +
						" DELETE oldRel " +
						" CREATE (newLP)-[:NEXTPOST]->(oldLP) " +
						" RETURN newLP.contentId as contentId, newLP.title as title, " +
						" newLP.tagstr as tagstr, " +
						" newLP.timestamp as timestamp, newLP.url as url, " +
						"user.username as username, true as owner ",
				map("1", username, "2", content.getTitle(), "3",
						content.getUrl(), "4", tagStr, "5",
						timestamp.getTime() / 1000, "6",
						UUID.randomUUID().toString(), "7", tagList(tagStr))));
		ResultSetMapper<MappedContent> resultSetMapper = new ResultSetMapper<MappedContent>();
		return resultSetMapper.mapResultSetToMappedClass(contentMap, MappedContent.class);
	}

	public MappedContent editContent(Content content, String username) {

		String tagStr = trimContentTags(content.getTagstr());

		Map<String, Object> contentMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
				" MATCH (c:Content {contentId:{1}})-[:NEXTPOST*0..]-()-[:CURRENTPOST]-(user { username: {2}}) " +
						" SET c.title = {3}, c.url = {4}, c.tagstr = {5}" +
						" FOREACH (tagName in {6} |  " +
						" MERGE (t:Tag {wordPhrase:tagName}) " +
						" MERGE (c)-[:HAS]->(t) " +
						" )" +
						" RETURN c.contentId as contentId, c.title as title, c.tagstr as tagstr, " +
						" c.timestamp as timestamp, c.url as url, {2} as username, true as owner ",
				map("1", content.getContentId(), "2", username, "3", content.getTitle(),
						"4", content.getUrl(), "5", tagStr, "6", tagList(tagStr))));
		ResultSetMapper<MappedContent> resultSetMapper = new ResultSetMapper<MappedContent>();
		return resultSetMapper.mapResultSetToMappedClass(contentMap, MappedContent.class);

	}

	public void deleteContent(String contentId, String username) {
		cypher.iteratorQuery(
				" MATCH (u:User { username: {1} }), (c:Content { contentId: {2} }) " +
						" WITH u,c " +
						" MATCH (u)-[:CURRENTPOST]->(c)-[:NEXTPOST]->(nextPost) " +
						" WHERE nextPost is not null " +
						" CREATE UNIQUE (u)-[:CURRENTPOST]->(nextPost) " +
						" WITH count(nextPost) as cnt " +
						" MATCH (before)-[:NEXTPOST]->(c:Content { contentId: {2}})-[:NEXTPOST]->(after) " +
						" WHERE before is not null AND after is not null " +
						" CREATE UNIQUE (before)-[:NEXTPOST]->(after) " +
						" WITH count(before) as cnt " +
						" MATCH (c:Content { contentId: {2} })-[r]-() " +
						" DELETE c, r",
				map("1", username, "2", contentId));
	}

	private String trimContentTags(String tagStr) {
		if (StringUtils.isNotEmpty(tagStr)) {
			tagStr = tagStr.trim();
			tagStr = StringUtils.removeEnd(tagStr, ",");
			String array[] = StringUtils.split(tagStr, ",");
			for (int i = 0; i < array.length; i++)
				array[i] = array[i].trim();

			tagStr = StringUtils.join(array, ",");
		}

		return tagStr;
	}

	private List<String> tagList(String tagStr) {

		List<String> tagList = null;

		if (StringUtils.isNotEmpty(tagStr)) {
			tagList = new ArrayList<String>(Arrays.asList(StringUtils.split(tagStr, ",")));
		}

		return tagList;
	}
}