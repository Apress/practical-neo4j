package com.practicalneo4j.graphstory.action;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class LocationAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(LocationAction.class);

	private String q, productNodeId;

	private Double distance;

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}

	public String getProductNodeId() {
		return productNodeId;
	}

	public void setProductNodeId(String productNodeId) {
		this.productNodeId = productNodeId;
	}

	@Action(value = "location",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/location/index.html")
		})
	public String location() {
		setTitle("Location");
		try {
			mappedUserLocation = graphStoryDAO.getUserDAO().getUserLocation(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey));

			if (distance != null) {
				if (StringUtils.isNotBlank(productNodeId)) {
					graphStory.setLocations(graphStoryDAO.getLocationDAO().returnLocationsWithinDistanceAndHasProduct(mappedUserLocation.getLat(), mappedUserLocation.getLon(), distance, Long.valueOf(productNodeId)));
					graphStory.setProduct(graphStoryDAO.getProductDAO().getProductByNodeId(Long.valueOf(productNodeId)));
				} else {
					graphStory.setLocations(graphStoryDAO.getLocationDAO().returnLocationsWithinDistance(mappedUserLocation.getLat(), mappedUserLocation.getLon(), distance));
				}

			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "/productsearch/{q}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String productSearch() {
		try {

			graphStory.setMappedProductSearch(graphStoryDAO.getProductDAO().search(q));

		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

}
