package com.practicalneo4j.graphstory.action;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class ConsumptionAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(ConsumptionAction.class);

	private Long productNodeId;

	public Long getProductNodeId() {
		return productNodeId;
	}

	public void setProductNodeId(Long productNodeId) {
		this.productNodeId = productNodeId;
	}

	@Action(value = "consumption/{pagenum}",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/consumption/index.html"),
				@Result(name = "page", type = "mustache", location = "/mustache/html/graphs/consumption/product-list.html")
		})
	public String consumption() {

		// returns a product list HTML snippet
		if (pagenum != null) {
			// set current page
			Integer curpage = pagenum;
			// get the list of products for this page
			graphStory = graphStoryDAO.getProductDAO().getProducts(graphStory, curpage);
			// increase the page count
			curpage = curpage + 10;
			// set the next page to call
			graphStory.setNextPageUrl("/consumption/" + curpage.toString());

			return "page";

		} else {

			setTitle("Consumption");
			// retrieve the first page of products
			graphStory = graphStoryDAO.getProductDAO().getProducts(graphStory, pageNumStart);
			// set the product trail

			graphStory.setProductTrail(graphStoryDAO.getProductDAO().getProductTrail(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
			// set the next page to call
			graphStory.setNextPageUrl("/consumption/10");

			return SUCCESS;
		}

	}

	@Action(value = "consumption/console",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/consumption/console.html")
		})
	public String console() {
		setTitle("Consumption Console");

		graphStory.setUsersWithMatchingTags(graphStoryDAO.getProductDAO().getProductsHasATagAndUserUsesAMatchingTag());

		return SUCCESS;
	}

	@Action(value = "consumptionview/add/{productNodeId}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String addUserViewAndReturnProductTrail() {
		try {
			graphStory.setProductTrail(graphStoryDAO.getProductDAO().addUserViewAndReturnProductTrail(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), productNodeId));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

}
