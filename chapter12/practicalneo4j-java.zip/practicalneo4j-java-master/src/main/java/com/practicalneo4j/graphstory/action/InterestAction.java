package com.practicalneo4j.graphstory.action;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class InterestAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(InterestAction.class);

	private Boolean isCurrentUser;

	private String tag;

	public Boolean getIsCurrentUser() {
		return isCurrentUser;
	}

	public void setIsCurrentUser(Boolean isCurrentUser) {
		this.isCurrentUser = isCurrentUser;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	@Action(value = "interest",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/interest/index.html"),
		})
	public String interest() {
		try {
			setTitle("Interest");

			graphStory.setUsername(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey));
			graphStory = graphStoryDAO.getTagDAO().tagsInMyNetwork(graphStory);

			if (StringUtils.isNotEmpty(tag)) {
				graphStory.setContent(graphStoryDAO.getContentDAO().getContentByTag(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), tag, isCurrentUser));
			} else {
				graphStory.setContent(null);
			}

		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "/tag/{tag}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String tagSearch() {
		try {
			graphStory.setTags(graphStoryDAO.getTagDAO().tagSearch(tag));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

}
