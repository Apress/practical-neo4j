package com.practicalneo4j.graphstory.action;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class IntentAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(IntentAction.class);

	private Boolean showForm;

	private String producttitle;

	public Boolean getShowForm() {
		return showForm;
	}

	public void setShowForm(Boolean showForm) {
		this.showForm = showForm;
	}

	public String getProducttitle() {
		return producttitle;
	}

	public void setProducttitle(String producttitle) {
		this.producttitle = producttitle;
	}

	@Action(value = "intent",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/intent/index.html")
		})
	public String intent() {
		setTitle("Products Purchased by Friends");
		try {
			graphStory.setMappedProductUserPurchaseList(graphStoryDAO.getPurchaseDAO().friendsPurchase(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
			graphStory.setUser(graphStoryDAO.getUserDAO().getByUserName(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "intent/friendsPurchaseByProduct",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/intent/index.html")
		})
	public String friendsPurchaseByProduct() {
		setTitle("Specific Products Purchased by Friends");
		setShowForm(true);
		try {

			if (StringUtils.isBlank(producttitle)) {
				producttitle = "Star Wars Mimobot Thumb Drives";
			}

			graphStory.setMappedProductUserPurchaseList(graphStoryDAO.getPurchaseDAO().friendsPurchaseByProduct(producttitle, cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
			graphStory.setUser(graphStoryDAO.getUserDAO().getByUserName(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "intent/friendsPurchaseTagSimilarity",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/intent/index.html")
		})
	public String friendsPurchaseTagSimilarity() {
		setTitle("Products Purchased by Friends and Matches User's Tags");

		try {

			graphStory.setMappedProductUserPurchaseList(graphStoryDAO.getPurchaseDAO().friendsPurchaseTagSimilarity(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
			graphStory.setUser(graphStoryDAO.getUserDAO().getByUserName(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "intent/friendsPurchaseTagSimilarityAndProximityToLocation",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/intent/index.html")
		})
	public String friendsPurchaseTagSimilarityAndProximityToLocation() {
		setTitle("Products Purchased by Friends Nearby and Matches User's Tags");

		try {

			mappedUserLocation = graphStoryDAO.getUserDAO().getUserLocation(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey));

			graphStory.setUser(graphStoryDAO.getUserDAO().getByUserName(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));

			graphStory.setMappedProductUserPurchaseList(graphStoryDAO.getPurchaseDAO()
					.friendsPurchaseTagSimilarityAndProximityToLocation(
							mappedUserLocation.getLat(),
							mappedUserLocation.getLon(),
							new Double("10.00"),
							cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)
					));

		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}
}
