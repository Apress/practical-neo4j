package com.practicalneo4j.graphstory.model.mapped;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class MappedProductUserPurchase {

	private String productId, title, wordPhrase;

	private List<String> fullname;

	private Integer cfriends;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWordPhrase() {
		return wordPhrase;
	}

	public void setWordPhrase(String wordPhrase) {
		this.wordPhrase = wordPhrase;
	}

	public List<String> getFullname() {
		return fullname;
	}

	public void setFullname(List<String> fullname) {
		this.fullname = fullname;
	}

	public Integer getCfriends() {
		return cfriends;
	}

	public void setCfriends(Integer cfriends) {
		this.cfriends = cfriends;
	}
}
