package com.practicalneo4j.graphstory.action;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Actions;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.model.mapped.MappedContent;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class SocialAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(SocialAction.class);

	// the content id
	private String contentId;

	private MappedContent content;

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public MappedContent getContent() {
		return content;
	}

	public void setContent(MappedContent content) {
		this.content = content;
	}

	@Actions({
			@Action(value = "social",
				results = {
						@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/social/posts.html")
				})
	})
	public String posts() {
		try {
			setTitle("Social");

			graphStory = graphStoryDAO.getContentDAO().getContent(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), pageNumStart, graphStory);

		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "/postsfeed/{pagenum}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String postsfeed() {
		try {
			graphStory = graphStoryDAO.getContentDAO().getContent(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), pagenum, graphStory);
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "posts/add", interceptorRefs = {
			@InterceptorRef(value = "cookie", params = { "cookiesName", "graphstoryUserAuthKey" }),
			@InterceptorRef(value = "json", params = { "noCache", "true", "excludeNullProperties", "true" }) },
		results = {
				@Result(name = "success", type = "json", params = { "noCache", "true" })
		})
	public String addContent() {
		try {

			if (graphStory.getStatusUpdate() != null) {
				graphStory.setMappedContent(graphStoryDAO.getContentDAO().addContent(graphStory.getStatusUpdate(), cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));

			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "posts/edit", interceptorRefs = {
			@InterceptorRef(value = "cookie", params = { "cookiesName", "graphstoryUserAuthKey" }),
			@InterceptorRef(value = "json", params = { "noCache", "true", "excludeNullProperties", "true" }) },
		results = {
				@Result(name = "success", type = "json", params = { "noCache", "true" })
		})
	public String editContent() {
		try {
			if (graphStory.getStatusUpdate() != null) {
				graphStory.setMappedContent(graphStoryDAO.getContentDAO()
						.editContent(
								graphStory.getStatusUpdate(),
								cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)
						));
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "/posts/delete/{contentId}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String deleteContent() {
		try {

			graphStoryDAO.getContentDAO()
					.deleteContent(
							contentId,
							cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)
					);

			Map<String, Object> msg = new HashMap<String, Object>();
			msg.put("Msg", "OK");
			graphStory.setMessage(msg);
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Actions({
			@Action(value = "/viewpost/{contentId}",
				results = {
						@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/social/post.html")
				})
	})
	public String post() {

		content = graphStoryDAO.getContentDAO().getByContentId(contentId, cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey));

		if (content != null) {
			setTitle(content.getTitle());
		} else {
			setTitle("Social");
		}
		return SUCCESS;
	}

}
