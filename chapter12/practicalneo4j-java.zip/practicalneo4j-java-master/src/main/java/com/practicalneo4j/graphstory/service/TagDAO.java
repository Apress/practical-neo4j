package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.util.List;

import org.apache.log4j.Logger;

import com.practicalneo4j.graphstory.model.mapped.MappedContentTag;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class TagDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(TagDAO.class);

	public GraphStory tagsInMyNetwork(GraphStory graphStory) throws Exception {

		graphStory.setUserTags(userTags(graphStory.getUsername()));
		graphStory.setTagsInNetwork(tagsInNetwork(graphStory.getUsername()));

		return graphStory;
	}

	public List<MappedContentTag> userTags(String username) throws Exception {
		ResultSet rs = cypher.resultSetQuery(
				" MATCH (u:User {username: {1} })-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
						" WITH distinct c " +
						" MATCH c-[ct:HAS]->(t) " +
						" WITH distinct ct,t " +
						" RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id " +
						" ORDER BY id desc " +
						" SKIP 0 LIMIT 30",
				map("1", username));
		ResultSetMapper<MappedContentTag> resultSetMapper = new ResultSetMapper<MappedContentTag>();
		return resultSetMapper.mapResultSetToListMappedClass(rs, MappedContentTag.class);
	}

	public List<MappedContentTag> tagsInNetwork(String username) throws Exception {
		ResultSet rs = cypher.resultSetQuery(
				" MATCH (u:User {username: {1} })-[:FOLLOWS]->f " +
						" WITH distinct f " +
						" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " +
						" WITH distinct c " +
						" MATCH c-[ct:HAS]->(t) " +
						" WITH distinct ct,t " +
						" RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id " +
						" ORDER BY id desc " +
						" SKIP 0 LIMIT 30",
				map("1", username));
		ResultSetMapper<MappedContentTag> resultSetMapper = new ResultSetMapper<MappedContentTag>();
		return resultSetMapper.mapResultSetToListMappedClass(rs, MappedContentTag.class);
	}

	public MappedContentTag[] tagSearch(String q) throws Exception {

		q = q.trim().toLowerCase() + ".*";
		try {

			ResultSet rs = cypher.resultSetQuery(
					" MATCH (c:Content)-[:HAS]->(t:Tag) WHERE t.wordPhrase =~ {1} " +
							" RETURN count(t) as name, TOSTRING(ID(t)) as id, t.wordPhrase as label  " +
							" ORDER BY t.wordPhrase " +
							" LIMIT 5",
					map("1", q));

			ResultSetMapper<MappedContentTag> resultSetMapper = new ResultSetMapper<MappedContentTag>();
			List<MappedContentTag> mappedContentTagResults = resultSetMapper.mapResultSetToListMappedClass(rs, MappedContentTag.class);

			MappedContentTag[] mappedContentTag = new MappedContentTag[mappedContentTagResults.size()];
			return mappedContentTagResults.toArray(mappedContentTag);

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}
}
