package com.practicalneo4j.graphstory.service;


public class GraphStoryExample {

}
