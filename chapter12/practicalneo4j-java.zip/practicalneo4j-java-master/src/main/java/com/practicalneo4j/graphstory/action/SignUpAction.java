package com.practicalneo4j.graphstory.action;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

@ParentPackage("practicalneo4j-struts-default")
@Namespace("/signup")
public class SignUpAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(UserAction.class);

	@Action(value = "add",
		results = {
				@Result(name = "success", type = "redirectAction", params = { "actionName", "thankyou", "namespace", "/" }),
				@Result(name = "userExists", type = "mustache", location = "/mustache/html/home/index.html")
		})
	public String add() {
		try {
			graphStory = getGraphStoryDAO().getUserDAO().save(graphStory);

			if (graphStory.getErrorMsgs().isEmpty()) {
				setTitle("Thank you!");
				return SUCCESS;
			}
			else {
				setTitle("Home");
				return "userExists";
			}
		}
		catch (Exception e) {
			log.error(e);
			return ERROR;
		}

	}

}