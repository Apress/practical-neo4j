package com.practicalneo4j.graphstory.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Content implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long nodeId = null;

	private String contentId;

	private String title;

	private String url;

	private String tagstr;

	private Long timestamp;

	private String userNameForPost;

	private String timestampAsStr;

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTagstr() {
		return tagstr;
	}

	public void setTagstr(String tagstr) {
		this.tagstr = tagstr;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public String getUserNameForPost() {
		return userNameForPost;
	}

	public void setUserNameForPost(String userNameForPost) {
		this.userNameForPost = userNameForPost;
	}

	public String getTimestampAsStr() {
		return timestampAsStr;
	}

	public void setTimestampAsStr(String timestampAsStr) {
		this.timestampAsStr = timestampAsStr;
	}

}
