package com.practicalneo4j.graphstory.action;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-default")
public class LoginAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(LoginAction.class);

	@Action(value = "login",
		results = {
				@Result(name = "success", type = "redirectAction", params = { "actionName", "social", "namespace", "" }),
				@Result(name = "loginfail", type = "mustache", location = "/mustache/html/home/message.html")
		})
	public String checkLogin() {

		try {

			graphStory = graphStoryDAO.getUserDAO().login(graphStory);

			if (noGraphStoryErrors()) {
				response.addCookie(addCookie(GraphStoryConstants.graphstoryUserAuthKey, graphStory.getUser().getUsername()));
				return SUCCESS;
			} else {
				setTitle("Login Failed");
				return "loginfail";
			}

		}
		catch (Exception e) {
			log.error(e);
			return ERROR;
		}
	}

	public String logout() {

		try {
			doLogout();
			return SUCCESS;
		}
		catch (Exception e) {
			log.error(e);
			return ERROR;
		}
	}

	private String r;

	public void setR(String r) {
		this.r = r;
	}

	public String getR() {
		return r;
	}
}
