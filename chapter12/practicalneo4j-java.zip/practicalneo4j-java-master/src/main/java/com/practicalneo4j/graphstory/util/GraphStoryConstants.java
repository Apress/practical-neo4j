package com.practicalneo4j.graphstory.util;

public class GraphStoryConstants {

	public static final String DEFAULT_URL = " https://username:password@host:7473";

	public final static String graphstoryUserAuthKey = "graphstoryUserAuthKey";

	public final static int dayexpiry = 24 * 60 * 60;

	public final static int twoWeekExpiry = 14 * dayexpiry;

	public final static String ROOTPATH = "/";

	public static int getWebPort() {
		String webPort = System.getenv("PORT");
		if (webPort == null || webPort.isEmpty()) {
			return 8080;
		}
		return Integer.parseInt(webPort);
	}

	public static String getNeo4jUrl() {
		String urlVar = System.getenv("NEO4J_REST_URL");
		if (urlVar == null)
			urlVar = "NEO4J_URL";
		String url = System.getenv(urlVar);
		if (url == null || url.isEmpty()) {
			return DEFAULT_URL;
		}
		return url;
	}
}
