package com.practicalneo4j.graphstory.struts;

import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts2.dispatcher.StrutsResultSupport;

import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.config.entities.Parameterizable;

/**
 * The Class MustacheResult.
 * BIG hat tip to https://twitter.com/rzuasti
 * http://ricardozuasti.com/2012/using-mustache-java-templates-with-struts-2/
 * I Added in the rootMustachePath config part.
 */
public class MustacheResult extends StrutsResultSupport implements Parameterizable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The log. */
	static Logger log = Logger.getLogger(MustacheResult.class);

	public MustacheResult() {
		super();
	}

	public MustacheResult(String location) {
		super(location);
	}

	/** The root mustache path. */
	private String rootMustachePath;

	private Boolean cache;

	// create the resource root
	private String resourceRoot;

	/* (non-Javadoc)
	 * @see org.apache.struts2.dispatcher.PlainTextResult#doExecute(java.lang.String, com.opensymphony.xwork2.ActionInvocation)
	 */
	@Override
	public void doExecute(String finalLocation, ActionInvocation invocation) throws Exception {

		try
		{

			HttpServletResponse response = (HttpServletResponse) invocation.getInvocationContext().get(HTTP_RESPONSE);
			ServletContext servletContext = (ServletContext) invocation.getInvocationContext().get(SERVLET_CONTEXT);

			InputStreamReader reader = new FileReader(servletContext.getRealPath(finalLocation));

			// create the resource root
			String resourceRoot = null;

			if (rootMustachePath != null) {
				resourceRoot = rootMustachePath;
			} else {
				resourceRoot = servletContext.getRealPath("/");
			}

			response.setContentType("text/html");
			if (!cache) {
				response.setHeader("Cache-control", "no-cache, no-store, must-revalidate");
				response.setHeader("Cache-Control", "no-store");
				response.setDateHeader("Expires", -1);
				response.setHeader("Pragma", "no-cache");
			}

			PrintWriter writer = response.getWriter();
			// We need to pass the real path of the templates to the Mustache compiler, in order to support nested templates
			MustacheFactory mf = new DefaultMustacheFactory(new File(resourceRoot));

			Mustache mustache = mf.compile(reader, "mustacheResult");

			mustache.execute(writer, invocation.getAction());

			writer.flush();
			writer.close();
		}
		catch (Exception e) {
			log.error(e);
		}

	}

	/**
	 * Gets the root mustache path.
	 * 
	 * @return the root mustache path
	 */
	public String getRootMustachePath() {
		return rootMustachePath;
	}

	/**
	 * Sets the root mustache path.
	 * 
	 * @param rootMustachePath the new root mustache path
	 */
	public void setRootMustachePath(String rootMustachePath) {
		this.rootMustachePath = rootMustachePath;
	}

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.config.entities.Parameterizable#addParam(java.lang.String, java.lang.String)
	 */
	@Override
	public void addParam(String arg0, String arg1) {

	}

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.config.entities.Parameterizable#getParams()
	 */
	@Override
	public Map<String, String> getParams() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.config.entities.Parameterizable#setParams(java.util.Map)
	 */
	@Override
	public void setParams(Map<String, String> arg0) {

	}

	public String getResourceRoot() {
		return resourceRoot;
	}

	public void setResourceRoot(String resourceRoot) {
		this.resourceRoot = resourceRoot;
	}

	public Boolean getCache() {
		return cache;
	}

	public void setCache(Boolean cache) {
		this.cache = cache;
	}

}