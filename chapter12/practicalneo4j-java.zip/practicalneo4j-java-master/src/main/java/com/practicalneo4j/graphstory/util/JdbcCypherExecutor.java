package com.practicalneo4j.graphstory.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;

/**
 * @author Michael Hunger @since 22.10.13
 */
public class JdbcCypherExecutor implements CypherExecutor {

	private final Connection conn;

	static Logger log = Logger.getLogger(JdbcCypherExecutor.class);

	public JdbcCypherExecutor(String uri) {
		try {
			Class.forName("org.neo4j.jdbc.Driver");
			String username = null;
			String password = null;
			URL url = new URL(uri);

			String auth = url.getUserInfo();

			if (auth != null) {
				String[] parts = auth.split(":");
				username = parts[0];
				password = parts[1];

			}

			if (uri.contains("https://")) {
				uri = "jdbc:neo4j:" + url.getProtocol() + "://" + url.getHost() + ":" + url.getPort();
				conn = DriverManager.getConnection(uri, username, password);
			} else {
				conn = DriverManager.getConnection(uri.replace("http://", "jdbc:neo4j://"), username, password);
			}

		}
		catch (SQLException | ClassNotFoundException | MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public ResultSet resultSetQuery(String query, Map<String, Object> params) {
		try {
			final PreparedStatement statement = conn.prepareStatement(query);
			if (params != null) {
				setParameters(statement, params);
			}

			final ResultSet result = statement.executeQuery();
			return result;
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Iterator<Map<String, Object>> iteratorQuery(String query, Map<String, Object> params) {
		try {
			final PreparedStatement statement = conn.prepareStatement(query);
			if (params != null) {
				setParameters(statement, params);
			}
			final ResultSet result = statement.executeQuery();
			return new Iterator<Map<String, Object>>() {

				boolean hasNext = result.next();

				public List<String> columns;

				@Override
				public boolean hasNext() {
					return hasNext;
				}

				private List<String> getColumns() throws SQLException {
					if (columns != null)
						return columns;
					ResultSetMetaData metaData = result.getMetaData();
					int count = metaData.getColumnCount();
					List<String> cols = new ArrayList<>(count);
					for (int i = 1; i <= count; i++)
						cols.add(metaData.getColumnName(i));
					return columns = cols;
				}

				@Override
				public Map<String, Object> next() {
					try {
						if (hasNext) {
							Map<String, Object> map = new LinkedHashMap<>();
							for (String col : getColumns())
								map.put(col, result.getObject(col));
							hasNext = result.next();
							if (!hasNext) {
								result.close();
								statement.close();
							}
							return map;
						} else
							throw new NoSuchElementException();
					}
					catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}

				@Override
				public void remove() {
				}
			};
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	private void setParameters(PreparedStatement statement, Map<String, Object> params) throws SQLException {
		for (Map.Entry<String, Object> entry : params.entrySet()) {
			int index = Integer.parseInt(entry.getKey());
			statement.setObject(index, entry.getValue());

		}
	}
}