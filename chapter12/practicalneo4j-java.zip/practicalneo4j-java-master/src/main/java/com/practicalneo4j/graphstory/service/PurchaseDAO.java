package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.util.List;

import org.apache.log4j.Logger;

import com.practicalneo4j.graphstory.model.mapped.MappedProductUserPurchase;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class PurchaseDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(PurchaseDAO.class);

	public List<MappedProductUserPurchase> friendsPurchase(String username) {
		try {
			ResultSet rs = cypher.resultSetQuery(
					"MATCH (u:User { username : {1} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " +
							" RETURN p.productId as productId, " +
							" p.title as title, " +
							" collect(f.firstname + ' ' + f.lastname) as fullname, " +
							" null as wordPhrase, " +
							" count(f) as cfriends " +
							" ORDER BY cfriends desc, p.title ",
					map("1", username));

			ResultSetMapper<MappedProductUserPurchase> resultSetMapper = new ResultSetMapper<MappedProductUserPurchase>();

			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserPurchase.class);
		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public List<MappedProductUserPurchase> friendsPurchaseByProduct(String title, String username) {
		try {
			ResultSet rs = cypher.resultSetQuery(
					"MATCH (p:Product) " +
							" WHERE lower(p.title) =lower({1}) " +
							" WITH p " +
							" MATCH (u:User { username : {2} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->(p) " +
							" RETURN p.productId as productId,  " +
							" p.title as title, " +
							" collect(f.firstname + ' ' + f.lastname) as fullname, " +
							" null as wordPhrase, count(f) as cfriends " +
							"ORDER BY cfriends desc, p.title ",
					map("1", title, "2", username));

			ResultSetMapper<MappedProductUserPurchase> resultSetMapper = new ResultSetMapper<MappedProductUserPurchase>();

			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserPurchase.class);
		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarity(String username) {
		try {
			ResultSet rs = cypher.resultSetQuery(
					"MATCH (u:User { username : {1} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " +
							" WITH u,p,f " +
							" MATCH u-[:USES]->(t)<-[:HAS]-p " +
							" RETURN p.productId as productId,  " +
							" p.title as title, " +
							" collect(f.firstname + ' ' + f.lastname) as fullname, " +
							" t.wordPhrase as wordPhrase, " +
							" count(f) as cfriends " +
							" ORDER BY cfriends desc, p.title ",
					map("1", username));

			ResultSetMapper<MappedProductUserPurchase> resultSetMapper = new ResultSetMapper<MappedProductUserPurchase>();

			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserPurchase.class);
		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public List<MappedProductUserPurchase> friendsPurchaseTagSimilarityAndProximityToLocation(Double lat, Double lon, Double distance, String username) {
		try {
			ResultSet rs = cypher.resultSetQuery(
					"START n = node:geom({1}) " +
							" WITH n " +
							" MATCH (u:User { username : {2} } )-[:USES]->(t)<-[:HAS]-p " +
							" WITH n,u,p,t " +
							" MATCH u-[:FOLLOWS]->(f)-[:HAS]->(n) " +
							" WITH p,f,t " +
							" MATCH f-[:MADE]->()-[:CONTAINS]->(p) " +
							" RETURN p.productId as productId, " +
							" p.title as title, " +
							" collect(f.firstname + ' ' + f.lastname) as fullname, " +
							" t.wordPhrase as wordPhrase, " +
							" count(f) as cfriends " +
							" ORDER BY cfriends desc, p.title ",
					map("1", distanceQueryAsString(lat, lon, distance), "2", username));

			ResultSetMapper<MappedProductUserPurchase> resultSetMapper = new ResultSetMapper<MappedProductUserPurchase>();

			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserPurchase.class);
		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}
}
