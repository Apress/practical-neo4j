package com.practicalneo4j.graphstory.struts;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.StrutsStatics;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

public class SecurityInterceptor implements Interceptor {

	private static final long serialVersionUID = 1L;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {

		boolean hasLoginCookie = false;

		HttpServletRequest request = (HttpServletRequest) invocation.getInvocationContext().get(StrutsStatics.HTTP_REQUEST);

		if (request.getCookies() != null)
		{
			for (Cookie c : request.getCookies()) {
				if (c.getName().equals(GraphStoryConstants.graphstoryUserAuthKey))
				{
					hasLoginCookie = true;
					break;
				}
			}
		}

		if (hasLoginCookie)
		{
			return invocation.invoke();
		}
		else
		{
			return "needlogin";
		}
	}

}
