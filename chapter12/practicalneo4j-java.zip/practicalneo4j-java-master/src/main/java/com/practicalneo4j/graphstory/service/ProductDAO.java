package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.neo4j.helpers.collection.IteratorUtil;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.practicalneo4j.graphstory.model.Product;
import com.practicalneo4j.graphstory.model.mapped.MappedProduct;
import com.practicalneo4j.graphstory.model.mapped.MappedProductSearch;
import com.practicalneo4j.graphstory.model.mapped.MappedProductUserTag;
import com.practicalneo4j.graphstory.model.mapped.MappedProductUserViews;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class ProductDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(ProductDAO.class);

	public GraphStory getProducts(GraphStory graphStory, int skip) {

		try {
			ResultSet rs = cypher.resultSetQuery(
					" MATCH (p:Product) RETURN ID(p) as nodeId, p.title as title, " +
							" p.description as description, p.tagstr  as tagstr " +
							" ORDER BY p.title " +
							" SKIP {1} LIMIT 11 ",
					map("1", skip));

			ResultSetMapper<MappedProduct> resultSetMapper = new ResultSetMapper<MappedProduct>();
			graphStory.setProducts(resultSetMapper.mapResultSetToListMappedClass(rs, MappedProduct.class));

			if (graphStory.getProducts().size() >= 11) {
				graphStory.setNext(true);
				graphStory.setProducts(graphStory.getProducts().subList(0, 10));

			} else {
				graphStory.setNext(false);
			}
		}
		catch (InstantiationException e) {
			log.error(e);
		}
		catch (IllegalAccessException e) {
			log.error(e);
		}
		catch (Exception e) {
			log.error(e);
		}

		return graphStory;
	}

	public List<MappedProductUserViews> getProductTrail(String username) {

		try {
			ResultSet rs = cypher.resultSetQuery(
					"MATCH (u:User { username: {1} })-[r:VIEWED]->(p) " +
							" RETURN p.title as title, r.dateAsStr as dateAsStr " +
							" ORDER BY r.timestamp DESC ",
					map("1", username));

			ResultSetMapper<MappedProductUserViews> resultSetMapper = new ResultSetMapper<MappedProductUserViews>();
			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserViews.class);

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public List<MappedProductUserViews> addUserViewAndReturnProductTrail(String username, Long productNodeId) {

		try {
			Date timestamp = new Date();
			SimpleDateFormat dformatter = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat tformatter = new SimpleDateFormat("h:mm a");
			String dateAsStr = dformatter.format(timestamp) + " at " + tformatter.format(timestamp);

			ResultSet rs = cypher.resultSetQuery(
					" MATCH (p:Product), (u:User { username:{1} })" +
							" WHERE id(p) = {2}" +
							" WITH u,p" +
							" MERGE (u)-[r:VIEWED]->(p)" +
							" SET r.dateAsStr={3}, r.timestamp={4}" +
							" WITH u " +
							" MATCH (u)-[r:VIEWED]->(p)" +
							" RETURN p.title as title,  r.dateAsStr as dateAsStr" +
							" ORDER BY r.timestamp desc",
					map("1", username, "2", productNodeId, "3", dateAsStr, "4", timestamp.getTime()));

			ResultSetMapper<MappedProductUserViews> resultSetMapper = new ResultSetMapper<MappedProductUserViews>();
			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserViews.class);

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}

	public List<MappedProductUserTag> getProductsHasATagAndUserUsesAMatchingTag() {

		try {

			ResultSet rs = cypher.resultSetQuery(
					"MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) " +
							" RETURN p.title as title, " +
							" collect(u.username) as users, " +
							" collect(distinct t.wordPhrase) as tags", null);

			ResultSetMapper<MappedProductUserTag> resultSetMapper = new ResultSetMapper<MappedProductUserTag>();
			return resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductUserTag.class);

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public Product getProductByNodeId(Long productNodeId) throws Exception {
		Map<String, Object> productMap = null;
		if (productNodeId == null) {
			return null;
		} else {
			productMap = IteratorUtil.singleOrNull(cypher.iteratorQuery(
					" MATCH (product:Product) " +
							" WHERE ID(product)={1} " +
							" RETURN product LIMIT 1 ",
					map("1", productNodeId)));
			ResultSetMapper<Product> userResultSetMapper = new ResultSetMapper<Product>();

			return userResultSetMapper.mapLabelNodeToClass(productMap, Product.class, new ObjectMapper());
		}
	}

	public MappedProductSearch[] search(String q) {
		q = q.trim().toLowerCase() + ".*";
		try {

			ResultSet rs = cypher.resultSetQuery(
					"MATCH (p:Product) " +
							" WHERE lower(p.title) =~ {1} " +
							" RETURN count(*) as name, TOSTRING(ID(p)) as id, " +
							" p.title as label  " +
							" ORDER BY p.title LIMIT 5",
					map("1", q));

			ResultSetMapper<MappedProductSearch> resultSetMapper = new ResultSetMapper<MappedProductSearch>();
			List<MappedProductSearch> mappedProductSearchResults = resultSetMapper.mapResultSetToListMappedClass(rs, MappedProductSearch.class);

			MappedProductSearch[] mappedProductSearch = new MappedProductSearch[mappedProductSearchResults.size()];
			return mappedProductSearchResults.toArray(mappedProductSearch);

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}
}
