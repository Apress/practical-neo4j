package com.practicalneo4j.graphstory.model;

import java.io.Serializable;

import org.neo4j.graphdb.Node;

public class Location implements Serializable {

	private static final long serialVersionUID = 1L;

	private Node node = null;

	private Long nodeId = null;

	private String locationId;

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	public Long getNodeId() {
		return nodeId;
	}

	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

}
