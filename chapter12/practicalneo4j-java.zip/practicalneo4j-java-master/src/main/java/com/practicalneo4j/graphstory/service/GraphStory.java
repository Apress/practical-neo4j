package com.practicalneo4j.graphstory.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.practicalneo4j.graphstory.model.Content;
import com.practicalneo4j.graphstory.model.Product;
import com.practicalneo4j.graphstory.model.User;
import com.practicalneo4j.graphstory.model.mapped.MappedContent;
import com.practicalneo4j.graphstory.model.mapped.MappedContentTag;
import com.practicalneo4j.graphstory.model.mapped.MappedLocation;
import com.practicalneo4j.graphstory.model.mapped.MappedProduct;
import com.practicalneo4j.graphstory.model.mapped.MappedProductSearch;
import com.practicalneo4j.graphstory.model.mapped.MappedProductUserPurchase;
import com.practicalneo4j.graphstory.model.mapped.MappedProductUserTag;
import com.practicalneo4j.graphstory.model.mapped.MappedProductUserViews;

public class GraphStory implements Serializable {

	private static final long serialVersionUID = 1L;

	private User user;

	private User userUpdate;

	private String username;

	private List<String> errorMsgs;

	private Content statusUpdate;

	private MappedContent mappedContent;

	private List<MappedContent> content;

	private List<User> following;

	private List<User> users;

	private Boolean morecontent;

	private List<MappedContentTag> tagsInNetwork;

	private List<MappedContentTag> userTags;

	private MappedContentTag[] tags;

	private List<MappedProduct> products;

	private Boolean next;

	private String nextPageUrl;

	private List<MappedProductUserViews> productTrail;

	private List<MappedProductUserTag> usersWithMatchingTags;

	private Product product;

	private List<MappedLocation> locations;

	private MappedProductSearch[] mappedProductSearch;

	private List<MappedProductUserPurchase> mappedProductUserPurchaseList;

	private Map<String, Object> message;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<String> getErrorMsgs() {
		return errorMsgs;
	}

	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Content getStatusUpdate() {
		return statusUpdate;
	}

	public void setStatusUpdate(Content statusUpdate) {
		this.statusUpdate = statusUpdate;
	}

	public List<MappedContent> getContent() {
		return content;
	}

	public void setContent(List<MappedContent> content) {
		this.content = content;
	}

	public Boolean getMorecontent() {
		return morecontent;
	}

	public void setMorecontent(Boolean morecontent) {
		this.morecontent = morecontent;
	}

	public List<User> getFollowing() {
		return following;
	}

	public void setFollowing(List<User> following) {
		this.following = following;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<MappedContentTag> getTagsInNetwork() {
		return tagsInNetwork;
	}

	public void setTagsInNetwork(List<MappedContentTag> tagsInNetwork) {
		this.tagsInNetwork = tagsInNetwork;
	}

	public List<MappedContentTag> getUserTags() {
		return userTags;
	}

	public void setUserTags(List<MappedContentTag> userTags) {
		this.userTags = userTags;
	}

	public List<MappedProduct> getProducts() {
		return products;
	}

	public void setProducts(List<MappedProduct> products) {
		this.products = products;
	}

	public Boolean getNext() {
		return next;
	}

	public void setNext(Boolean next) {
		this.next = next;
	}

	public String getNextPageUrl() {
		return nextPageUrl;
	}

	public void setNextPageUrl(String nextPageUrl) {
		this.nextPageUrl = nextPageUrl;
	}

	public List<MappedProductUserViews> getProductTrail() {
		return productTrail;
	}

	public void setProductTrail(List<MappedProductUserViews> productTrail) {
		this.productTrail = productTrail;
	}

	public List<MappedProductUserTag> getUsersWithMatchingTags() {
		return usersWithMatchingTags;
	}

	public void setUsersWithMatchingTags(List<MappedProductUserTag> usersWithMatchingTags) {
		this.usersWithMatchingTags = usersWithMatchingTags;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public List<MappedLocation> getLocations() {
		return locations;
	}

	public void setLocations(List<MappedLocation> locations) {
		this.locations = locations;
	}

	public MappedProductSearch[] getMappedProductSearch() {
		return mappedProductSearch;
	}

	public void setMappedProductSearch(MappedProductSearch[] mappedProductSearch) {
		this.mappedProductSearch = mappedProductSearch;
	}

	public List<MappedProductUserPurchase> getMappedProductUserPurchaseList() {
		return mappedProductUserPurchaseList;
	}

	public void setMappedProductUserPurchaseList(List<MappedProductUserPurchase> mappedProductUserPurchaseList) {
		this.mappedProductUserPurchaseList = mappedProductUserPurchaseList;
	}

	public User getUserUpdate() {
		return userUpdate;
	}

	public void setUserUpdate(User userUpdate) {
		this.userUpdate = userUpdate;
	}

	public MappedContent getMappedContent() {
		return mappedContent;
	}

	public void setMappedContent(MappedContent mappedContent) {
		this.mappedContent = mappedContent;
	}

	public Map<String, Object> getMessage() {
		return message;
	}

	public void setMessage(Map<String, Object> message) {
		this.message = message;
	}

	public MappedContentTag[] getTags() {
		return tags;
	}

	public void setTags(MappedContentTag[] tags) {
		this.tags = tags;
	}

}