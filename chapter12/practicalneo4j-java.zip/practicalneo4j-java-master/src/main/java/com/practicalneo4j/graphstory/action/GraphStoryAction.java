package com.practicalneo4j.graphstory.action;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.interceptor.CookiesAware;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.inject.Inject;
import com.practicalneo4j.graphstory.model.mapped.MappedUserLocation;
import com.practicalneo4j.graphstory.service.GraphStory;
import com.practicalneo4j.graphstory.service.GraphStoryDAO;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@Namespace("/")
public class GraphStoryAction extends ActionSupport implements ServletResponseAware, ServletRequestAware, ModelDriven<GraphStory>, CookiesAware, Preparable {

	private static final long serialVersionUID = 1L;

	@Override
	public void prepare() {
		try {
			graphStory.setErrorMsgs(null);
		}
		catch (Exception e) {

		}
	}

	public HttpServletResponse response = null;

	public HttpServletRequest request = null;

	@Inject("graphstory")
	public GraphStory graphStory;

	@Inject("graphStoryDAO")
	public GraphStoryDAO graphStoryDAO;

	public Map<String, String> cookiesMap;

	public String title, graphstoryUserAuthKey;

	public static final int pageNumStart = 0;

	public Integer pagenum;

	public MappedUserLocation mappedUserLocation;

	@Override
	public void setCookiesMap(Map<String, String> cookiesMap) {
		this.cookiesMap = cookiesMap;
	}

	public Map<String, String> getCookiesMap() {
		return cookiesMap;
	}

	@Override
	public GraphStory getModel() {
		return getGraphStory();
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public GraphStory getGraphStory() {
		return graphStory;
	}

	public void setGraphStory(GraphStory graphStory) {
		this.graphStory = graphStory;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public GraphStoryDAO getGraphStoryDAO() {
		return graphStoryDAO;
	}

	public void setGraphStoryDAO(GraphStoryDAO graphStoryDAO) {
		this.graphStoryDAO = graphStoryDAO;
	}

	public String getGraphstoryUserAuthKey() {
		return graphstoryUserAuthKey;
	}

	public void setGraphstoryUserAuthKey(String graphstoryUserAuthKey) {
		this.graphstoryUserAuthKey = graphstoryUserAuthKey;
	}

	public void doLogout() {
		response.addCookie(removeCookie(GraphStoryConstants.graphstoryUserAuthKey));
	}

	public Cookie addCookie(String name, String value) {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(GraphStoryConstants.ROOTPATH);
		cookie.setMaxAge(GraphStoryConstants.twoWeekExpiry);
		// optional
		// cookie.setSecure(true);
		return cookie;
	}

	public Cookie removeCookie(String name) {
		Cookie cookie = new Cookie(name, "");
		cookie.setPath(GraphStoryConstants.ROOTPATH);
		cookie.setMaxAge(0);
		// cookie.setSecure(true);
		return cookie;
	}

	public boolean noGraphStoryErrors() {
		boolean noerrors = true;
		if (graphStory.getErrorMsgs() != null) {
			noerrors = graphStory.getErrorMsgs().isEmpty();
		}
		return noerrors;
	}

	public Integer getPagenum() {
		return pagenum;
	}

	public void setPagenum(Integer pagenum) {
		this.pagenum = pagenum;
	}

	public MappedUserLocation getMappedUserLocation() {
		return mappedUserLocation;
	}

	public void setMappedUserLocation(MappedUserLocation mappedUserLocation) {
		this.mappedUserLocation = mappedUserLocation;
	}

}
