package com.practicalneo4j.graphstory.service;

import com.opensymphony.xwork2.inject.Inject;

public class GraphStoryDAO {

	@Inject("contentDAO")
	private ContentDAO contentDAO;

	@Inject("locationDAO")
	private LocationDAO locationDAO;

	@Inject("productDAO")
	private ProductDAO productDAO;

	@Inject("purchaseDAO")
	private PurchaseDAO purchaseDAO;

	@Inject("tagDAO")
	private TagDAO tagDAO;

	@Inject("userDAO")
	private UserDAO userDAO;

	public GraphStoryDAO() {

	}

	public GraphStoryDAO(ContentDAO contentDAO, LocationDAO locationDAO, ProductDAO productDAO, PurchaseDAO purchaseDAO, TagDAO tagDAO, UserDAO userDAO) {
		this.contentDAO = contentDAO;
		this.locationDAO = locationDAO;
		this.productDAO = productDAO;
		this.purchaseDAO = purchaseDAO;
		this.tagDAO = tagDAO;
		this.userDAO = userDAO;
	}

	public ContentDAO getContentDAO() {
		return contentDAO;
	}

	public void setContentDAO(ContentDAO contentDAO) {
		this.contentDAO = contentDAO;
	}

	public LocationDAO getLocationDAO() {
		return locationDAO;
	}

	public void setLocationDAO(LocationDAO locationDAO) {
		this.locationDAO = locationDAO;
	}

	public ProductDAO getProductDAO() {
		return productDAO;
	}

	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	public PurchaseDAO getPurchaseDAO() {
		return purchaseDAO;
	}

	public void setPurchaseDAO(PurchaseDAO purchaseDAO) {
		this.purchaseDAO = purchaseDAO;
	}

	public TagDAO getTagDAO() {
		return tagDAO;
	}

	public void setTagDAO(TagDAO tagDAO) {
		this.tagDAO = tagDAO;
	}

	public UserDAO getUserDAO() {
		return userDAO;
	}

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

}
