package com.practicalneo4j.graphstory.action;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.practicalneo4j.graphstory.util.GraphStoryConstants;

@ParentPackage("practicalneo4j-struts-secure")
public class UserAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(UserAction.class);

	@Action(value = "user",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/social/user.html"),
		})
	public String showUser() {
		try {
			setTitle("User Settings");
			graphStory.setUser(graphStoryDAO.getUserDAO().getByUserName(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "user/edit", interceptorRefs = {
			@InterceptorRef(value = "cookie", params = { "cookiesName", "graphstoryUserAuthKey" }),
			@InterceptorRef(value = "json", params = { "noCache", "true", "excludeNullProperties", "true" }) },

		results = {
				@Result(name = "success", type = "json", params = { "noCache", "true" })
		})
	public String edit() {
		try {
			if (graphStory.getUser() != null) {
				graphStory.setUser(graphStoryDAO.getUserDAO().update(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), graphStory.getUser()));
			}
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "friends",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/graphs/social/friends.html"),
		})
	public String showFriends() {
		try {
			setTitle("Friends");
			graphStory.setFollowing(graphStoryDAO.getUserDAO().following(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey)));

		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "searchbyusername/{username}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String searchByUsername() {
		try {
			graphStory.setUsers(graphStoryDAO.getUserDAO().searchNotFollowing(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), graphStory.getUsername()));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "follow/{username}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String follow() {
		try {
			graphStory.setFollowing(graphStoryDAO.getUserDAO().follow(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), graphStory.getUsername()));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

	@Action(value = "unfollow/{username}",
		results = {
				@Result(name = "success", type = "json")
		})
	public String unfollow() {
		try {
			graphStory.setFollowing(graphStoryDAO.getUserDAO().unfollow(cookiesMap.get(GraphStoryConstants.graphstoryUserAuthKey), graphStory.getUsername()));
		}
		catch (Exception e) {
			log.error(e);
		}

		return SUCCESS;
	}

}
