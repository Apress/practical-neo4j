package com.practicalneo4j.graphstory.action;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Actions;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

@ParentPackage("practicalneo4j-struts-default")
public class HomeAction extends GraphStoryAction {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(HomeAction.class);

	@Actions({
			// path is /home
			@Action(value = "home",
				results = {
						@Result(name = "success", type = "mustache", location = "/mustache/html/home/index.html")
				}),
			// path is /
			@Action(value = "",
				results = {
						@Result(name = "success", type = "mustache", location = "/mustache/html/home/index.html")
				})
	})
	public String home() {
		setTitle("Home");

		return SUCCESS;
	}

	@Action(value = "thankyou",
		results = {
				@Result(name = "success", type = "mustache", location = "/mustache/html/home/message.html")
		})
	public String thankyou() {
		setTitle("Tell Yours");

		return SUCCESS;
	}
}
