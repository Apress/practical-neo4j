package com.practicalneo4j.graphstory.service;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.TimeBasedGenerator;
import com.practicalneo4j.graphstory.util.CypherExecutor;
import com.practicalneo4j.graphstory.util.GraphStoryConstants;
import com.practicalneo4j.graphstory.util.JdbcCypherExecutor;

public class GraphStoryService {

	static Logger log = Logger.getLogger(GraphStoryService.class);

	public final CypherExecutor cypher;

	public GraphStoryService() {
		cypher = createCypherExecutor();
	}

	public CypherExecutor createCypherExecutor() {

		return new JdbcCypherExecutor(GraphStoryConstants.getNeo4jUrl());

	}

	public GraphStory addErrorMsg(GraphStory graphStory, String msg) {
		if (graphStory.getErrorMsgs() == null) {
			graphStory.setErrorMsgs(new LinkedList<String>());
		}
		graphStory.getErrorMsgs().add(msg);

		return graphStory;

	}

	public HashMap<String, Object> objectAsMap(Object object) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();

		objectMapper.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
		String json = objectMapper.writeValueAsString(object);

		TypeReference<HashMap<String, Object>> typeRef = new TypeReference<HashMap<String, Object>>() {
		};

		HashMap<String, Object> o = objectMapper.readValue(json, typeRef);

		return o;
	}

	public final TimeBasedGenerator uuidGenerator = Generators.timeBasedGenerator();

	public String uuidGen() {
		final UUID uuid = uuidGenerator.generate();
		final StringBuilder sb = new StringBuilder();
		sb.append(Long.toHexString(uuid.getMostSignificantBits())).append(Long.toHexString(uuid.getLeastSignificantBits()));

		return sb.toString();
	}

	public String uuidGenWithTimeStamp() {
		final StringBuilder sb = new StringBuilder();
		sb.append(uuidGen());
		sb.append(String.valueOf(new Date().getTime()));
		return sb.toString();
	}

	public String distanceQueryAsString(Double lat, Double lon, Double distance) {
		StringBuilder lq = new StringBuilder();
		lq.append("withinDistance:[");
		lq.append(Double.toString(lat));
		lq.append(",");
		lq.append(Double.toString(lon));
		lq.append(",");
		lq.append(Double.toString(distance));
		lq.append("]");

		return lq.toString();
	}
}
