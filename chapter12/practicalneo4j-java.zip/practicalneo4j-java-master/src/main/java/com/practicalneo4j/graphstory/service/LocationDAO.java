package com.practicalneo4j.graphstory.service;

import static org.neo4j.helpers.collection.MapUtil.map;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.List;

import org.apache.log4j.Logger;

import com.practicalneo4j.graphstory.model.mapped.MappedLocation;
import com.practicalneo4j.graphstory.util.ResultSetMapper;

public class LocationDAO extends GraphStoryService {

	static Logger log = Logger.getLogger(LocationDAO.class);

	public List<MappedLocation> returnLocationsWithinDistance(Double lat, Double lon, Double distance) {

		try {
			String locationType = "business";
			ResultSet rs = cypher.resultSetQuery(
					"START n = node:geom({1}) WHERE n.type = {2} " +
							" RETURN n.locationId as locationId, n.address as address, " +
							" n.city as city, n.state as state, n.zip as zip, " +
							" n.name as name, n.lat as lat, n.lon as lon",
					map("1", distanceQueryAsString(lat, lon, distance), "2", locationType));

			ResultSetMapper<MappedLocation> resultSetMapper = new ResultSetMapper<MappedLocation>();
			List<MappedLocation> locations = resultSetMapper.mapResultSetToListMappedClass(rs, MappedLocation.class);

			// add the distance in miles to locations
			addDistanceTo(locations, lat, lon);

			return locations;

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}

	}

	public List<MappedLocation> returnLocationsWithinDistanceAndHasProduct(Double lat, Double lon, Double distance, Long productNodeId) {

		try {
			ResultSet rs = cypher.resultSetQuery(
					" START n = node:geom({1}), p=node({2}) " +
							" MATCH n-[:HAS]->p " +
							" RETURN n.locationId as locationId, n.address as address, " +
							" n.city as city, n.state as state, n.zip as zip, " +
							" n.name as name, n.lat as lat, n.lon as lon",
					map("1", distanceQueryAsString(lat, lon, distance), "2", productNodeId));

			ResultSetMapper<MappedLocation> resultSetMapper = new ResultSetMapper<MappedLocation>();
			List<MappedLocation> locations = resultSetMapper.mapResultSetToListMappedClass(rs, MappedLocation.class);

			// add the distance in miles to locations
			addDistanceTo(locations, lat, lon);

			return locations;

		}
		catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	private void addDistanceTo(List<MappedLocation> locations, Double lat, Double lon) {

		for (MappedLocation location : locations) {
			location.setDistanceToLocation(distance(location.getLat(), location.getLon(), lat, lon, 'M'));
		}

	}

	private String distance(double lat1, double lon1, double lat2, double lon2, char unit) {

		StringBuilder distance = new StringBuilder();

		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);

		char K = 'K';
		char N = 'N';
		char M = 'M';

		if (unit == M) {
			dist = dist * 60 * 1.1515;
			DecimalFormat df = new DecimalFormat("#.00");
			distance.append(df.format(dist) + " Miles Away");
		}
		else if (unit == K) {
			dist = dist * 1.609344;
			distance.append(dist + "Kilometers Away");
		} else if (unit == N) {
			dist = dist * 0.8684;
			distance.append(dist + "Nautical Miles Away");
		}
		return distance.toString();
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::  This function converts decimal degrees to radians             :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::  This function converts radians to decimal degrees             :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}

}
