package com.practicalneo4j.graphstory.util;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class ResultSetMapper.
 * 
 * @param <T> the generic type
 */
public class ResultSetMapper<T> {

	/** The log. */
	static Logger log = Logger.getLogger(ResultSetMapper.class);

	/** The columns. */
	public List<String> columns;

	/**
	 * Map label node to class.
	 * Used for a cypher query that returns a specific label node, e.g User
	 * 
	 * @param map the map
	 * @param clazz the clazz
	 * @param mapper the mapper
	 * @return the bean
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IOException
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public T mapLabelNodeToClass(Map<String, Object> map, Class clazz, ObjectMapper mapper) throws InstantiationException, IllegalAccessException, JsonParseException, JsonMappingException, JsonProcessingException, IOException {
		T bean = null;

		if (map != null) {
			bean = (T) clazz.newInstance();

			for (Map.Entry<String, Object> entry : map.entrySet()) {
				// get the value of the SQL column
				Object columnValue = entry.getValue();

				bean = (T) mapper.readValue(mapper.writeValueAsString(columnValue), clazz);
			}
		}

		return bean;
	}

	/**
	 * Map ResultSet to list of objects.
	 * 
	 * @param result - the ResultSet from the resulting query
	 * @param clazz the clazz
	 * @return the list of mapped objects
	 * @throws IOException
	 * @throws JsonProcessingException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	@SuppressWarnings({ "rawtypes" })
	public List<T> mapRersultSetToObject(ResultSet result, Class clazz) throws JsonParseException, JsonMappingException, InstantiationException, IllegalAccessException, JsonProcessingException, IOException {

		List<T> outputList = null;

		Iterator<Map<String, Object>> iterator = query(result);

		// make sure resultset is not null
		if (iterator != null) {
			// check if Class clazz has the 'Entity' annotation

			ObjectMapper mapper = new ObjectMapper();

			while (iterator.hasNext()) {
				T bean = mapLabelNodeToClass(iterator.next(), clazz, mapper);

				if (outputList == null) {
					outputList = new LinkedList<T>();
				}
				outputList.add(bean);
			} // EndOf while(rs.next())
		} else {
			// ResultSet is empty
			return null;
		}

		return outputList;
	}

	/**
	 * Map result set to mapped class.
	 * 
	 * @param map the map
	 * @param clazz the clazz
	 * @return the t
	 * @throws InstantiationException the instantiation exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public T mapResultSetToMappedClass(Map<String, Object> map, Class clazz) {

		T bean = null;

		if (map != null) {
			ObjectMapper mapper = new ObjectMapper();

			bean = (T) mapper.convertValue(map, clazz);
		}

		return bean;
	}

	/**
	 * Map result set to list mapped class.
	 * 
	 * @param result the result
	 * @param clazz the clazz
	 * @return the list
	 * @throws InstantiationException the instantiation exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<T> mapResultSetToListMappedClass(ResultSet result, Class clazz) throws InstantiationException, IllegalAccessException {

		List<T> outputList = null;
		Iterator<Map<String, Object>> iterator = query(result);
		// make sure resultset is not null
		if (iterator != null) {
			ObjectMapper mapper = new ObjectMapper();
			// check if Class clazz has the 'Entity' annotation
			while (iterator.hasNext()) {
				T bean;
				bean = (T) clazz.newInstance();

				Map<String, Object> map = iterator.next();
				bean = (T) mapper.convertValue(map, clazz);
				if (outputList == null) {
					outputList = new LinkedList<T>();
				}
				outputList.add(bean);
			} // EndOf while(rs.next())
		} else {
			// ResultSet is empty
			return null;
		}

		return outputList;
	}

	/**
	 * Query.
	 * 
	 * @param result the result
	 * @return the iterator
	 */
	private Iterator<Map<String, Object>> query(final ResultSet result) {
		try {
			return new Iterator<Map<String, Object>>() {

				boolean hasNext = result.next();

				public List<String> columns;

				@Override
				public boolean hasNext() {
					return hasNext;
				}

				private List<String> getColumns() throws SQLException {
					if (columns != null)
						return columns;
					ResultSetMetaData metaData = result.getMetaData();
					int count = metaData.getColumnCount();
					List<String> cols = new ArrayList<>(count);
					for (int i = 1; i <= count; i++)
						cols.add(metaData.getColumnName(i));
					return columns = cols;
				}

				@Override
				public Map<String, Object> next() {
					try {
						if (hasNext) {
							Map<String, Object> map = new LinkedHashMap<>();
							for (String col : getColumns())
								map.put(col, result.getObject(col));
							hasNext = result.next();
							if (!hasNext) {
								result.close();
							}
							return map;
						} else
							throw new NoSuchElementException();
					}
					catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}

				@Override
				public void remove() {
				}

			};
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
