package com.practicalneo4j.graphstory.struts;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import org.apache.struts2.rest.handler.ContentTypeHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.opensymphony.xwork2.inject.Inject;

public class JacksonLibHandler implements ContentTypeHandler {


	private static final String DEFAULT_CONTENT_TYPE = "application/json";

	private String defaultEncoding;

	private ObjectMapper mapper;

	public JacksonLibHandler() {
		defaultEncoding = "ISO-8859-1";
		mapper = new ObjectMapper();
	}

	public void toObject(Reader paramReader, Object paramObject) throws IOException {
		ObjectReader or = mapper.readerForUpdating(paramObject);
		or.readValue(paramReader);
	}

	public String fromObject(Object paramObject, String paramString, Writer paramWriter) throws IOException {
		mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
		mapper.writeValue(paramWriter, paramObject);
		return null;
	}

	public String getContentType() {
		return DEFAULT_CONTENT_TYPE + ";charset=" + defaultEncoding;
	}

	public String getExtension() {
		return "json";
	}

	@Inject("struts.i18n.encoding")
	public void setDefaultEncoding(String val) {
		defaultEncoding = val;
	}

}
