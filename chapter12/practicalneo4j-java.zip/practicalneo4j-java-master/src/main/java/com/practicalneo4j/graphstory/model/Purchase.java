package com.practicalneo4j.graphstory.model;

public class Purchase {

}
