package com.practicalneo4j.graphstory.model.mapped;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class MappedProductUserViews {

	private String title, dateAsStr;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDateAsStr() {
		return dateAsStr;
	}

	public void setDateAsStr(String dateAsStr) {
		this.dateAsStr = dateAsStr;
	}

}
