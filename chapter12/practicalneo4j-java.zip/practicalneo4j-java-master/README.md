Practical Neo4j for Java
==================

I used Eclipse 3.7 with JDK 7 for this project.  

After the project has been downloaed and unpacked, then you should:

1. Setup a Neo4j instance by going to www.graphstory.com/practicalneo4j
2. Copy the database connection information
3. Import the project into your IDE
4. Update the database connection information in the {projectroot}/src/main/java/com/practicalneo4j/graphstory/util/GraphStoryConstants.java file with your connection information
5. Update your tomcat server.xml by adding a host similar to the one below. Make sure to update the "aliases" element within the Context

	```xml
	<Host name="practicalneo4j-java" appBase="/path/to/your/practicalneo4j-java/WebContent" unpackWARs="true" autoDeploy="true" >
		<Context path="" docBase="" aliases="/resources=/path/to/your/practicalneo4j-java/WebContent/resources" 
			reloadable="true" swallowOutput="true" antiResourceLocking="false" cachingAllowed="false" />
	</Host>
	```
6. Configure your web server. The virtual host configuration for apache web server is below:

	```xml
	<VirtualHost *:80>
		ServerName practicalneo4j-java
		ProxyPreserveHost On
		ProxyPass / http://practicalneo4j-java:8090/
		ProxyPassReverse / http://practicalneo4j-java:8090/
	</VirtualHost>
	```
