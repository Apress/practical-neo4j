Practical Neo4j - Chapter 6 - Extending Neo4j
==============================

I used Eclipse 3.7 with JDK 7 for this project.  

You will also need Maven installed to build this project.

Once the project has been imported, then you should:

1. run maven clean
2. run maven install
3. the new jar should be available in target folder.

