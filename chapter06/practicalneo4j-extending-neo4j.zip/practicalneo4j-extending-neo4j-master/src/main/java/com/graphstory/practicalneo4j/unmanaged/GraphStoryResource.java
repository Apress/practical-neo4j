package com.graphstory.practicalneo4j.unmanaged;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.neo4j.graphdb.GraphDatabaseService;

@Path("/graphstory")
public class GraphStoryResource
{
	private final GraphDatabaseService database;

	public GraphStoryResource(@Context GraphDatabaseService database)
	{
		this.database = database;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/dbname")
	public Response dbAvailable() throws JsonGenerationException, JsonMappingException, IOException
	{
		// Do stuff with the database
		ObjectMapper objectMapper = new ObjectMapper();

		return Response.status(Status.OK).entity(objectMapper.writeValueAsString(database.isAvailable(5000))).build();
	}
}
