package com.graphstory.practicalneo4j.plugin;

import java.util.ArrayList;

import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.Transaction;
import org.neo4j.server.plugins.Description;
import org.neo4j.server.plugins.PluginTarget;
import org.neo4j.server.plugins.ServerPlugin;
import org.neo4j.server.plugins.Source;

@Description("An extension to the Neo4j Server for getting all nodes or relationships")
public class GraphStoryPlugin extends ServerPlugin {

	@Description("Get all nodes related to this node")
	@PluginTarget(Node.class)
	public Iterable<Relationship> getRelatedNodes(@Source Node node)
	{
		ArrayList<Relationship> relationships = new ArrayList<>();

		try (Transaction tx = node.getGraphDatabase().beginTx())
		{
			for (Relationship relationship : node.getRelationships(Direction.BOTH))
			{
				relationships.add(relationship);
			}
			tx.success();
		}
		return relationships;
	}
}
