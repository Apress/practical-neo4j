package com.graphstory.practicalneo4j;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.neo4j.server.rest.security.SecurityFilter;
import org.neo4j.server.rest.security.SecurityRule;

public class GraphStoryIPCheck implements SecurityRule {

	public static final String REALM = "GraphStory";

	@Override
	public boolean isAuthorized(HttpServletRequest request)
	{
		String IPs[] = { "128.0.0.1", "173.193.188.115" };

		if (Arrays.asList(IPs).contains(request.getRemoteAddr())) {
			System.out.println("passed");
			return true;
		}
		else {
			System.out.println("did not pass");
			return false;
		}
	}

	@Override
	public String forUriPath()
	{
		return "/*";
	}

	@Override
	public String wwwAuthenticateHeader()
	{
		return SecurityFilter.basicAuthenticationResponse(REALM);
	}
}
