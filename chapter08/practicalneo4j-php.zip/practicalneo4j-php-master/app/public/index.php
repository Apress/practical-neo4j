<?php
error_reporting(-1);
ini_set("display_errors", 1);

define('APPLICATION_PATH', realpath(dirname(__DIR__)));

require_once APPLICATION_PATH . '/vendor/autoload.php';
require_once APPLICATION_PATH . '/service/AppConfig.php';
require_once APPLICATION_PATH . '/service/Neo4jClient.php';
require_once APPLICATION_PATH . '/service/Content.php';
require_once APPLICATION_PATH . '/service/Location.php';
require_once APPLICATION_PATH . '/service/Product.php';
require_once APPLICATION_PATH . '/service/Purchase.php';
require_once APPLICATION_PATH . '/service/Tag.php';
require_once APPLICATION_PATH . '/service/User.php';
require_once APPLICATION_PATH . '/service/UserLocation.php';

use Slim\Mustache\Mustache;
use Slim\Slim;

// Prepare app
$logWriter = new \Slim\LogWriter(fopen(APPLICATION_PATH .'/logs/practicalneo4j-php-debug.log', 'a'));
$app = new \Slim\Slim(array(
    'log.enabled' =>    true,
    'log.level' =>      \Slim\Log::DEBUG,
    'log.writer' => $logWriter,
    'templates.path' => APPLICATION_PATH . '/templates',
));

$app->add(new \Slim\Middleware\SessionCookie(array(
    'expires' => '60 minutes',
    'path' => '/',
)));

$app->view(new Mustache());
$app->view->parserOptions = array(
	'cache' => '/tmp/mustache-cache',
    'pragmas' => array(\Mustache_Engine::PRAGMA_BLOCKS,),
);

$isLoggedIn = function () use ($app) {
	if(!isset($_SESSION['username']) && empty($_SESSION['username'])) {
   		$app->redirect('/'); 
   	}
};

// neo client
Neo4Client::setClient($neo4jClient);

$app->get('/', function () use ($app) {
	 $app->render('home/index.mustache');
})->name('home');

// create new user & redirect
$app->post('/signup/add', function() use ($app){
    $params = $app->request()->post();
	// make sure the user name was passed.
	$username = trim($params['username']);
	
	//FYI - this is one way to log with SLIM 
	// $app->log->debug('some message then a variable: ' . $username);
    
    if (!empty($username)) {
    	// lower case the username.  
		$username=strtolower($username);
		
    	// see if there's already a User node with this username
        $checkuser = User::getByUsername($username);
		
		//No? then save it
        if(is_null($checkuser)){
        	// setup the object
            $user = new User();
            $user->username = $username;
			// save it            
            User::saveUser($user);
			// redirect to thank you page
            $app->redirect('/thankyou?u='.$username);    
        }
		// show the "try again" message.
        else {
            $app->view()->setData(array('error' => 'The username "'.$username.'" already exists. Please try again.'));
            $app->render('home/index.mustache');
        }
	// username field was empty
    } else {
        $app->view()->setData(array('error' => 'Please enter a username.'));
        $app->render('home/index.mustache');
    }
});


// login
$app->post('/login', function() use ($app){
    $params = $app->request()->post();
	
	// make sure the user name was passed.
	$username = trim($params['username']);
	
	if (!empty($username)) {
		// lower case the username.  
		$username=strtolower($username);
		$checkuser = User::getByUsername($username);
		
		// match
		if(!is_null($checkuser)){
			
			$_SESSION['username'] = $username;
			
			$app->redirect('/social');
		}else{
    		$app->view()->setData(array('msg' => 'The username you entered was not found.'));
			$app->render('home/message.mustache');	
		}
	}
	else{
    	$app->view()->setData(array('msg' => 'Please enter a username.'));
		$app->render('home/message.mustache');
	}
	
})->name('login');

// create user success - always say 'thank you!'
$app->get('/thankyou', function() use ($app){
    // personalize with the username
    $app->view()->setData(array('msg' => 'Thank you, '.$_GET['u']. '!'));
	$app->render('home/message.mustache');
})->name('thank-you');

############################################################
# user & friends
############################################################

// show user form
$app->get('/user', $isLoggedIn, function() use ($app){
	$user = User::getByUsername($_SESSION['username']);
	$app->view()->setData(array('user' => $user, 
			'title'=>'User Settings'));
	$app->render('graphs/social/user.mustache');
});

// edit a user
$app->put('/user/edit', function() use ($app){
	$params = json_decode($app->request()->getBody());
	$user=User::updateUser($_SESSION['username'],$params->firstname,$params->lastname);
	echo json_encode($user);
});

// friends route that shows connected users via FOLLOW relationship
$app->get('/friends', $isLoggedIn, function() use ($app){
	$user = User::getByUsername($_SESSION['username']);
	$following =  User::following($_SESSION['username']);
	$app->view()->setData(array('user' => $user,
			'following' => $following,
			'title'=>'User Settings'));
	$app->render('graphs/social/friends.mustache');
});

// takes current user session and will follow :username, e.g. one way follow
$app->get('/follow/:username', function ($username) use ($app) {
	$following = User::follow($_SESSION['username'], $username);
	echo '{"following": ' . json_encode($following) . '}';
});

// takes current user session and will unfollow :username
$app->get('/unfollow/:username', function ($username) use ($app) {
	$following = User::unfollow($_SESSION['username'], $username);
	echo '{"following": ' . json_encode($following) . '}';
});

//search users by name
$app->get('/searchbyusername/:u', function($u) use ($app){
	$users = User::searchByUsername($u,$_SESSION['username']);
	echo '{"users": ' . json_encode($users) . '}';
});

############################################################
# social graph
############################################################

// social - show posts
$app->get('/social', $isLoggedIn, function() use ($app){
	
	$c =  Content::getContent($_SESSION['username'],0);
	
	$content = array_slice($c, 0, 3);
	
	$moreContent = (count($c) >= 4);
	
	$app->view()->setData(array(
			'morecontent'=>$moreContent,
			'content' => $content,
			'title' => 'Social'));
	$app->render('graphs/social/posts.mustache');
})->name('content');

// social - return posts via JSON
$app->get('/postsfeed/:s', $isLoggedIn, function( $s) use ($app){
	$content =  Content::getContent($_SESSION['username'], (int) $s);
	echo '{"content": ' . json_encode($content) . '}';
})->name('more-content');

// social - show post
$app->get('/viewpost/:contentId', $isLoggedIn, function($contentId) use ($app){
	$post =  Content::getStatusUpdate($contentId,$_SESSION['username']);
	$content = new Content();
	if (!empty($post)) {
		$content = 	$post[0];
	}
	$app->view()->setData(array('usr' => $_SESSION['username'], 'content' => $content));
	$app->render('graphs/social/post.mustache');
})->name('view-content');


// add a status update - route
$app->post('/posts/add', function() use ($app){
	$request = $app->request();
    $contentParams = json_decode($request->getBody());
    
	$content = new Content();
	$content->title=$contentParams->title;
	$content->url=$contentParams->url;
	
	// are tags set?
	if(isset($contentParams->tagstr)){
		$content->tagstr=$contentParams->tagstr;
	}
	$content =  Content::addContent($_SESSION['username'], $content);
	
	$app->response->headers->set('Content-Type', 'application/json');
	
	echo json_encode($content);
	
})->name('add-content');

// edit a status update - route
$app->put('/posts/edit', function() use ($app){
	$request = $app->request();
    $contentParams = json_decode($request->getBody());
    $content = Content::getStatusUpdate(
    		$contentParams->contentId,
    		$_SESSION['username']
    		
    );
    $content = $content[0];
    
    $content->title=$contentParams->title;
	$content->url=$contentParams->url;
	
	// are tags set?
	if (isset($contentParams->tagstr)) {
		$content->tagstr = $contentParams->tagstr;
	}
	
	$content =  Content::editContent($_SESSION['username'], $content);
    
	$app->response->headers->set('Content-Type', 'application/json');
	
	echo json_encode($content);
})->name('edit-content');

// remove a status update
$app->get('/posts/delete/:contentId', function ($contentId) use ($app) {
	Content::deleteContent($_SESSION['username'],$contentId);
})->name('delete-content');

############################################################
# interest graph
############################################################

# show tags within the user's network (theirs and those being followed)
$app->get('/interest', $isLoggedIn,  function () use ($app) {
	
	# get the user's tags
	$userTags = Tag::userTags($_SESSION['username']);

	# get the tags of user's friends
	$tagsInNetwork=Tag::tagsInNetwork($_SESSION['username']);

	$contents = null;
	
	$userscontent = $app->request()->get('userscontent');
	
	if(!empty($userscontent)){

		$tag = $app->request()->get('tag');
		
		# if the user's content was requested
		if($userscontent === "true"){
			$contents = Content::getUserContentWithTag($_SESSION['username'],$tag);
		# if the user's friends' content was requested
		}else{
			$contents = Content::getFollowingContentWithTag($_SESSION['username'],$tag);
		}
	}
	
	$app->view()->setData(array('contents'=>$contents, 
			'userTags'=>$userTags,
			'tagsInNetwork'=>$tagsInNetwork,
			'title'=>'Interest'));
	$app->render('graphs/interest/index.mustache');
})->name('interest');

#tag search 
$app->get('/tag/:q', function($q) use ($app){
	# get matches
	$tags = Tag::searchTags($q);

	$app->response->headers->set('Content-Type', 'application/json');

	echo json_encode($tags);

})->name('tagsearch');

############################################################
# consumption graph
############################################################

# show products and products VIEWED by user
$app->get('/consumption', $isLoggedIn,  function() use ($app){
	# get products by page
	$products = Product::getProducts(0);
	
	$next = true;

	$nextPageUrl = "/consumption/10";
	
	$productTrail = Product::getProductTrail($_SESSION['username']);

	$app->view()->setData(array('products'=>$products, 
			'next'=>$next,
			'nextPageUrl'=>$nextPageUrl, 
			'productTrail'=>$productTrail,
			'title'=>'Consumption'));
	$app->render('graphs/consumption/index.mustache');
})->name('consumption');


// displays products that are connected to users via a tag relationship
$app->get('/consumption/console', $isLoggedIn,  function() use ($app){

	$usersWithMatchingTags = null;

	$tag = $app->request()->get('tag');

	# was tag supplied, then get product matches based on specific tag
	if(!empty($tag)){
		$usersWithMatchingTags = Product::getProductsHasSpecificTagAndUserUsesSpecificTag($tag);
	}else{
		$usersWithMatchingTags = Product::getProductsHasATagAndUserUsesAMatchingTag();
	}

	$app->view()->setData(array('usersWithMatchingTags'=>$usersWithMatchingTags,
			'title'=>'Consumption Console'));
	$app->render('graphs/consumption/console.mustache');
})->name('consumption-console');

# return partial - helps to perform auto scroll of products
$app->get('/consumption/:pagenum', function($pagenum) use ($app){
	$curpage = intval($pagenum);
	
	# get products for this page
	$products = Product::getProducts($curpage);
	
	# bump the page total
	$next = true;
	$curpage = $curpage + 10;
	
	# set the next GET route
	$nextPageUrl = "/consumption/" . strval($curpage);
	
	$app->view()->setData(array('products'=>$products, 
			'next'=>$next,
			'nextPageUrl'=>$nextPageUrl));
	$app->render('graphs/consumption/product-list.mustache');
})->name('consumption-page');

# add a product via VIEWED relationship and return VIEWED products
$app->get('/consumption/add/:productNodeId', function($productNodeId) use ($app){
	
	#save the view and return the full list of views
	$productTrail=Product::createUserViewAndReturnViews($_SESSION['username'],$productNodeId);

	$app->response->headers->set('Content-Type', 'application/json');
	
	echo '{"productTrail": ' . json_encode($productTrail) . '}';
	
})->name('consumption-add');


############################################################
# location graph
############################################################

$app->get('/location', $isLoggedIn,  function() use ($app){           
        
    // get the user's locations
    $userlocations = UserLocation::getUserLocation($_SESSION['username']);
    
    #was distances provided
    $distance = $app->request()->get('distance');
    
    if (!empty($distance)) {
        # use first location
        $ul = $userlocations[0];
        
        $productNodeId = $app->request()->get('productNodeId');
        
        $lq = UserLocation::getLQ($ul,$distance);
        
        if (!empty($productNodeId)) {
        	
            $locations = Location::locationsWithinDistanceWithProduct($lq,$ul,$productNodeId);
            $app->view()->setData(array('locations' => $locations, 
                'mappedUserLocation'=>$userlocations));
        }
        else{
            $locations = Location::locationsWithinDistance($lq, $ul,"business");
            $app->view()->setData(array('locations' => $locations, 
                'mappedUserLocation'=>$userlocations));
        }    
        
    }
    else{
        $app->view()->setData(array('mappedUserLocation'=>$userlocations));
    }
    $app->view()->setData(array('title'=>'Location'));
    $app->render('graphs/location/index.mustache');
    
})->name('location');

// return product array as json
$app->get('/productsearch/:q', function($q) use ($app){
    # get matches
    $productsFound = Product::productSearch($q);

    $app->response->headers->set('Content-Type', 'application/json');
    
    echo json_encode($productsFound);

})->name('productsearch');


############################################################
# intent graph
############################################################

// purchases by friends
$app->get('/intent', $isLoggedIn,  function() use ($app){
    $mappedProductUserPurchaseList = Purchase::friendsPurchase($_SESSION['username']);
    $app->view()->setData(array(
    	'mappedProductUserPurchaseList' => $mappedProductUserPurchaseList, 
        'title' =>"Products Purchased by Friends"));
    $app->render('graphs/intent/index.mustache');
})->name('intent');

// specific product purchases by friends
$app->get('/intent/friendsPurchaseByProduct', $isLoggedIn,  function() use ($app){
    $mappedProductUserPurchaseList = Purchase::friendsPurchaseByProduct(
    		$_SESSION['username'],
    		"Star Wars Mimobot Thumb Drives");
    $app->view()->setData(array(
    	'mappedProductUserPurchaseList' => $mappedProductUserPurchaseList, 
        'title' =>"Specific Products Purchased by Friends"));
    $app->render('graphs/intent/index.mustache');
})->name('friendsPurchaseByProduct');

// friends bought specific products. match these products to tags of the current user
$app->get('/intent/friendsPurchaseTagSimilarity', $isLoggedIn,  function() use ($app){
    $mappedProductUserPurchaseList = Purchase::friendsPurchaseTagSimilarity(
    		$_SESSION['username']);
    $app->view()->setData(array(
    		'mappedProductUserPurchaseList' => $mappedProductUserPurchaseList, 
        'title' =>"Products Purchased by Friends and Matches User's Tags"));
    $app->render('graphs/intent/index.mustache');
})->name('friendsPurchaseTagSimilarity');

// friends that are nearby bought this product. the product should also matches tags of the current user
$app->get('/intent/friendsPurchaseTagSimilarityAndProximityToLocation',
		 $isLoggedIn,  function() use ($app){
    // get the user's locations
    $userlocations = UserLocation::getUserLocation($_SESSION['username']);
    
    // create the location query using first location
    $lq = UserLocation::getLQ($userlocations[0],"10.00");
    
    # get result set
    $mappedProductUserPurchaseList = 
    Purchase::friendsPurchaseTagSimilarityAndProximityToLocation($_SESSION['username'],$lq);
    
    $app->view()->setData(array(
    	'mappedProductUserPurchaseList' => $mappedProductUserPurchaseList, 
        'mappedUserLocation'=>$userlocations, 
        'title' =>"Products Purchased by Friends Nearby and Matches User's Tags"));
    $app->render('graphs/intent/index.mustache');
})->name('friendsPurchaseTagSimilarityAndProximityToLocation');

// Run app
$app->run();