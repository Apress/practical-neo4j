<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;

class Content {
	protected $node = null;
	public $id = null;
	public $title = '';
	public $url = '';
	public $tagstr = '';
	public $timestampAsStr = '';
	public $contentId = '';
	public $username = '';
	public $owner = false;
	
	
	public static function getContent($username, $s) {
		// we're doing LIMIT 4.  at present were' only displaying 3. the extra item 
		// is to ensure there's more to view, so the next skip will be 3, then 6, then 12
		$queryString = " MATCH (u:User {username: {u} })-[:FOLLOWS*0..1]->f  " .
				" WITH DISTINCT f,u " .
				" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..3]-p   " .
				" RETURN  p, f.username as username, f=u as owner  " .
				" ORDER BY p.timestamp desc SKIP {s} LIMIT 4 ";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username,
				's' => $s
		));
		$result = $query->getResultSet();
		return self::returnMappedContent($result);
	}
	
	public static function getStatusUpdate($contentId, $username) {
		$queryString = " MATCH (p:Content {contentId:{contentId}})-[:NEXTPOST*0..]-()-[:CURRENTPOST]-(o:User), " .
		" (u:User {username: {u} }) " .
		" RETURN p, o.username as username, o=u as owner ";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'contentId' => $contentId,
				'u' => $username,
		));
		$result = $query->getResultSet();
		
		return self::returnMappedContent($result);
	}
	// add a status update
	public static function addContent($username, Content $content) {
			
		$tagstr=self::trimContentTags($content->tagstr);
		$tags=explode(',', $tagstr);
	
		$queryString = " MATCH (user { username: {u}}) " .
	        " CREATE UNIQUE (user)-[:CURRENTPOST]->(p:Content { title:{title}, url:{url}, " .
	        " tagstr:{tagstr}, timestamp:{timestamp}, contentId:{contentId} }) " .
	        " WITH user, p" .
	        " FOREACH (tagName in {tags} |  " .
	        " MERGE (t:Tag {wordPhrase:tagName}) " .
	        " MERGE (p)-[:HAS]->(t) " .
	        " )" .
	        " WITH user, p " .
			" OPTIONAL MATCH  (p)<-[:CURRENTPOST]-(user)-[oldRel:CURRENTPOST]->(oldLP)" .
			" DELETE oldRel " .
			" CREATE (p)-[:NEXTPOST]->(oldLP) " .
			" RETURN p, {u} as username, true as owner ";
			
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username,
				'title' => $content->title,
				'url' => $content->url,
				'tagstr' =>  $tagstr,
				'tags' => $tags,
				'timestamp' => time(),
				'contentId' => uniqid()
		));
		$result = $query->getResultSet();
		return self::returnMappedContent($result);
	}

	// edit a status update
	public static function editContent($username, Content $content) {
		
		$tagstr=self::trimContentTags($content->tagstr);
		$tags=explode(',', $tagstr);
			
		$queryString =  " MATCH (p:Content { contentId: {contentId} } )-[:NEXTPOST*0..]".
			"-()-[:CURRENTPOST]-(user { username: {u} } ) " .
			" SET p.title = {title}, p.url = {url}, p.tagstr = {tagstr}" .
			" FOREACH (tagName in {tags} |  " .
			" MERGE (t:Tag {wordPhrase:tagName}) " .
			" MERGE (p)-[:HAS]->(t) " .
			" )" .
			" RETURN p, {u} as username, true as owner " ;
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'contentId' => $content->contentId,
				'u' => $username,
				'title' => $content->title,
				'url' => $content->url,
				'tagstr' =>  $tagstr,
				'tags' => $tags
		));
		$result = $query->getResultSet();
		return self::returnMappedContent($result);
	}
	
	public static function deleteContent($username, $contentId) {
	
		$queryString = " MATCH (u:User { username: {u} }), (c:Content { contentId: {contentId} }) " .
		" WITH u,c " .
		" MATCH (u)-[:CURRENTPOST]->(c)-[:NEXTPOST]->(nextPost) " .
	    " WHERE nextPost is not null " .
		" CREATE UNIQUE (u)-[:CURRENTPOST]->(nextPost) " .
		" WITH count(nextPost) as cnt " .
		" MATCH (before)-[:NEXTPOST]->(c:Content { contentId: {contentId}})-[:NEXTPOST]->(after) " .
		" WHERE before is not null AND after is not null " .
		" CREATE UNIQUE (before)-[:NEXTPOST]->(after) " .
		" WITH count(before) as cnt " .
		" MATCH (c:Content { contentId: {contentId} })-[r]-() " .
		" DELETE c, r";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
			'u' => $username,
			'contentId' => $contentId
		));
		$query->getResultSet();
	
	}

	public static function returnMappedContent($results) {
		$mappedContentArray = array();
		foreach ($results as $row) {
			$mappedContentArray[] = self::fromMappedContentArray($row['p'], $row['username'], $row['owner']);
		}
		return $mappedContentArray;
	}

	public static function fromMappedContentArray(Node $cnode, $username, $owner) {
		$content = new Content();
		$content -> id = $cnode -> getId();
		$content -> title = $cnode -> getProperty('title');
		$content -> url = $cnode -> getProperty('url');
		$content -> tagstr = $cnode -> getProperty('tagstr');
		$content -> contentId = $cnode -> getProperty('contentId');
		$content -> timestampAsStr = gmdate("F j, Y g:i a", $cnode -> getProperty('timestamp'));
		$content -> owner = $owner;
		$content -> username = $username;
		$content -> node = $content;

		return $content;
	}

	public static function getByNodeId($id) {
		$node = Neo4Client::client() -> getNode($id);
		$content = new Content();
		$content -> id = $node -> getId();
		$content -> title = $node -> getProperty('title');
		$content -> url = $node -> getProperty('url');
		$content -> tagstr = $node -> getProperty('tagstr');
		$content -> contentId = $node -> getProperty('contentId');
        $content -> node = $node;
        return $content;
    }
    
	public static function getUserContentWithTag($username,$wp){
		$queryString = " MATCH (u:User {username: {u} })-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p " .
		" WITH DISTINCT u,p" .
		" MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" .
		" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " .
		" p.timestamp as timestamp, p.url as url, u.username as username, true as owner" .
		" ORDER BY p.timestamp DESC";
	   
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
	   		'u' => $username,
	   		'wp' => $wp
	   	));
		$result = $query->getResultSet();
	    
		foreach($result as $row){
	   		$row->timestampAsStr = date('n/d/Y',$row['timestamp']) . 
	   			' at ' . date('g:i A',$row['timestamp']);
		}
	    	
		return $result;
	}
    
	public static function getFollowingContentWithTag($username,$wp){
		$queryString = " MATCH (u:User {username: {u} })-[:FOLLOWS]->f" .
		" WITH DISTINCT f" .
	   	" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-p" .
	  	" WITH DISTINCT f,p" .
	   	" MATCH p-[:HAS]-(t:Tag {wordPhrase : {wp} } )" .
	   	" RETURN  p.contentId as contentId, p.title as title, p.tagstr as tagstr, " .
	   	" p.timestamp as timestamp, p.url as url, f.username as username, false as owner" .
	   	" ORDER BY p.timestamp DESC";
	    
	   	$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
			'u' => $username,
	    	'wp' => $wp
		));
	    $result = $query->getResultSet();
	    
	    foreach($result as $row){
	    	$row->timestampAsStr = date('n/d/Y',$row['timestamp']) . ' at ' . date('g:i A',$row['timestamp']);
	    }
	    
	   	return $result;
	}
	
	public static function trimContentTags($tagstr){
		$tags=trim($tagstr);
		if (substr($tags, -1, 1) == ',')
		{
			$tags = substr($tags, 0, -1);
		}
		$tags = array_map('trim', explode(',', $tags));
		$tags = implode(",", $tags);
		
		return $tags;
	}
	
	
    
}
