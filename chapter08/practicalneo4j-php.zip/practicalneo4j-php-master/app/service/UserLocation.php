<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;

class UserLocation {
	
	public static function getUserLocation($username){
		$queryString = " MATCH (u:User { username : {u} } )-[:HAS]-(l:Location) " .
		" RETURN u.username as username, l.address as address, l.city as city, l.state as state, " .
		" l.zip as zip, l.lat as lat, l.lon as lon";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username
		));
		$result = $query->getResultSet();
		
		
		return $result;
		
	}
	
	// returns the location query, aka LQ
	public static function getLQ($ul,$distance){
		
		$lq = "withinDistance:[" .
				strval(floatval($ul["lat"])) .
				"," .
				strval(floatval($ul["lon"])) .
		        "," . 
		        $distance . 
				"]";
		return $lq;
	}
	
}