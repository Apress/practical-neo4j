<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;
use Everyman\Neo4j\Query\ResultSet;
require_once APPLICATION_PATH . '/model/MappedProductSearch.php';
require_once APPLICATION_PATH . '/model/MappedProductUserView.php';

class Product
{
	
	public static function getProducts($skip){

		$queryString = " MATCH (p:Product) RETURN ID(p) as nodeId, p.title as title, " .
		" p.description as description, p.tagstr  as tagstr "  .
		" ORDER BY p.title " .
		" SKIP {skip} LIMIT 10 ";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'skip' => $skip
		));
		$result = $query->getResultSet();
	
		return $result;
	}
	
	public static function getProductTrail($username){
	
		$queryString = " MATCH (u:User { username: {username} })-[r:VIEWED]->(p) "  .
			" RETURN p.title as title,  r.dateAsStr as dateAsStr "  .
			" ORDER BY r.timestamp desc ";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'username' => $username
		));
		$result = $query->getResultSet();
	
		return $result;
	}
	
	public static function createUserViewAndReturnViews($username,$productNodeId){
		
		$productNodeId = intval($productNodeId);
		# create timestamp and string display
		$ts = time();
		$timestampAsStr = date('n/d/Y',$ts) . ' at ' . date('g:i A',$ts);
		
		$queryString = " MATCH (p:Product), (u:User { username:{u} })" .
						" WHERE id(p) = {productNodeId}" .
						" WITH u,p" .
						" MERGE (u)-[r:VIEWED]->(p)" .
						" SET r.dateAsStr={timestampAsStr}, r.timestamp={ts}" .
						" WITH u " .
						" MATCH (u)-[r:VIEWED]->(p)" .
						" RETURN p.title as title,  r.dateAsStr as dateAsStr" .
						" ORDER BY r.timestamp desc";
		
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username,
				'productNodeId' => $productNodeId,
				'timestampAsStr' => $timestampAsStr,
				'ts' => $ts,
		));
		$result = $query->getResultSet();
		
		return  self::returnMappedProductUserView($result);
	}
	
	protected static function returnMappedProductUserView(ResultSet $results){
		$mappedArray = array();
		foreach ($results as $row) {
			$mappedArray[] = self::createMappedProductUserView(
					$row['title'],
					$row['dateAsStr']
			);
		}
		return $mappedArray;
	}
	
	protected static function createMappedProductUserView($title = null, $dateAsStr = null)
	{
		$mappedProductUserView = new MappedProductUserView();
		$mappedProductUserView->title = $title;
		$mappedProductUserView->dateAsStr = $dateAsStr;
		return $mappedProductUserView;
	}
	
	public static function getProductsHasATagAndUserUsesAMatchingTag(){
	
		$queryString = " MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) " .
			" RETURN p.title as title , collect(u.username) as users, " .
			" collect(distinct t.wordPhrase) as tags ";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, null);
		$result = $query->getResultSet();
	
		return $result;
	}
	
	public static function getProductsHasSpecificTagAndUserUsesSpecificTag($tag){
	
		$queryString = " MATCH (t:Tag { wordPhrase: {wp} }) " .
					" WITH t " .
					" MATCH (p:Product)-[:HAS]->(t)<-[:USES]-(u:User) " .
					" RETURN p.title as title,collect(u) as u, collect(distinct t) as t ";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'wp' => $tag
		));
		$result = $query->getResultSet();
	
		return $result;
	}

	public static function productSearch($q){
		
		$q = trim($q) . ".*";
		
		$queryString = " MATCH (p:Product) WHERE lower(p.title) =~ {q} ".
		" RETURN count(*) as name, TOSTRING(ID(p)) as id, p.title as label " .
		" ORDER BY p.title " .
		" LIMIT 5 ";
		
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'q' => $q
		));
		$result = $query->getResultSet();
		
		return self::returnMappedProductSearch($result);
	}
	
	
	protected static function returnMappedProductSearch(ResultSet $results)
	{
		$mappedArray = array();
		foreach ($results as $row) {
			$mappedArray[] = self::createMappedProductSearch(
					$row['id'],
					$row['label'],
					$row['name']
			);
		}
		return $mappedArray;
	}
	
	protected static function createMappedProductSearch($id = null, $label = null, $name = false)
	{
		$mappedProductSearch = new MappedProductSearch();
		$mappedProductSearch->id = $id;
		$mappedProductSearch->label = $label;
		$mappedProductSearch->name = $name;
		return $mappedProductSearch;
	}
}