<?php
$neo4jClient = new Everyman\Neo4j\Client('host', 7473);
$neo4jClient->getTransport()->useHttps()->setAuth('username', 'password');