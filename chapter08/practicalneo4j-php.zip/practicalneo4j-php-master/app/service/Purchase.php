<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;

class Purchase {
	
	// products purchased by friends
	public static function friendsPurchase($username){
		$queryString = " MATCH (u:User {username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p" .
			" RETURN p.productId as productId,  " .
			" p.title as title, " .
			" collect(f.firstname + ' ' + f.lastname) as fullname, " .
			" null as wordPhrase, count(f) as cfriends " .
			" ORDER BY cfriends desc, p.title ";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username
		));
		$result = $query->getResultSet();
		return $result;
	}
	
	// a specific product purchased by friends
	public static function friendsPurchaseByProduct($username,$title){
		$queryString = " MATCH (p:Product) " .
				" WHERE lower(p.title) =lower({title}) " .
				" WITH p " .
				" MATCH (u:User {username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->(p) " .
				" RETURN p.productId as productId,  " .
				" p.title as title, " .
				" collect(f.firstname + ' ' + f.lastname) as fullname, " .
				" null as wordPhrase, count(f) as cfriends " .
				" ORDER BY cfriends desc, p.title ";
				$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
						'u' => $username,
						'title' => $title
				));
		$result = $query->getResultSet();
		return $result;
	}

	// products purchased by friends that match the user's tags
	public static function friendsPurchaseTagSimilarity($username){
		$queryString = 
				" MATCH (u:User {username: {u} } )-[:FOLLOWS]-(f)-[:MADE]->()-[:CONTAINS]->p " .
				" WITH u,p,f " .
				" MATCH u-[:USES]->(t)<-[:HAS]-p " .
				" RETURN p.productId as productId,  " .
				" p.title as title, " .
				" collect(f.firstname + ' ' + f.lastname) as fullname, " .
				" t.wordPhrase as wordPhrase, " .
				" count(f) as cfriends " .
				" ORDER BY cfriends desc, p.title ";
				$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
						'u' => $username
				));
		$result = $query->getResultSet();
		return $result;
	}
	
	// user's friends' purchases who are nearby and the products match the user's tags
	public static function friendsPurchaseTagSimilarityAndProximityToLocation($username,$lq){
		$queryString = " START n = node:geom({lq}) " .
						" WITH n " .
						" MATCH (u:User {username: {u} } )-[:USES]->(t)<-[:HAS]-p " .
						" WITH n,u,p,t " .
						" MATCH u-[:FOLLOWS]->(f)-[:HAS]->(n) " .
						" WITH p,f,t " .
						" MATCH f-[:MADE]->()-[:CONTAINS]->(p) " .
						" RETURN p.productId as productId, " .
						" p.title as title, " .
						" collect(f.firstname + ' ' + f.lastname) as fullname, " .
						" t.wordPhrase as wordPhrase, " .
						" count(f) as cfriends " .
						" ORDER BY cfriends desc, p.title ";
				$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
						'u' => $username,
						'lq' => $lq
				));
		$result = $query->getResultSet();
		return $result;
	}
}