<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;
use Everyman\Neo4j\Query\ResultSet;
require_once APPLICATION_PATH . '/model/MappedTag.php';

class Tag
{
	public static function userTags($username){
		$queryString = " MATCH (u:User {username: {u} })-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " .
			" WITH distinct c "  .
			" MATCH c-[ct:HAS]->(t) "  .
			" WITH distinct ct,t "  .
			" RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id "  .
			" ORDER BY id desc "  .
			" SKIP 0 LIMIT 30";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username
		));
		
		$result = $query->getResultSet();
	
		return $result;
	}
	
	public static function tagsInNetwork($username){
		$queryString = " MATCH (u:User {username: {u} })-[:FOLLOWS]->f " .
				" WITH distinct f " .
				" MATCH f-[:CURRENTPOST]-lp-[:NEXTPOST*0..]-c " .
				" WITH distinct c " .
				" MATCH c-[ct:HAS]->(t) " .
				" WITH distinct ct,t " .
				" RETURN t.wordPhrase as name, t.wordPhrase as label, count(ct) as id " .
				" ORDER BY id desc " .
				" SKIP 0 LIMIT 30";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username
		));
		$result = $query->getResultSet();
	
		return $result;
	}
	
	public static function searchTags($q){
	
		$q = trim($q) . ".*";
	
		$queryString = " MATCH (c:Content)-[:HAS]->(t:Tag) WHERE t.wordPhrase =~ {q} " .
					" RETURN count(t) as name, TOSTRING(ID(t)) as id, t.wordPhrase as label  ".
					" ORDER BY t.wordPhrase " .
					" LIMIT 5";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'q' => $q
		));
		$result = $query->getResultSet();
	
		return self::returnMappedTag($result);
	}
	
	protected static function returnMappedTag(ResultSet $results)
	{
		$mappedArray = array();
		foreach ($results as $row) {
			$mappedArray[] = self::createMappedTag(
					$row['id'],
					$row['label'],
					$row['name']
			);
		}
		return $mappedArray;
	}
	
	protected static function createMappedTag($id = null, $label = null, $name = false)
	{
		$mappedTag = new MappedTag();
		$mappedTag->id = $id;
		$mappedTag->label = $label;
		$mappedTag->name = $name;
		return $mappedTag;
	}
}