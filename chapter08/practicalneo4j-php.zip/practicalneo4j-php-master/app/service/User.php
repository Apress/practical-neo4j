<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;

class User
{
	protected $node = null;
	public $id = null;
	public $username = '';
	public $firstname = '';
	public $lastname = '';

	public static function getByUsername($username)
	{
		$userlabel = Neo4Client::client()->makeLabel('User');
		$nodes= $userlabel->getNodes('username', $username);
	
		if (empty($nodes) || count($nodes)==0) {
			return null;
		}else{
			return self::fromArray($nodes[0]);
		}
	}

	public static function saveUser(User $user){
		if(!$user->node){
			$user->node = new Node(Neo4Client::client());
		}
		$userlabel = Neo4Client::client()->makeLabel('User');
		// set properties
		$user->node->setProperty('username', $user->username);
		$user->node->setProperty('firstname', $user->firstname);
		$user->node->setProperty('lastname', $user->lastname);
		// save the node
		$user->node->save()->addLabels(array($userlabel));
		//set the id on the user object
		$user->id = $user->node->getId();
	}
	
	public static function updateUser($username,$firstname,$lastname){
		
		$queryString="MATCH (user:User {username:{u}} )  " .
		"SET user.firstname = {fn}, user.lastname = {ln}".
		"RETURN user";
		
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username,
				'fn' => $firstname,
				'ln' => $lastname));
	
		$result = $query->getResultSet();
	
		return self::returnAsUsers($result);
	}

	// search by user returns users in the network that aren�t already being followed
	public static function searchByUsername($username, $currentusername)
	{
		// wild card search on $username - which is just a string passed 
		// in from the request, e.g. the letter 'a'
		$username=$username.'.*';
		$queryString = "MATCH (n:User), (user { username:{c}}) " . 
		"WHERE (n.username =~ {u} AND n <> user) AND (NOT (user)-[:FOLLOWS]->(n)) ".
		" RETURN n";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'u' => $username,
				'c' => $currentusername));
		$result = $query->getResultSet();
		return self::returnAsUsers($result);
	}

	public static function follow($username, $userTofollow)
	{
	
		$queryString = " MATCH (user1:User {username:{cu}} ), ".
				" (user2:User {username:{u}} ) " .
				" CREATE UNIQUE user1-[:FOLLOWS]->user2 " .
				" WITH user1" .
				" MATCH (user1)-[f:FOLLOWS]->(users)" .
				" RETURN users " .
				" ORDER BY users.username";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'cu' => $username,
				'u' => $userTofollow
		));
		$result = $query->getResultSet();
	
		return self::returnAsUsers($result);
	}

	public static function unfollow($username, $userToUnfollow)
	{
		$queryString = "MATCH (user1:User {username:{cu}} )-[f:FOLLOWS]->".
				" (user2:User {username:{u}} ) " .
				" DELETE f " .
				" WITH user1" .
				" MATCH (user1)-[f:FOLLOWS]->(users)" .
				" RETURN users " .
				" ORDER BY users.username";
	
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
				'cu' => $username,
				'u' => $userToUnfollow
		));
		$result = $query->getResultSet();
	
		return self::returnAsUsers($result);
	}

	public static function following($username)
	{
		$queryString = "MATCH (user { username:{u}})-[:FOLLOWS]->(users) ".
		" RETURN users ORDER BY users.username";
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, 
				array('u' => $username));
		$result = $query->getResultSet();
		return self::returnAsUsers($result);
	}

	private static function returnAsUsers($results){
		$userArray = array();
		foreach ($results as $row) {
			$userArray[] = self::fromArray($row['x']);
		}
		return $userArray;
	}

	public static function getByNodeId($id)
	{
		return self::fromArray( Neo4Client::client()->getNode($id));
	}

	public static function getUsers($id)
	{
		$node = Neo4Client::client()->getNode($id);

		return array(self::fromArray($node));
	}

	public static function fromArray(Node $node)
	{
		$user = new User();
		$user->id = $node->getId();
		$user->username = $node->getProperty('username');
		$user->firstname = $node->getProperty('firstname');
		$user->lastname = $node->getProperty('lastname');
        $user->node = $node;
		
        return $user;
	}
}