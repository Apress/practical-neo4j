<?php

use Everyman\Neo4j\Node;
use Everyman\Neo4j\Index;
use Everyman\Neo4j\Relationship;
use Everyman\Neo4j\Index\NodeIndex;

class Location
{
	
	public static function locationsWithinDistance($lq,$mappedUserLocation,$locationType){
		$queryString = " START n = node:geom({lq}) WHERE n.type = {locationType}  " .
		" RETURN n.locationId as locationId, n.address as address, n.city as city, " . 
		" n.state as state, n.zip as zip, n.name as name, n.lat as lat, n.lon as lon";
			
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
			'lq' => $lq,
			'locationType' => $locationType
		));
		$result = $query->getResultSet();
			
		foreach($result as $row){
				
			$row->distanceToLocation = 
				self::distance(floatval($mappedUserLocation["lat"]), 
						floatval($mappedUserLocation["lon"]), 
						floatval($row["lat"]), 
						floatval($row["lon"]), 
						"M") . " Miles away";
				
		}
			
		return $result;
	}
	
	public static function locationsWithinDistanceWithProduct($lq,$mappedUserLocation,$productNodeId){
		$queryString = " START n = node:geom({lq}),  p=node({productNodeId}) " .
			" MATCH n-[:HAS]->p " .
			" RETURN n.locationId as locationId, n.address as address, " .
			" n.city as city,  n.state as state, n.zip as zip, n.name as name, " .
			" n.lat as lat, n.lon as lon";
			
		$query = new Everyman\Neo4j\Cypher\Query(Neo4Client::client(), $queryString, array(
			'lq' => $lq,
			'productNodeId' => intval($productNodeId)
		));
			
		$result = $query->getResultSet();
		
		foreach($result as $row){
			$row->distanceToLocation = 
				self::distance(floatval($mappedUserLocation["lat"]), 
					floatval($mappedUserLocation["lon"]), 
					floatval($row["lat"]), 
					floatval($row["lon"]), 
					"M") . " Miles away";
		}
		
		return $result;
	}
	
	protected static function distance($lat1, $lon1, $lat2, $lon2, $unit) {
	
		$theta = $lon1 - $lon2;
		$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
		$dist = acos($dist);
		$dist = rad2deg($dist);
		$miles = $dist * 60 * 1.1515;
		$unit = strtoupper($unit);
	
		if ($unit == "K") {
			return ($miles * 1.609344);
		} else {
			return number_format($miles, 2, '.', '');
		}
	}

}