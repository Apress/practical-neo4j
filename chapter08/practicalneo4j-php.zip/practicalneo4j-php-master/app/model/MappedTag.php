<?php

class MappedTag
{
    public $id;
    public $label;
    public $name;
    
    
    public function toArray()
    {
        return array(
            'id' => $this->id,
            'label' => $this->label,
            'name' => $this->name,
        );
    }
}