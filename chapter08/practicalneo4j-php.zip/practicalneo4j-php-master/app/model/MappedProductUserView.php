<?php

class MappedProductUserView
{
    public $title;
    public $dateAsStr;
    
    public function toArray()
    {
        return array(
            'title' => $this->title,
            'dateAsStr' => $this->dateAsStr,
        );
    }
}