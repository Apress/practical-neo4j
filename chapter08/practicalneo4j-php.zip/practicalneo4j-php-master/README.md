Practical Neo4j for PHP
==================

I used Eclipse 3.7 with JDK 7 for this project.  This project also requires PHP 5.3.28 or greater.

After the project has been downloaed and unpacked, then you should:

1. Setup a Neo4j instance by going to www.graphstory.com/practicalneo4j
2. Copy the database connection information
3. Import the project into your IDE
4. Make sure to add a writable "logs" directory to under the {projectroot}/app folder
5. Update the database connection information in the {projectroot}/app/service/AppConfig.php file with your connection information
6. Configure your web server. The virtual host configuration for apache web server is below:

```xml
<VirtualHost *:80>
	ServerName practicalneo4j-php
	DocumentRoot /path/to/your/practicalneo4j-php/app/public

	<Directory /path/to/your/practicalneo4j-php/app/public>
	
		RewriteEngine On
		RewriteCond %{REQUEST_FILENAME} !-f
		RewriteRule ^(.*)$ index.php [QSA,L]
	
		Options Indexes FollowSymLinks MultiViews
		AllowOverride All
		Order allow,deny
		Allow from all
	</Directory>
</VirtualHost>
```